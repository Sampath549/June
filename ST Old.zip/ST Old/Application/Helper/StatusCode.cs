﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace Application.Helper
{
    public class StatusCode
    {
        public static string ErrorPage(Exception ex, int StatusCode)
        {
            if (Convert.ToBoolean(GlobalVariables.Shared.InsertErrorLog))
                ExceptionLogging.SendErrorToText(ex);

            string _PageRedirect = string.Empty;

            switch (StatusCode)
            {
                case 400:
                    _PageRedirect = GlobalVariables.Shared.BadRequest;
                    break;
                case 401:
                    _PageRedirect = GlobalVariables.Shared.Unauthorized;
                    break;
                case 403:
                    _PageRedirect = GlobalVariables.Shared.Forbidden;
                    break;
                case 404:
                    _PageRedirect = GlobalVariables.Shared.NotFound;
                    break;
                case 500:
                    _PageRedirect = GlobalVariables.Shared.InternalServerError;
                    break;
                default:
                    _PageRedirect = GlobalVariables.Shared.InternalServerError;
                    break;
            }
            return _PageRedirect;
        }

        public static void ErrorMsgText(Exception ex)
        {
            if (Convert.ToBoolean(GlobalVariables.Shared.InsertErrorLog))
                ExceptionLogging.SendErrorToText(ex);
        }
    }
}