﻿using Application.App_Start;
using Application.Models.SharedEntities;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Linq;

namespace Application.Helper
{
    public static class Reusable
    {
        public static string RedirectPage(string RoleCode)
        {
            try
            {
                if (RoleCode == "DEV")
                    return "/CPanelDev/Dashboard";
                else if (RoleCode == "STU")
                    return "/CPanelStudent/Dashboard";
                else if (RoleCode == "ADM")
                    return "/CPanelAdmin/Dashboard";
                else if (RoleCode == "SADM")
                    return "";
                else
                    return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void ErrorMsgText(Exception ex)
        {
            if (Convert.ToBoolean(GlobalVariables.Shared.InsertErrorLog))
                ExceptionLogging.SendErrorToText(ex);
        }
        public static string BindMenus()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                {
                    //API Call		
                    ArrayList _Array = new ArrayList();
                    _Array.Add(RSAPattern.Encrypt(_SessionUserDetails.RoleCode));
                    string _Menu = ApiHelper.PostData_Json("api/CPanel/BindMenus?Values=", _Array);
                    Result<string> _Result = JsonConvert.DeserializeObject<Result<string>>(_Menu);

                    SessionHandler.Menus = _Result.Data;
                }
                return SessionHandler.Menus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> GenderList()
        {
            try
            {
                List<SelectListItem> GenderList = new List<SelectListItem>();
                GenderList.Add(new SelectListItem { Text = "Select Gender", Value = "0" });
                GenderList.Add(new SelectListItem { Text = "Male", Value = "1" });
                GenderList.Add(new SelectListItem { Text = "Female", Value = "2" });
                GenderList.Add(new SelectListItem { Text = "Other", Value = "3" });
                return GenderList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> CountriesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> CountriesList = new List<SelectListItem>();
                if (SessionHandler.Countries == null)
                {
                    //API Call
                    ArrayList _Array = new ArrayList();
                    string _Countries = ApiHelper.PostData_Json("api/CPanel/GetCountries?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultCountries = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Countries);

                    CountriesList.Add(new SelectListItem { Text = "Select Country", Value = "0" });
                    for (int k = 0; k < _ResultCountries.Data.Count; k++)
                    {
                        CountriesList.Add(new SelectListItem
                        {
                            Text = _ResultCountries.Data[k].Description.ToString(),
                            Value = _ResultCountries.Data[k].Id.ToString()
                        });
                    }
                    SessionHandler.Countries = CountriesList;
                }
                return SessionHandler.Countries;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> StatesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> StatesList = new List<SelectListItem>();
                if (SessionHandler.States == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _States = ApiHelper.PostData_Json("api/CPanel/GetStates?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultStates = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_States);

                    StatesList.Add(new SelectListItem { Text = "Select State", Value = "0" });
                    for (int i = 0; i < _ResultStates.Data.Count; i++)
                    {
                        StatesList.Add(new SelectListItem
                        {
                            Text = _ResultStates.Data[i].Description.ToString(),
                            Value = _ResultStates.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.States = StatesList;
                }
                return SessionHandler.States;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> RolesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> _lst = new List<SelectListItem>();
                if (SessionHandler.Roles == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _Roles = ApiHelper.PostData_Json("api/CPanel/RolesList?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultRoles = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Roles);

                    _lst.Add(new SelectListItem { Text = "Select Role", Value = "0" });
                    for (int i = 0; i < _ResultRoles.Data.Count; i++)
                    {
                        _lst.Add(new SelectListItem
                        {
                            Text = _ResultRoles.Data[i].Description.ToString(),
                            Value = _ResultRoles.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.Roles = _lst;
                }
                return SessionHandler.Roles;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> CourseCategoryList()
        {
            try
            {
                List<SelectListItem> _lst = new List<SelectListItem>();

                ArrayList _Array = new ArrayList();
                string _CCateogry = ApiHelper.PostData_Json("api/CPanelAdmin/CourseCategoryList?Values=", _Array);
                Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_CCateogry);

                _lst.Add(new SelectListItem { Text = "Select Course Cateogry", Value = "0" });
                for (int i = 0; i < _Result.Data.Count; i++)
                {
                    _lst.Add(new SelectListItem
                    {
                        Text = _Result.Data[i].Description.ToString(),
                        Value = _Result.Data[i].Id.ToString()
                    });
                }
                return _lst;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<string> ProfilePicExtentions()
        {
            try
            {
                List<string> _ext = new List<string>();
                _ext.Add(".JPG");
                _ext.Add(".JPEG");
                _ext.Add(".PNG");
                _ext.Add(".jpg");
                _ext.Add(".jpge");
                _ext.Add(".png");
                return _ext;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> BatchList()
        {
            try
            {
                List<SelectListItem> _lst = new List<SelectListItem>();
                if (SessionHandler.SessionBatchList == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _CCateogry = ApiHelper.PostData_Json("api/CPanelAdmin/BatchList?Values=", _Array);
                    Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_CCateogry);

                    _lst.Add(new SelectListItem { Text = "Select Batch", Value = "0" });
                    for (int i = 0; i < _Result.Data.Count; i++)
                    {
                        _lst.Add(new SelectListItem
                        {
                            Text = _Result.Data[i].Description.ToString(),
                            Value = _Result.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.SessionBatchList = _lst;
                }
                return SessionHandler.SessionBatchList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> StudentsBatchList(int UID)
        {
            try
            {
                List<SelectListItem> _lst = new List<SelectListItem>();
                if (SessionHandler.SessionStudentBatchList == null)
                {
                    ArrayList _Array = new ArrayList();
                    _Array.Add(RSAPattern.Encrypt(UID.ToString()));
                    string _CCateogry = ApiHelper.PostData_Json("api/CPanelStudent/StudentsBatchList?Values=", _Array);
                    Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_CCateogry);

                    for (int i = 0; i < _Result.Data.Count; i++)
                    {
                        _lst.Add(new SelectListItem
                        {
                            Text = _Result.Data[i].Description.ToString(),
                            Value = _Result.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.SessionStudentBatchList = _lst;
                }
                return SessionHandler.SessionStudentBatchList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> CourseList()
        {
            try
            {
                List<SelectListItem> _lst = new List<SelectListItem>();
                if (SessionHandler.SessionCourseList == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _CCateogry = ApiHelper.PostData_Json("api/CPanelAdmin/CourseList?Values=", _Array);
                    Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_CCateogry);

                    _lst.Add(new SelectListItem { Text = "Select Course", Value = "0" });
                    for (int i = 0; i < _Result.Data.Count; i++)
                    {
                        _lst.Add(new SelectListItem
                        {
                            Text = _Result.Data[i].Description.ToString(),
                            Value = _Result.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.SessionCourseList = _lst;
                }
                return SessionHandler.SessionCourseList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> StudentsList()
        {
            try
            {
                List<SelectListItem> _lst = new List<SelectListItem>();
                if (SessionHandler.SessionStudentsList == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _Studentslst = ApiHelper.PostData_Json("api/CPanelAdmin/StudentsList?Values=", _Array);
                    Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Studentslst);

                    for (int i = 0; i < _Result.Data.Count; i++)
                    {
                        _lst.Add(new SelectListItem
                        {
                            Text = _Result.Data[i].Description.ToString(),
                            Value = _Result.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.SessionStudentsList = _lst;
                }
                return SessionHandler.SessionStudentsList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SE_News> LatestNews()
        {
            try
            {
                List<SE_News> _News = new List<SE_News>();
                XmlDocument xmlDoc = new XmlDocument();
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/XML/LatestNews.xml");  //File Path
                xmlDoc.Load(filepath);
                XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("item");

                foreach (XmlNode node in nodeList)
                {
                    SE_News _Rec = new SE_News();
                    _Rec.NewsId = Convert.ToInt32(node.SelectSingleNode("newsid").InnerText);
                    _Rec.NewsTitle = node.SelectSingleNode("newstitle").InnerText;
                    _Rec.NewsDesc = node.SelectSingleNode("newsdesc").InnerText;
                    _Rec.Image = node.SelectSingleNode("image").InnerText;
                    _Rec.FullDate = node.SelectSingleNode("fulldate").InnerText;
                    _News.Add(_Rec);
                }
                _News = _News.OrderByDescending(i => i.NewsId).ToList();
                return _News;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<SE_UpcomingClasses> UpcomingClasses()
        {
            try
            {
                List<SE_UpcomingClasses> _UClasses = new List<SE_UpcomingClasses>();
                XmlDocument xmlDoc = new XmlDocument();
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/XML/UpcomingClasses.xml");  //File Path
                xmlDoc.Load(filepath);
                XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("item");

                foreach (XmlNode node in nodeList)
                {
                    SE_UpcomingClasses _Rec = new SE_UpcomingClasses();
                    _Rec.UCId = Convert.ToInt32(node.SelectSingleNode("ucid").InnerText);
                    _Rec.UCTitle = node.SelectSingleNode("uctitle").InnerText;
                    _Rec.UCCategory = node.SelectSingleNode("uccategory").InnerText;
                    _Rec.DateNumber = node.SelectSingleNode("ucdate").InnerText;
                    _Rec.FullDate = node.SelectSingleNode("fulldate").InnerText;
                    _UClasses.Add(_Rec);
                }
                _UClasses = _UClasses.OrderByDescending(i => i.UCId).ToList();
                return _UClasses;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<SE_LatestVideos> LatestVideos()
        {
            try
            {
                List<SE_LatestVideos> _Videos = new List<SE_LatestVideos>();
                XmlDocument xmlDoc = new XmlDocument();
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/XML/LatestVideos.xml");  //File Path		
                xmlDoc.Load(filepath);
                XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("item");
                foreach (XmlNode node in nodeList)
                {
                    SE_LatestVideos _Rec = new SE_LatestVideos();
                    _Rec.LVId = Convert.ToInt32(node.SelectSingleNode("lvId").InnerText);
                    _Rec.LVTitle = node.SelectSingleNode("lvtitile").InnerText;
                    _Rec.LVDesc = node.SelectSingleNode("lvdesc").InnerText;
                    _Rec.LVImage = node.SelectSingleNode("image").InnerText;
                    _Rec.LVUrl = node.SelectSingleNode("url").InnerText;
                    _Rec.DateNumber = node.SelectSingleNode("fulldate").InnerText;
                    _Videos.Add(_Rec);
                }
                _Videos = _Videos.OrderByDescending(i => i.LVId).ToList();
                return _Videos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static String ErrorlineNo, Errormsg, extype, exurl, ErrorLocation;
        public static void TempPwd(int UserId, string Email, string Pwd)
        {
            var _BreakLine = Environment.NewLine;
            try
            {
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/TempPwd/");  //Text File Path
                if (!Directory.Exists(filepath))
                    Directory.CreateDirectory(filepath);

                filepath = filepath + DateTime.Today.ToString("dd-MM-yy") + ".txt";   //Text File Name
                if (!File.Exists(filepath))
                    File.Create(filepath).Dispose();

                using (StreamWriter sw = File.AppendText(filepath))
                {
                    string _ErrorDetails = "User Id:" + " " + UserId + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Email:" + " " + Email + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Pwd:" + " " + Pwd + _BreakLine;
                    sw.WriteLine("-----------------------------------------------------------------");
                    sw.WriteLine(_ErrorDetails);
                    sw.WriteLine("------------------------------/End/------------------------------");
                    sw.WriteLine(_BreakLine);
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }
    }
}