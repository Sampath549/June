﻿using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Helper
{
    public static class SessionHandler
    {
        public static SE_Users UserDetails
        {
            get
            {
                return HttpContext.Current.Session["_UserDetails"] != null ? HttpContext.Current.Session["_UserDetails"] as SE_Users : null;
            }
            set
            {
                HttpContext.Current.Session["_UserDetails"] = value;
            }
        }

        public static string Menus
        {
            get
            {
                return HttpContext.Current.Session["_Menus"] != null ? HttpContext.Current.Session["_Menus"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["_Menus"] = value;
            }
        }

        public static List<SelectListItem> Countries
        {
            get
            {
                return HttpContext.Current.Session["_Countries"] != null ? HttpContext.Current.Session["_Countries"] as List<SelectListItem> : null;
            }
            set
            {
                HttpContext.Current.Session["_Countries"] = value;
            }
        }

        public static List<SelectListItem> States
        {
            get
            {
                return HttpContext.Current.Session["_States"] != null ? HttpContext.Current.Session["_States"] as List<SelectListItem> : null;
            }
            set
            {
                HttpContext.Current.Session["_States"] = value;
            }
        }

        public static List<SelectListItem> Roles
        {
            get
            {
                return HttpContext.Current.Session["_Roles"] != null ? HttpContext.Current.Session["_Roles"] as List<SelectListItem> : null;
            }
            set
            {
                HttpContext.Current.Session["_Roles"] = value;
            }
        }

        public static List<SelectListItem> CourseCateogry
        {
            get
            {
                return HttpContext.Current.Session["_CourseCateogry"] != null ? HttpContext.Current.Session["_CourseCateogry"] as List<SelectListItem> : null;
            }
            set
            {
                HttpContext.Current.Session["_CourseCateogry"] = value;
            }
        }









        public static List<SelectListItem> SessionStudentBatchList
        {
            get
            {
                return HttpContext.Current.Session["_StudentBatchList"] != null ? HttpContext.Current.Session["_StudentBatchList"] as List<SelectListItem> : null;
            }
            set
            {
                HttpContext.Current.Session["_StudentBatchList"] = value;
            }
        }
        public static List<SelectListItem> SessionBatchList
        {
            get
            {
                return HttpContext.Current.Session["_BatchList"] != null ? HttpContext.Current.Session["_BatchList"] as List<SelectListItem> : null;
            }
            set
            {
                HttpContext.Current.Session["_BatchList"] = value;
            }
        }
        public static List<SelectListItem> SessionCourseList
        {
            get
            {
                return HttpContext.Current.Session["_CourseList"] != null ? HttpContext.Current.Session["_CourseList"] as List<SelectListItem> : null;
            }
            set
            {
                HttpContext.Current.Session["_CourseList"] = value;
            }
        }
        public static List<SelectListItem> SessionStudentsList
        {
            get
            {
                return HttpContext.Current.Session["_StudentsList"] != null ? HttpContext.Current.Session["_StudentsList"] as List<SelectListItem> : null;
            }
            set
            {
                HttpContext.Current.Session["_StudentsList"] = value;
            }
        }
    }
}