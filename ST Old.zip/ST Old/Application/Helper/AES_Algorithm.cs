﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace Application.Helper
{
    public class AES_Algorithm
    {
        /*
    * usage
    * 
    *  string plaintext = "Hello world!!! \n";
       Console.WriteLine("Plain Text :"+ plaintext);

       string ciphertext = Encryption.EncryptString(plaintext);
       Console.WriteLine("Cipher Text :" + ciphertext);
       Console.WriteLine("Plain Text :" + Encryption.DecryptString(ciphertext));

       To generate AES Key 
       powershell command 
       $AESKey = New-Object Byte[] 32
       [Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($AESKey)
       $AESKeyb64 = [Convert]::ToBase64String($AESKey)
    * */
        private static byte[] AESKey;
        static private byte[] GetAesKey()
        {
            if (AESKey == null || AESKey.Length != 32)
            {
                string key = GlobalVariables.Shared.AESKey;
                //Console.WriteLine("Key :" + key);
                AESKey = System.Convert.FromBase64String(key);
                //Console.WriteLine("Key lenght bytes:" + AESKey.Length);
            }
            return (AESKey);
        }
        public static string EncryptString(string plainText)
        {
            if (plainText.Length < 1)
            {
                return ("");
            }
            return (EncryptString(plainText, GetAesKey()));
        }
        public static string DecryptString(string cipherText)
        {
            if (cipherText.Length < 1)
            {
                return ("");
            }
            return (DecryptString(cipherText, GetAesKey()));
        }
        [SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times")]
        public static string EncryptString(string plainText, byte[] key)
        {
            string cipherText;
            var aes = new AesCryptoServiceProvider()
            {
                Key = key,
                Mode = CipherMode.CBC,
                BlockSize = 128,
                Padding = PaddingMode.PKCS7
            };
            aes.GenerateIV();
            byte[] plaintxt = Encoding.UTF8.GetBytes(plainText);
            var iv = aes.IV;

            using (var encrypter = aes.CreateEncryptor(aes.Key, iv))
            using (var cipherStream = new MemoryStream())
            {
                using (var tCryptoStream = new CryptoStream(cipherStream, encrypter, CryptoStreamMode.Write))
                using (var tBinaryWriter = new BinaryWriter(tCryptoStream))
                {
                    cipherStream.Write(iv, 0, iv.Length);
                    tBinaryWriter.Write(plaintxt);
                    tCryptoStream.FlushFinalBlock();
                }

                cipherText = Convert.ToBase64String(cipherStream.ToArray());
            }
            return (cipherText);
        }
        [SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times")]
        public static string DecryptString(string cipherText, byte[] key)
        {
            string plainText = "";
            var aes = new AesCryptoServiceProvider()
            {
                Key = key,
                Mode = CipherMode.CBC,
                BlockSize = 128,
                Padding = PaddingMode.PKCS7

            };
            var iv = new byte[16];
            byte[] ciphertxt = Convert.FromBase64String(cipherText);
            Array.Copy(ciphertxt, 0, iv, 0, iv.Length);
            using (var plaintextstream = new MemoryStream())
            {
                using (var cs = new CryptoStream(plaintextstream, aes.CreateDecryptor(aes.Key, iv), CryptoStreamMode.Write))
                using (var binaryWriter = new BinaryWriter(cs))
                {
                    //Decrypt Cipher Text from Message
                    binaryWriter.Write(
                        ciphertxt,
                        iv.Length,
                        ciphertxt.Length - iv.Length
                    );
                }
                plainText = Encoding.UTF8.GetString(plaintextstream.ToArray());
            }
            return (plainText);
        }
    }
}