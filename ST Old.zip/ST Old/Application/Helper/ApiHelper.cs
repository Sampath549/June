﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Application.Helper
{
    public static class ApiHelper
    {
        public static string PostData_Json_NToken(string endPointAddress, ArrayList _Array)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(GlobalVariables.Shared.ConfigUrl);
                    client.DefaultRequestHeaders.Clear();
                    var response = client.PostAsJsonAsync(endPointAddress, _Array);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        dynamic requestResult = response.Result.Content.ReadAsStringAsync().Result;
                        return requestResult;
                    }
                    else
                    {
                        var resp = new HttpResponseMessage(response.Result.StatusCode)
                        {
                            Content = new StringContent(response.Result.Content.ReadAsStringAsync().Result),
                            ReasonPhrase = response.Result.ReasonPhrase
                        };
                        throw new HttpResponseException(resp);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static string PostData_Json(string endPointAddress, ArrayList _Array)
        {
            try
            {
                var accessToken = (string)System.Web.HttpContext.Current.Session["BearerToken"];

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(GlobalVariables.Shared.ConfigUrl);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("AuthorizedToken", accessToken);
                    var response = client.PostAsJsonAsync(endPointAddress, _Array);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        dynamic requestResult = response.Result.Content.ReadAsStringAsync().Result;
                        return requestResult;
                    }
                    else
                    {
                        var resp = new HttpResponseMessage(response.Result.StatusCode)
                        {
                            Content = new StringContent(response.Result.Content.ReadAsStringAsync().Result),
                            ReasonPhrase = response.Result.ReasonPhrase
                        };
                        throw new Exception(resp.StatusCode.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}