﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Web;
using System.Web.Security;

namespace Application.Helper
{
    public static class PwdEncryption
    {
        public static string GenerateRandomNumbers(int length)
        {
            try
            {
                string allowedChars = "";
                allowedChars = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,";
                allowedChars += "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,";
                allowedChars += "1,2,3,4,5,6,7,8,9,0";
                allowedChars += "!,@,#,$,%,&,?";
                char[] sep = { ',' };
                string[] arr = allowedChars.Split(sep);
                string passwordString = "";
                string temp = "";
                Random rand = new Random();
                for (int i = 0; i < Convert.ToInt32(length); i++)
                {
                    temp = arr[rand.Next(0, arr.Length)];
                    passwordString += temp;
                }

                return passwordString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static string GeneratePassword()
        {
            return Membership.GeneratePassword(8, 1);
        }
        public static string EncodePassword(string pass, string salt) //encrypt password
        {
            return SHAEncryption(pass, salt);
        }
        private static string SHAEncryption(string msg, string key)
        {
            var encoding = new System.Text.ASCIIEncoding();
            byte[] keyByte = encoding.GetBytes(key);
            byte[] messageBytes = encoding.GetBytes(msg);
            string securehash = null;
            using (var hmacsha256 = new HMACSHA256(keyByte))
            {
                byte[] hashmessage = hmacsha256.ComputeHash(messageBytes);
                securehash = Convert.ToBase64String(hashmessage);
            }
            return (securehash);
        }
    }
}