﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace Application.Models
{
    public partial class DataAccessComponent
    {
        public string DB_ADOConnect
        {
            get
            {
                if ((ConfigurationManager.AppSettings["DatabaseConnectivity"]) == "Live")
                    return ConfigurationManager.ConnectionStrings["ProductionDB"].ToString();
                else if ((ConfigurationManager.AppSettings["DatabaseConnectivity"]) == "Local")
                    return ConfigurationManager.ConnectionStrings["DevelopmentDB"].ToString();
                else
                    return ConfigurationManager.ConnectionStrings["Empty"].ToString();
            }
        }
    }
}