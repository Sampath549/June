﻿using Application.App_Start;
using Application.Helper;
using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;

namespace Application.Models.DataObjects
{
    public partial class CPanelAdminDAL : DataAccessComponent
    {
        public SE_AdminDashboard Dashboard()
        {
            try
            {
                SE_AdminDashboard _Rec = new SE_AdminDashboard();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_AdminWidgets", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                    {
                        _Rec.RequestForm = Convert.ToInt32(dr["RequestForms"]);
                        _Rec.ManualForm = Convert.ToInt32(dr["ManualForms"]);
                        _Rec.ContactForm = Convert.ToInt32(dr["ContactForms"]);
                        _Rec.RegisterdStudents = Convert.ToInt32(dr["RegisteredStudents"]);
                    }

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_Forms> GetForms(string _FormType)
        {
            try
            {
                _FormType = StringEncrypt.Encrypt(_FormType);
                List<SE_Forms> _Rec = new List<SE_Forms>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                            SELECT 
                                                FormId,
	                                            FormType, 
	                                            Name, 
	                                            Email, 
	                                            Mobile, 
	                                            Course, 
	                                            [Message] 
                                            FROM [StepTekDB].[tbl_Forms] 
                                            WHERE FormType = @FormType
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@FormType", _FormType);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Forms { FormId = Convert.ToString(dr["FormId"]), FormType = Convert.ToString(dr["FormType"]), Name = dr["Name"].ToString(), Email = dr["Email"].ToString(), Mobile = dr["Mobile"].ToString(), Course = dr["Course"].ToString(), Message = dr["Message"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_Forms> GetFormsById(string Id)
        {
            try
            {
                List<SE_Forms> _Rec = new List<SE_Forms>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                            SELECT 
                                                FormId,
	                                            FormType, 
	                                            Name, 
	                                            Email, 
	                                            Mobile, 
	                                            Course, 
	                                            [Message] 
                                            FROM [StepTekDB].[tbl_Forms]  
                                            WHERE FormId = @FormId
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@FormId", Id);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Forms { FormId = Convert.ToString(dr["FormId"]), FormType = Convert.ToString(dr["FormType"]), Name = dr["Name"].ToString(), Email = dr["Email"].ToString(), Mobile = dr["Mobile"].ToString(), Course = dr["Course"].ToString(), Message = dr["Message"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertForms(SE_Forms _Data)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_Forms";
                cmd.Parameters.Add("@FormType", SqlDbType.VarChar).Value = _Data.FormType;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = _Data.Name;
                cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = _Data.Email;
                cmd.Parameters.Add("@Mobile", SqlDbType.VarChar).Value = _Data.Mobile;
                cmd.Parameters.Add("@Course", SqlDbType.VarChar).Value = _Data.Course;
                cmd.Parameters.Add("@Message", SqlDbType.VarChar).Value = _Data.Message;

                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                return 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int UploadDocuments(SE_Uploads _Data)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_UploadDocument";
                cmd.Parameters.Add("@CourseId", SqlDbType.VarChar).Value = _Data.CourseId;
                cmd.Parameters.Add("@FileName", SqlDbType.VarChar).Value = _Data.FileName;
                cmd.Parameters.Add("@FileExt", SqlDbType.VarChar).Value = _Data.FileExt;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_Uploads> GetUploadedDocuments()
        {
            try
            {
                List<SE_Uploads> _Rec = new List<SE_Uploads>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                            SELECT 
                                                CM.MaterialId [Id],
                                            	CM.CourseId, 
                                            	C.Title [CourseDesc],
                                            	CM.FileName,
                                            	CM.FileExt
                                            FROM [StepTekDB].[tbl_CourseMaterial] CM
                                            INNER JOIN [tbl_Course] C ON CM.CourseId = C.CourseId 
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Uploads { Id = Convert.ToString(dr["Id"]), CourseId = Convert.ToString(dr["CourseId"]), CourseDesc = Convert.ToString(dr["CourseDesc"]), FileName = dr["FileName"].ToString(), FileExt = dr["FileExt"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int DeleteFile(string ID)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_File";
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = Convert.ToInt32(ID);

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int UploadVideos(SE_Uploads _Data)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_UploadVideo";
                cmd.Parameters.Add("@BatchId", SqlDbType.VarChar).Value = _Data.BatchId;
                cmd.Parameters.Add("@Url", SqlDbType.VarChar).Value = _Data.Url;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_Uploads> GetUploadedVideos()
        {
            try
            {
                List<SE_Uploads> _Rec = new List<SE_Uploads>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                            SELECT
                                            	VR.[VideoRecId],
                                            	VR.BatchId,
                                            	B.BatchCode,
                                            	VR.VideoPath
                                            FROM [StepTekDB].[tbl_VideoRecording] VR
                                            INNER JOIN [tbl_Batches] B ON B.BatchId = VR.BatchId
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Uploads { Id = Convert.ToString(dr["VideoRecId"]), BatchId = Convert.ToString(dr["BatchId"]), BatchCode = Convert.ToString(dr["BatchCode"]), Url = dr["VideoPath"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int DeleteVideo(string ID)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_Video";
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = Convert.ToInt32(ID);

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_Users> GetStudentDetails()
        {
            try
            {
                List<SE_Users> _Rec = new List<SE_Users>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                            SELECT
                                                U.UserId, 
	                                            U.FirstName +' '+ U.LastName [FullName],
	                                            U.FirstName,
	                                            U.LastName, 
	                                            U.Email,
	                                            U.Mobile,
	                                            U.RoleId,
	                                            R.Description [RoleDesc],
	                                            U.IsActive,
	                                            (SELECT STUFF(
	                                            		(SELECT DISTINCT ', '+ CAST(B.BatchCode AS VARCHAR(MAX)) FROM [StepTekDB].[tbl_Batches] B,tbl_BatchStudents BS
	                                            			WHERE B.BatchId = BS.BatchId  AND BS.StudentId = U.UserId
	                                            			FOR XMl PATH('')),1,1,'')
	                                            			FROM [StepTekDB].[tbl_BatchStudents] TBS 
	                                            			WHERE TBS.StudentId = U.UserId
	                                            			Group By TBS.StudentId ) [Batches]
                                            FROM [StepTekDB].[tbl_Users] U 
                                            INNER JOIN [StepTekDB].[Ref_Roles] R ON R.RoleId = U.RoleId 
                                            WHERE U.RoleId = @RoleId
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@RoleId", GlobalVariables.Shared.StudentRoleId);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Users { UserId = Convert.ToInt32(dr["UserId"]), FirstName = Convert.ToString(dr["FirstName"]), LastName = dr["LastName"].ToString(), Email = dr["Email"].ToString(), Mobile = dr["Mobile"].ToString(), RoleId = Convert.ToInt32(dr["RoleId"]), RoleDesc = dr["RoleDesc"].ToString(), IsActive = Convert.ToBoolean(dr["IsActive"]), Batches = dr["Batches"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_Users> EditStudentDetails(int UID)
        {
            try
            {
                List<SE_Users> _Rec = new List<SE_Users>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                            SELECT
                                                U.UserId, 
	                                            U.FirstName +' '+ U.LastName [FullName],
	                                            U.FirstName,
	                                            U.LastName, 
	                                            U.Email,
	                                            U.Mobile,
	                                            U.RoleId,
	                                            R.Description [RoleDesc],
	                                            U.IsActive,
                                                (SELECT STUFF(
	                                            		(SELECT DISTINCT ', '+ CAST(B.BatchCode AS VARCHAR(MAX)) FROM [StepTekDB].[tbl_Batches] B,tbl_BatchStudents BS
	                                            			WHERE B.BatchId = BS.BatchId
	                                            			FOR XMl PATH('')),1,1,'')
	                                            			FROM [StepTekDB].[tbl_BatchStudents] TBS 
	                                            			WHERE TBS.StudentId = U.UserId
	                                            			Group By TBS.StudentId ) [Batches]
                                            FROM [StepTekDB].[tbl_Users] U 
                                            INNER JOIN [StepTekDB].[Ref_Roles] R ON R.RoleId = U.RoleId 
                                            WHERE U.RoleId = @RoleId AND U.UserId = @UserId
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@RoleId", GlobalVariables.Shared.StudentRoleId);
                        da.SelectCommand.Parameters.AddWithValue("@UserId", UID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Users { UserId = Convert.ToInt32(dr["UserId"]), FirstName = Convert.ToString(dr["FirstName"]), LastName = dr["LastName"].ToString(), Email = dr["Email"].ToString(), Mobile = dr["Mobile"].ToString(), RoleId = Convert.ToInt32(dr["RoleId"]), RoleDesc = dr["RoleDesc"].ToString(), IsActive = Convert.ToBoolean(dr["IsActive"]), Batches = dr["Batches"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int UpdateStudentDetails(SE_Users Users)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Update_StudentDetails";
                cmd.Parameters.Add("@UserId", SqlDbType.VarChar).Value = Users.UserId;
                cmd.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = Users.FirstName;
                cmd.Parameters.Add("@LastName", SqlDbType.VarChar).Value = Users.LastName;
                cmd.Parameters.Add("@IsActive", SqlDbType.Bit).Value = Users.IsActive;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_RefValues> GetCourseCategory()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [StepTekDB].[tbl_CourseCategory]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["CategoryId"]), Code = dr["Code"].ToString(), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateCourseCategory(string Code, string Desc, string btnType)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_CourseCategory";
                cmd.Parameters.Add("@Code", SqlDbType.VarChar).Value = Code;
                cmd.Parameters.Add("@Desc", SqlDbType.VarChar).Value = Desc;
                cmd.Parameters.Add("@btnType", SqlDbType.VarChar).Value = btnType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteCourseCategory(string Code)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_CourseCategory";
                cmd.Parameters.Add("@Code", SqlDbType.VarChar).Value = Code;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_RefValues> CourseCategoryList()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT [CategoryId], [Description] FROM [StepTekDB].[tbl_CourseCategory]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["CategoryId"]), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_Course> GetCourse()
        {
            try
            {
                List<SE_Course> _Rec = new List<SE_Course>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT C.CourseId, C.CategoryId,CC.[Description] [CategoryDesc], C.Title, C.[Description] FROM [StepTekDB].[tbl_Course] C INNER JOIN [StepTekDB].[tbl_CourseCategory] CC ON CC.CategoryId = C.CategoryId ", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Course { CourseId = Convert.ToInt32(dr["CourseId"]), CategoryId = Convert.ToInt32(dr["CategoryId"]), CategoryDesc = dr["CategoryDesc"].ToString(), Title = dr["Title"].ToString(), Desc = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateCreateCourse(SE_Course _Course)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_CreateCourse";
                cmd.Parameters.Add("@CategoryId", SqlDbType.Int).Value = _Course.CategoryId;
                cmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = _Course.Title;
                cmd.Parameters.Add("@Desc", SqlDbType.VarChar).Value = _Course.Desc;
                cmd.Parameters.Add("@btnType", SqlDbType.VarChar).Value = _Course.btnType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteCourse(string Title)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_Delete_Course";
            cmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = Title;

            SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            cmd.Parameters.Add(outputIdParam);
            cmd.Connection = con;

            try
            {
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                string str = ex.Message;
                if (str.IndexOf("The DELETE statement conflicted with the REFERENCE constraint") > -1)
                {
                    throw new Exception("Related Records");
                }
                else
                    throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_CourseDetails> GetCourseDetails()
        {
            try
            {
                List<SE_CourseDetails> _Rec = new List<SE_CourseDetails>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_CourseDetails", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_CourseDetails
                        {
                            CDetailsId = Convert.ToString(dr["CDetailsId"]),
                            CourseId = Convert.ToInt32(dr["CourseId"]),
                            CourseTitle = Convert.ToString(dr["CourseTitle"]),
                            CategoryId = Convert.ToInt32(dr["CategoryId"]),
                            CategoryDesc = dr["CategoryDesc"].ToString(),
                            Currency = dr["Currency"].ToString(),
                            Price = dr["Price"].ToString(),
                            Rating = dr["Ratting"].ToString(),
                            Duration = dr["Duration"].ToString(),
                            NumOfClasses = dr["NumOfClasses"].ToString(),
                            Image = dr["Image"].ToString()
                        });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_RefValues> CourseList()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT [CourseId], [Title] FROM [StepTekDB].[tbl_Course]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["CourseId"]), Description = dr["Title"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateCourseDetails(string CourseId, string Currency, string Price, string Rating, string Duration, string NumOfClasses, string Image, string CDetailsId, string btnType)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_CourseDetails";
                cmd.Parameters.Add("@CourseId", SqlDbType.VarChar).Value = Convert.ToInt32(CourseId);
                cmd.Parameters.Add("@Currency", SqlDbType.VarChar).Value = Currency;
                cmd.Parameters.Add("@Price", SqlDbType.Decimal).Value = Convert.ToDecimal(Price);
                cmd.Parameters.Add("@Rating", SqlDbType.Int).Value = Convert.ToInt32(Rating);
                cmd.Parameters.Add("@Duration", SqlDbType.Int).Value = Convert.ToInt32(Duration);
                cmd.Parameters.Add("@NumOfClasses", SqlDbType.Int).Value = Convert.ToInt32(NumOfClasses);
                cmd.Parameters.Add("@Image", SqlDbType.VarChar).Value = Image;
                cmd.Parameters.Add("@CDetailsId", SqlDbType.Int).Value = Convert.ToInt32(CDetailsId);
                cmd.Parameters.Add("@btnType", SqlDbType.VarChar).Value = btnType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_CourseDetails> EditCourseDetails(int CDID)
        {
            try
            {
                List<SE_CourseDetails> _Rec = new List<SE_CourseDetails>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_CourseDetailsById", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@CDetailsId", CDID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_CourseDetails
                        {
                            CDetailsId = Convert.ToString(dr["CDetailsId"]),
                            CourseId = Convert.ToInt32(dr["CourseId"]),
                            CourseTitle = Convert.ToString(dr["CourseTitle"]),
                            CategoryId = Convert.ToInt32(dr["CategoryId"]),
                            CategoryDesc = dr["CategoryDesc"].ToString(),
                            Currency = dr["Currency"].ToString(),
                            Price = dr["Price"].ToString(),
                            Rating = dr["Ratting"].ToString(),
                            Duration = dr["Duration"].ToString(),
                            NumOfClasses = dr["NumOfClasses"].ToString(),
                            Image = dr["Image"].ToString()
                        });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int DeleteCourseDetails(string ID)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_CourseDetails";
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = ID;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_CourseContent> GetCourseContent()
        {
            try
            {
                List<SE_CourseContent> _Rec = new List<SE_CourseContent>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT CCo.ContentId, CCo.CourseId, C.[Title] [CourseDesc], CCo.Concepts [Content] FROM [StepTekDB].[tbl_CourseContent] CCo INNER JOIN [StepTekDB].[tbl_Course] C ON C.CourseId = CCo.CourseId", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_CourseContent { ContentId = Convert.ToString(dr["ContentId"]), CourseId = Convert.ToInt32(dr["CourseId"]), CourseDesc = dr["CourseDesc"].ToString(), Content = dr["Content"].ToString(), ContentShort = dr["Content"].ToString().Length > 30 ? dr["Content"].ToString().Substring(0, 30) + "...." : dr["Content"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertUpdateCourseContent(string ContentId, string CourseId, string Content, string btnType)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_CourseContent";
                if (btnType == "Update")
                    cmd.Parameters.Add("@ContentId", SqlDbType.Int).Value = Convert.ToInt32(ContentId);
                else if (btnType == "Save")
                    cmd.Parameters.Add("@ContentId", SqlDbType.Int).Value = null;
                cmd.Parameters.Add("@CourseId", SqlDbType.Int).Value = Convert.ToInt32(CourseId);
                cmd.Parameters.Add("@Content", SqlDbType.VarChar).Value = Content;
                cmd.Parameters.Add("@btnType", SqlDbType.VarChar).Value = btnType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteCourseContent(string ID)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_CourseContent";
                cmd.Parameters.Add("@ID", SqlDbType.VarChar).Value = ID;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_RefValues> StudentsList()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT UserId, FirstName, LastName, Email FROM [StepTekDB].[tbl_Users] WHERE IsActive = 1 AND RoleId = @RoleId", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@RoleId", GlobalVariables.Shared.StudentRoleId);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                    {
                        string FullVal = AES_Algorithm.DecryptString(dr["FirstName"].ToString()) + " " + AES_Algorithm.DecryptString(dr["LastName"].ToString()) + " (" + StringEncrypt.Decrypt(dr["Email"].ToString()) + ")";
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["UserId"]), Description = FullVal });
                    }

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_RefValues> BatchList()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT [BatchId], [BatchCode] FROM [StepTekDB].[tbl_Batches]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["BatchId"]), Description = dr["BatchCode"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int CreateBatch(SE_Batches _Batch)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                var routes_list = (dynamic)json_serializer.DeserializeObject(_Batch.SingleValStudents);

                string ParamValue = string.Empty;
                foreach (var val in routes_list)
                    ParamValue += StringEncrypt.Encrypt(val.Split(new Char[] { '(', ')' })[1]) + ",";

                if (ParamValue != "")
                    ParamValue = ParamValue.Remove(ParamValue.Length - 1);
                else
                    ParamValue = null;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_CreateBatch";
                cmd.Parameters.Add("@CourseId", SqlDbType.Int).Value = _Batch.CourseId;
                cmd.Parameters.Add("@StaffName", SqlDbType.VarChar).Value = _Batch.StaffName;
                cmd.Parameters.Add("@BatchStartDate", SqlDbType.VarChar).Value = _Batch.BatchStartDate;
                cmd.Parameters.Add("@BatchTime", SqlDbType.VarChar).Value = _Batch.BatchTime;
                cmd.Parameters.Add("@SingleValStudents", SqlDbType.VarChar).Value = ParamValue;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_Batches> GetBatchDetails()
        {
            try
            {
                List<SE_Batches> _Rec = new List<SE_Batches>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_BatchDetails", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Batches
                        {
                            BatchId = Convert.ToString(dr["BatchId"]),
                            BatchCode = Convert.ToString(dr["BatchCode"]),
                            CourseId = Convert.ToInt32(dr["CourseId"]),
                            CourseDesc = Convert.ToString(dr["CourseDesc"]),
                            FullDateTime = dr["FullDateTime"].ToString(),
                            NumOfStudents = Convert.ToInt32(dr["NumOfStudents"])
                        });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_Batches> EditBatchDetails(int CDID)
        {
            try
            {
                List<SE_Batches> _Rec = new List<SE_Batches>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_BatchDetailsById", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@BatchId", CDID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Batches
                        {
                            BatchId = Convert.ToString(dr["BatchId"]),
                            BatchCode = Convert.ToString(dr["BatchCode"]),
                            CourseId = Convert.ToInt32(dr["CourseId"]),
                            CourseDesc = Convert.ToString(dr["CourseDesc"]),
                            StaffName = Convert.ToString(dr["StaffName"]),
                            BatchStartDate = Convert.ToDateTime(dr["BatchStartDate"]),
                            BatchTime = Convert.ToString(dr["BatchTime"]),
                            AssignedStudents = GetAssignedStudents(_Result)
                        });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<string> GetAssignedStudents(DataSet _Result)
        {
            List<string> str = new List<string>();
            if (_Result.Tables[1].Rows.Count > 0)
                foreach (DataRow dr in _Result.Tables[1].Rows)
                {
                    str.Add(AES_Algorithm.DecryptString(Convert.ToString(dr["FirstName"])) + " " + AES_Algorithm.DecryptString(Convert.ToString(dr["LastName"])) + " (" + StringEncrypt.Decrypt(Convert.ToString(dr["Email"])) + ")");
                }

            return str;
        } // From EditBatchDetails
        public int UpdateBatchDetails(SE_Batches _Batch)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                var routes_list = (dynamic)json_serializer.DeserializeObject(_Batch.SingleValStudents);

                string ParamValue = string.Empty;
                foreach (var val in routes_list)
                    ParamValue += StringEncrypt.Encrypt(val.Split(new Char[] { '(', ')' })[1]) + ",";

                if (ParamValue != "")
                    ParamValue = ParamValue.Remove(ParamValue.Length - 1);
                else
                    ParamValue = null;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Update_BatchDetails";
                cmd.Parameters.Add("@BatchId", SqlDbType.Int).Value = Convert.ToInt32(RSAPattern.Decrypt(_Batch.BatchId));
                cmd.Parameters.Add("@StaffName", SqlDbType.VarChar).Value = _Batch.StaffName;
                cmd.Parameters.Add("@BatchStartDate", SqlDbType.VarChar).Value = _Batch.BatchStartDate;
                cmd.Parameters.Add("@BatchTime", SqlDbType.VarChar).Value = _Batch.BatchTime;
                cmd.Parameters.Add("@SingleValStudents", SqlDbType.VarChar).Value = ParamValue;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteBatch(string ID)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_Batch";
                cmd.Parameters.Add("@ID", SqlDbType.VarChar).Value = ID;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
    }
}