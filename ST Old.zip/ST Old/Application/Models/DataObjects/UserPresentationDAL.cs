﻿using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class UserPresentationDAL : DataAccessComponent
    {
        public int InsertForms(SE_Forms _Data)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_Forms";
                cmd.Parameters.Add("@FormType", SqlDbType.VarChar).Value = _Data.FormType;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = _Data.Name;
                cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = _Data.Email;
                cmd.Parameters.Add("@Mobile", SqlDbType.VarChar).Value = _Data.Mobile;
                cmd.Parameters.Add("@Course", SqlDbType.VarChar).Value = _Data.Course;
                cmd.Parameters.Add("@Message", SqlDbType.VarChar).Value = _Data.Message;

                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                return 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<int> SearchCourse(string Course)
        {
            try
            {
                List<int> _Rec = new List<int>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"SELECT CourseId FROM [StepTekDB].[tbl_Course] WHERE Title = @Course";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Course", Convert.ToString(Course));
                        da.Fill(_Result);
                    }
                }
                _Rec.Add(Convert.ToInt32(_Result.Tables[0].Rows[0][0]));
                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_UserCourses> GetPopularCourses()
        {
            try
            {
                List<SE_UserCourses> _Rec = new List<SE_UserCourses>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_PopularCourses", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_UserCourses { CategoryId = Convert.ToInt32(dr["CategoryId"]), CategoryDesc = Convert.ToString(dr["CategoryDesc"]), CourseId = Convert.ToInt32(dr["CourseId"]), CourseTitle = Convert.ToString(dr["CourseTitle"]), CourseDesc = dr["CourseDesc"].ToString(), Currency = dr["Currency"].ToString(), Price = dr["Price"].ToString(), Ratting = Convert.ToInt32(dr["Ratting"]), Duration = Convert.ToInt32(dr["Duration"]), NumOfClasses = Convert.ToInt32(dr["NumOfClasses"]), Image = dr["Image"].ToString(), Concepts = dr["Concepts"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_UserCourses> GetAllCourses()
        {
            try
            {
                List<SE_UserCourses> _Rec = new List<SE_UserCourses>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_UserAllCourses", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_UserCourses { CategoryId = Convert.ToInt32(dr["CategoryId"]), CategoryDesc = Convert.ToString(dr["CategoryDesc"]), CourseId = Convert.ToInt32(dr["CourseId"]), CourseTitle = Convert.ToString(dr["CourseTitle"]), CourseDesc = dr["CourseDesc"].ToString(), Currency = dr["Currency"].ToString(), Price = dr["Price"].ToString(), Ratting = Convert.ToInt32(dr["Ratting"]), Duration = Convert.ToInt32(dr["Duration"]), NumOfClasses = Convert.ToInt32(dr["NumOfClasses"]), Image = dr["Image"].ToString(), Concepts = dr["Concepts"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_UserCourses> GetCourseById(string CourseId)
        {
            try
            {
                List<SE_UserCourses> _Rec = new List<SE_UserCourses>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_CourseById", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@CourseId", Convert.ToInt32(CourseId));
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_UserCourses { CategoryId = Convert.ToInt32(dr["CategoryId"]), CategoryDesc = Convert.ToString(dr["CategoryDesc"]), CourseId = Convert.ToInt32(dr["CourseId"]), CourseTitle = Convert.ToString(dr["CourseTitle"]), CourseDesc = dr["CourseDesc"].ToString(), Currency = dr["Currency"].ToString(), Price = dr["Price"].ToString(), Ratting = Convert.ToInt32(dr["Ratting"]), Duration = Convert.ToInt32(dr["Duration"]), NumOfClasses = Convert.ToInt32(dr["NumOfClasses"]), Image = dr["Image"].ToString(), Concepts = dr["Concepts"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}