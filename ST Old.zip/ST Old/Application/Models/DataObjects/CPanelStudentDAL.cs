﻿using Application.App_Start;
using Application.Helper;
using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;

namespace Application.Models.DataObjects
{
    public class CPanelStudentDAL : DataAccessComponent
    {
        public SE_StudentDashboard GetStudentDashboard(int UID)
        {
            try
            {
                SE_StudentDashboard _Rec = new SE_StudentDashboard();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_StudentWidgets", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@UserId", UID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                    {
                        _Rec.SelectedCourses = Convert.ToInt32(dr["SelectedCourses"]);
                        _Rec.Materials = Convert.ToInt32(dr["Materials"]);
                        _Rec.VideoRecordings = Convert.ToInt32(dr["VideoRecordings"]);
                        _Rec.TotalAvlCourses = Convert.ToInt32(dr["TotalAvlCourses"]);
                        List<SE_Batches> _Data = new List<SE_Batches>();
                        if (_Result.Tables[1].Rows.Count > 0)
                        {
                            foreach (DataRow drInner in _Result.Tables[1].Rows)
                            {
                                SE_Batches _Val = new SE_Batches();
                                _Val.BatchCode = Convert.ToString(drInner["BatchCode"]);
                                _Val.CourseDesc = Convert.ToString(drInner["CourseDesc"]);
                                _Val.CourseCategory = Convert.ToString(drInner["CourseCategory"]);
                                _Val.FullDateTime = Convert.ToString(drInner["FullDateTime"]);
                                _Val.CourseImage = Convert.ToString(drInner["Image"]);
                                _Data.Add(_Val);
                            }
                        }
                        _Rec.CourseBatch = _Data;
                    }

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_RefValues> StudentsBatchList(int _Id)
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                        SELECT 
	                                        BS.BatchId,
	                                        B.BatchCode 
                                        FROM [StepTekDB].[tbl_BatchStudents] BS
                                        INNER JOIN [StepTekDB].[tbl_Batches] B ON BS.BatchId = B.BatchId
                                        WHERE BS.StudentId = @UID";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@UID", _Id);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["BatchId"]), Description = dr["BatchCode"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_Uploads> GetStudentBatchVideos(string UID, string BatchId)
        {
            try
            {
                List<SE_Uploads> _Rec = new List<SE_Uploads>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                            SELECT 
                                                VR.VideoRecId,
                                            	BS.BatchId,
                                            	BS.StudentId,
                                            	VR.VideoPath,
                                                VR.Createddate
                                            FROM [StepTekDB].[tbl_BatchStudents] BS 
                                            INNER JOIN [StepTekDB].[tbl_VideoRecording] VR ON VR.BatchId = BS.BatchId 
                                            WHERE BS.StudentId = @UID AND BS.BatchId = @BatchId 
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.SelectCommand.Parameters.AddWithValue("@BatchId", BatchId);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                    {
                        DateTime dt = Convert.ToDateTime(dr["Createddate"]);
                        var day = dt.Day;
                        var month = dt.ToString("MMMM");
                        var year = dt.Year;
                        var hour = dt.ToString("hh");
                        var min = dt.ToString("mm");
                        var tt = dt.ToString("tt", CultureInfo.InvariantCulture);
                        var displayDate = day + " " + month + " " + year + ", " + hour + ":" + min + " " + tt;
                        _Rec.Add(new SE_Uploads { Id = Convert.ToString(dr["VideoRecId"]), BatchId = Convert.ToString(dr["BatchId"]), Url = StringEncrypt.Decrypt(dr["VideoPath"].ToString()), UploadedDate = displayDate });
                    }

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_Uploads> GetStudentCourseMaterial(string UID, string BatchId)
        {
            try
            {
                List<SE_Uploads> _Rec = new List<SE_Uploads>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                            SELECT 
                                                CM.MaterialId,
                                                B.CourseId,
                                                CM.[FileName],
                                                CM.CreatedDate
                                            FROM [StepTekDB].[tbl_BatchStudents] BS 
                                            INNER JOIN [StepTekDB].[tbl_Batches] B ON B.BatchId = BS.BatchId 
                                            INNER JOIN [StepTekDB].[tbl_CourseMaterial] CM ON CM.CourseId = B.CourseId
                                            WHERE BS.StudentId = @UID AND BS.BatchId = @BatchId 
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.SelectCommand.Parameters.AddWithValue("@BatchId", BatchId);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                    {
                        DateTime dt = Convert.ToDateTime(dr["Createddate"]);
                        var day = dt.Day;
                        var month = dt.ToString("MMMM");
                        var year = dt.Year;
                        var hour = dt.ToString("hh");
                        var min = dt.ToString("mm");
                        var tt = dt.ToString("tt", CultureInfo.InvariantCulture);
                        var displayDate = day + " " + month + " " + year + ", " + hour + ":" + min + " " + tt;

                        _Rec.Add(new SE_Uploads { Id = Convert.ToString(dr["MaterialId"]), CourseId = Convert.ToString(dr["CourseId"]), FileName = StringEncrypt.Decrypt(dr["FileName"].ToString()), UploadedDate = displayDate });
                    }

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}