﻿using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class SharedDAL : DataAccessComponent
    {
        public string GetSaltKeyByEmail(string _Email)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT SaltKey FROM [StepTekDB].[tbl_Users] WHERE Email = @Email", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Email", _Email);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToString(_Result.Tables[0].Rows[0]["SaltKey"]);
                else
                    return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string GetSaltKeyById(string _Id)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT SaltKey FROM [StepTekDB].[tbl_Users] WHERE UserId = @ID", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@ID", _Id);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToString(_Result.Tables[0].Rows[0]["SaltKey"]);
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_RefValues> GetCountries()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [StepTekDB].[Ref_Countries]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["CountryId"]), Code = dr["Code"].ToString(), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_RefValues> GetStates()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT * FROM [StepTekDB].[Ref_States]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }


                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["StateId"]), Code = dr["Code"].ToString(), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_RefValues> RolesList()
        {
            try
            {
                List<SE_RefValues> _Rec = new List<SE_RefValues>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT RoleId, [Description] FROM [StepTekDB].[Ref_Roles]", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_RefValues { Id = Convert.ToInt32(dr["RoleId"]), Description = dr["Description"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}