﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_Forms
    {
        public string FormId { get; set; }
        public string FormType { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Course { get; set; }
        public string Message { get; set; }
    }
}