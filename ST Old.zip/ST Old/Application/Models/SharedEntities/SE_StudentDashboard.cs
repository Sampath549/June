﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_StudentDashboard
    {
        public int SelectedCourses { get; set; }
        public int Materials { get; set; }
        public int VideoRecordings { get; set; }
        public int TotalAvlCourses { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public List<SE_Batches> CourseBatch { get; set; }
    }
}