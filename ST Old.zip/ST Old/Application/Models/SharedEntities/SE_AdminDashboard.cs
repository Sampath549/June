﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_AdminDashboard
    {
        public int RequestForm { get; set; }
        public int ManualForm { get; set; }
        public int ContactForm { get; set; }
        public int RegisterdStudents { get; set; }
    }
}