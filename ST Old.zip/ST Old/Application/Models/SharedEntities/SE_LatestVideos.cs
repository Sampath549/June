﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_LatestVideos
    {
        public int LVId { get; set; }
        public string LVTitle { get; set; }
        public string LVDesc { get; set; }
        public string LVUrl { get; set; }
        public string LVImage { get; set; }
        public string DateNumber { get; set; }
    }
}