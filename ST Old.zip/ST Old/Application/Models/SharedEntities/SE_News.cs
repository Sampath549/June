﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_News
    {
        public int NewsId { get; set; }
        public string NewsTitle { get; set; }
        public string NewsDesc { get; set; }
        public string Image { get; set; }
        public string FullDate { get; set; }
    }
}