﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_UpcomingClasses
    {
        public int UCId { get; set; }
        public string UCTitle { get; set; }
        public string UCCategory { get; set; }
        public string DateNumber { get; set; }
        public string FullDate { get; set; }
    }
}