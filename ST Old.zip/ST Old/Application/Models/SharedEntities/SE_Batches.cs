﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_Batches
    {
        public string BatchId { get; set; }
        public string BatchCode { get; set; }
        public int CourseId { get; set; }
        public string CourseDesc { get; set; }
        public string CourseCategory { get; set; }
        public string StaffName { get; set; }
        public DateTime BatchStartDate { get; set; }
        public string OnlyBatchStartDate { get; set; }
        public string BatchTime { get; set; }
        public string FullDateTime { get; set; }
        public int NumOfStudents { get; set; }
        public string CourseImage { get; set; }
        public string SingleValStudents { get; set; }
        public List<SE_Students> StudentsList { get; set; }
        public List<string> AssignedStudents { get; set; }
    }

    public class SE_Students
    {
        public int StudentId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
    }
}