﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_Uploads
    {
        public string Id { get; set; }
        public string Type { get; set; }
        public string CourseId { get; set; }
        public string CourseDesc { get; set; }
        public string BatchId { get; set; }
        public string BatchCode { get; set; }
        public string FileName { get; set; }
        public string FileExt { get; set; }
        public string Url { get; set; }
        public string UploadedDate { get; set; }
    }
}