﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_UserCourses
    {
        public int CategoryId { get; set; }
        public string CategoryDesc { get; set; }
        public int CourseId { get; set; }
        public string CourseTitle { get; set; }
        public string CourseDesc { get; set; }
        public string Currency { get; set; }
        public string Price { get; set; }
        public int Ratting { get; set; }
        public int Duration { get; set; }
        public int NumOfClasses { get; set; }
        public string Image { get; set; }
        public string Concepts { get; set; }
    }
}