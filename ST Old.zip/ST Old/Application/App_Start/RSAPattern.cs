﻿using Application.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.IO;

namespace Application.App_Start
{
    public static class RSAPattern
    {
        public static string Encrypt(string Value)
        {
            return RSAMessageEncryption(Value);
        }
        public static string Decrypt(string Value)
        {
            return RSAMessageDecrypt(Value);
        }
        private static string RSAMessageEncryption(string strChipertext)
        {
            var csp = new RSACryptoServiceProvider(1024);
            csp = new RSACryptoServiceProvider(1024);
            csp.FromXmlString(GlobalVariables.Shared.PublicKey);
            var bytesPlainTextData = System.Text.Encoding.Unicode.GetBytes(strChipertext);
            var bytesCypherText = csp.Encrypt(bytesPlainTextData, false);
            var cypherText = Convert.ToBase64String(bytesCypherText);
            return cypherText;
        }
        private static string RSAMessageDecrypt(string strEncryption)
        {
            string decryptedString = string.Empty;
            var csp = new RSACryptoServiceProvider(1024);
            csp = new RSACryptoServiceProvider(1024);
            csp.FromXmlString(GlobalVariables.Shared.PrivateKey);
            string data2Decrypt = strEncryption;
            data2Decrypt = data2Decrypt.Replace(" ", "+");
            byte[] encyrptedBytes = Convert.FromBase64String(data2Decrypt);
            byte[] plain = csp.Decrypt(encyrptedBytes, false);
            decryptedString = System.Text.Encoding.UTF8.GetString(plain);
            if (decryptedString.Contains("\0"))
            {
                decryptedString = decryptedString.Replace("\0", "");
            }
            return decryptedString;
        }

        // Method to encrypte a string data and save it in a specific file using an AES algorithm  
        public static string SymmetricEncrypt(SymmetricAlgorithm aesAlgorithm, string text)
        {
            // Create an encryptor from the AES algorithm instance and pass the aes algorithm key and inialiaztion vector to generate a new random sequence each time for the same text  
            ICryptoTransform encryptor = aesAlgorithm.CreateEncryptor(aesAlgorithm.Key, aesAlgorithm.IV);

            // Create a memory stream to save the encrypted data in it  
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                {
                    using (StreamWriter writer = new StreamWriter(cs))
                    {
                        // Write the text in the stream writer   
                        writer.Write(text);
                    }
                }

                // Get the result as a byte array from the memory stream   
                byte[] encryptedDataBuffer = ms.ToArray();
                var cypherText = Convert.ToBase64String(encryptedDataBuffer);
                return cypherText;
                // Write the data to a file   
                //File.WriteAllBytes(fileName, encryptedDataBuffer);
            }
        }

        // Method to decrypt a data from a specific file and return the result as a string   
        public static string SymmetricDecrypt(SymmetricAlgorithm aesAlgorithm, string data)
        {
            // Create a decryptor from the aes algorithm   
            //ICryptoTransform decryptor = aesAlgorithm.CreateDecryptor(aesAlgorithm.Key, aesAlgorithm.IV);

            // Read the encrypted bytes from the file   
            byte[] cipherText = Convert.FromBase64String(data);
            string plaintext = null;

            // Create an AesManaged object
            // with the specified key and IV.
            using (AesManaged aesAlg = new AesManaged())
            {
                // Create a decrytor to perform the stream transform.
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
                aesAlg.Padding = PaddingMode.Zeros;
                // Create the streams used for decryption.
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {

                            // Read the decrypted bytes from the decrypting stream
                            // and place them in a string.
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }

            }

            return plaintext;

            //// Create a memorystream to write the decrypted data in it   
            //using (MemoryStream ms = new MemoryStream(encryptedDataBuffer))
            //{
            //    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
            //    {
            //        using (StreamReader reader = new StreamReader(cs))
            //        {
            //            // Reutrn all the data from the streamreader   
            //            return reader.ReadToEnd();
            //        }
            //    }
            //}
        }
    }
}