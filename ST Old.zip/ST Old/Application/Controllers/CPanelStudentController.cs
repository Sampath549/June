﻿using Application.App_Start;
using Application.Filters;
using Application.Helper;
using Application.Models.SharedEntities;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    [MVCSessionFilter, MVCStudentAuthorization]
    public class CPanelStudentController : Controller
    {
        public ActionResult Dashboard()
        {
            try
            {
                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_SessionUserDetails.UserId.ToString()));
                string _Data = ApiHelper.PostData_Json("api/CPanelStudent/GetStudentDashboard?Values=", _Array);
                Result<SE_StudentDashboard> _Result = JsonConvert.DeserializeObject<Result<SE_StudentDashboard>>(_Data);
                _Result.Data.FirstName = _SessionUserDetails.FirstName;
                _Result.Data.LastName = _SessionUserDetails.LastName;
                _Result.Data.Email = _SessionUserDetails.Email;
                _Result.Data.Mobile = _SessionUserDetails.Mobile;

                return View(_Result.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        public ActionResult StudentMaterial()
        {
            try
            {
                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                ViewBag.Batch_dll = Reusable.StudentsBatchList(_SessionUserDetails.UserId); // All Batches

                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult StudentMaterial(string BatchId)
        {
            List<SE_Uploads> _Uploads = new List<SE_Uploads>();
            try
            {
                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                ViewBag.Batch_dll = Reusable.StudentsBatchList(_SessionUserDetails.UserId); // All Batches

                _Uploads = StudentMaterial(_SessionUserDetails.UserId, BatchId.ToString());

                return Json(new { _Result = _Uploads }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private List<SE_Uploads> StudentMaterial(int UID, string BatchId)
        {
            List<SE_Uploads> _Uploads = new List<SE_Uploads>();
            try
            {
                //API Calls
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(UID.ToString()));
                _Array.Add(RSAPattern.Encrypt(BatchId.ToString()));

                string _Data = ApiHelper.PostData_Json("api/CPanelStudent/GetStudentCourseMaterial?Values=", _Array);
                Result<List<SE_Uploads>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Uploads>>>(_Data);
                return _Result.Data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DownloadFile(string CID, string FName)
        {
            try
            {
                string fileName = CID + " ^_^ " + FName;
                string _Path = Server.MapPath("~/Uploads/Documents/");

                string file = Path.Combine(_Path, fileName);
                if (System.IO.File.Exists(file))
                    return Json(new Result(true, 200, fileName, null), JsonRequestBehavior.AllowGet);
                else
                    return Json(new Result(false, 500, GlobalVariables.Shared.ErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(true, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult StudentVideos()
        {
            try
            {
                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                ViewBag.Batch_dll = Reusable.StudentsBatchList(_SessionUserDetails.UserId); // All Batches

                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult StudentVideos(string BatchId)
        {
            List<SE_Uploads> _Uploads = new List<SE_Uploads>();
            try
            {
                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                ViewBag.Batch_dll = Reusable.StudentsBatchList(_SessionUserDetails.UserId); // All Batches

                _Uploads = StudentVideos(_SessionUserDetails.UserId, BatchId.ToString());

                return Json(new { _Result = _Uploads }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private List<SE_Uploads> StudentVideos(int UID, string BatchId)
        {
            List<SE_Uploads> _Uploads = new List<SE_Uploads>();
            try
            {
                //API Calls
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(UID.ToString()));
                _Array.Add(RSAPattern.Encrypt(BatchId.ToString()));

                string _Data = ApiHelper.PostData_Json("api/CPanelStudent/GetStudentBatchVideos?Values=", _Array);
                Result<List<SE_Uploads>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Uploads>>>(_Data);
                return _Result.Data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}