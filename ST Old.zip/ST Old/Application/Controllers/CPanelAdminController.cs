﻿using Application.App_Start;
using Application.Filters;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace Application.Controllers
{
    [MVCSessionFilter, MVCAdminAuthorization]
    public class CPanelAdminController : Controller
    {
        public ActionResult Dashboard()
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus

                //API Call		
                ArrayList _Array = new ArrayList();
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/Dashboard?Values=", _Array);
                Result<SE_AdminDashboard> _Result = JsonConvert.DeserializeObject<Result<SE_AdminDashboard>>(response);
                return View(_Result.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        #region  Forms
        public ActionResult RequestForms()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult CreateManualForm()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult ContactUsForm()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetForms(string _FormType)
        {
            List<SE_Forms> _list = new List<SE_Forms>();
            try
            {
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_FormType));
                string _UsersData = ApiHelper.PostData_Json("api/CPanelAdmin/GetForms?Values=", _Array);
                Result<List<SE_Forms>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Forms>>>(_UsersData);
                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.FormId),
                                 Convert.ToString(AES_Algorithm.DecryptString(c.FormType)),
                                 Convert.ToString((AES_Algorithm.DecryptString(c.Name))),
                                 Convert.ToString((StringEncrypt.Decrypt(c.Email))),
                                 Convert.ToString((StringEncrypt.Decrypt(c.Mobile))),
                                 Convert.ToString((AES_Algorithm.DecryptString(c.Course))),
                                 Convert.ToString((AES_Algorithm.DecryptString(c.Message)))
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [CSRF_AntiForgeryToken]
        public ActionResult ViewForms(string Id)
        {
            ArrayList _Array = new ArrayList();
            _Array.Add(RSAPattern.Encrypt(Id));
            string _UsersData = ApiHelper.PostData_Json("api/CPanelAdmin/GetFormsById?Values=", _Array);
            Result<SE_Forms> _Result = JsonConvert.DeserializeObject<Result<SE_Forms>>(_UsersData);
            SE_Forms model = new SE_Forms();
            model.Name = AES_Algorithm.DecryptString(_Result.Data.Name);
            model.Email = StringEncrypt.Decrypt(_Result.Data.Email);
            model.Mobile = StringEncrypt.Decrypt(_Result.Data.Mobile);
            model.Course = AES_Algorithm.DecryptString(_Result.Data.Course);
            model.Message = AES_Algorithm.DecryptString(_Result.Data.Message);

            try
            {
                ViewBag.Caption = "View Record";
                ViewBag.DisplayBtn = false;
                return View("../PartialViews/AddFormsSideBar", model);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [CSRF_AntiForgeryToken]
        public ActionResult AddManualForms()
        {
            SE_Forms model = new SE_Forms();
            try
            {
                ViewBag.Caption = "Add Record";
                ViewBag.DisplayBtn = true;
                return View("../PartialViews/AddFormsSideBar", model);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CreateManualForm(SE_Forms _Forms)
        {
            try
            {
                //Server-Side Validations
                if (_Forms.Name == null || Sanitizer.GetSafeHtmlFragment(_Forms.Name) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Forms.Name), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_Forms.Name).Length > 100)
                    return Json(new Result(false, 500, "Validation Error", "Name should not be Empty and must contain only Alphabets"), JsonRequestBehavior.AllowGet);
                if (_Forms.Email == null || Sanitizer.GetSafeHtmlFragment(_Forms.Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Forms.Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_Forms.Email).Length > 100)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format"), JsonRequestBehavior.AllowGet);
                if (_Forms.Mobile == null || Sanitizer.GetSafeHtmlFragment(_Forms.Mobile) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Forms.Mobile), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_Forms.Mobile).Length > 15)
                    return Json(new Result(false, 500, "Validation Error", "Mobile should not be Empty and must contain only Numbers"), JsonRequestBehavior.AllowGet);
                if (_Forms.Course == null || Sanitizer.GetSafeHtmlFragment(_Forms.Course) == "" || Sanitizer.GetSafeHtmlFragment(_Forms.Course).Length > 150)
                    return Json(new Result(false, 500, "Validation Error", "Course should not be Empty"), JsonRequestBehavior.AllowGet);
                if (_Forms.Message == null || Sanitizer.GetSafeHtmlFragment(_Forms.Message) == "" || Sanitizer.GetSafeHtmlFragment(_Forms.Message).Length > 300)
                    return Json(new Result(false, 500, "Validation Error", "Message should not be Empty and must contain only Alphabets with Maximum of 300 characters"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                SE_Forms _Data = new SE_Forms();
                _Data.Name = RSAPattern.Encrypt(_Forms.Name);
                _Data.Email = RSAPattern.Encrypt(_Forms.Email.ToLower());
                _Data.Mobile = RSAPattern.Encrypt(_Forms.Mobile);
                _Data.Course = RSAPattern.Encrypt(_Forms.Course);
                _Data.Message = RSAPattern.Encrypt(_Forms.Message);

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(_Data);
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/CreateManualForms?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Student Details
        public ActionResult CreateStudent()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CreateStudents(SE_Users _User)
        {
            SE_Users Users = new SE_Users();
            try
            {
                //Server-Side Validations
                if (_User.FirstName == null || Sanitizer.GetSafeHtmlFragment(_User.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "First Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.LastName == null || Sanitizer.GetSafeHtmlFragment(_User.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Last Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Email == null || Sanitizer.GetSafeHtmlFragment(_User.Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Email).Length > 75)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format with max of 75 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Mobile == null || Sanitizer.GetSafeHtmlFragment(_User.Mobile) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Mobile), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Mobile).Length != 10)
                    return Json(new Result(false, 500, "Validation Error", "Mobile should not be Empty and must contain only Numbers with 10 digits"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                Users = new SE_Users();
                Users.FirstName = RSAPattern.Encrypt(_User.FirstName);
                Users.LastName = RSAPattern.Encrypt(_User.LastName);
                Users.Email = RSAPattern.Encrypt(_User.Email.ToLower());
                Users.Mobile = RSAPattern.Encrypt(_User.Mobile);
                Users.RoleIdVal = RSAPattern.Encrypt(GlobalVariables.Shared.StudentRoleId.ToString());

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Users);
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/CreateAllUsers?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                if (_Result.Status)
                    SessionHandler.SessionStudentsList = null;

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetStudentDetails()
        {
            List<SE_Users> _list = new List<SE_Users>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _UsersData = ApiHelper.PostData_Json("api/CPanelAdmin/GetStudentDetails?Values=", _Array);
                Result<List<SE_Users>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Users>>>(_UsersData);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.UserId),
                                 Convert.ToString(AES_Algorithm.DecryptString(c.FirstName) + " " + AES_Algorithm.DecryptString(c.LastName)),
                                 Convert.ToString(AES_Algorithm.DecryptString(c.FirstName)),
                                 Convert.ToString((AES_Algorithm.DecryptString(c.LastName))),
                                 Convert.ToString((StringEncrypt.Decrypt(c.Email))),
                                 Convert.ToString((StringEncrypt.Decrypt(c.Mobile))),
                                 Convert.ToString(c.RoleDesc),
                                 Convert.ToString(c.IsActive),
                                 Convert.ToString(c.Batches != "" ? c.Batches : "- NA -"),
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [CSRF_AntiForgeryToken]
        public ActionResult EditStudentDetails(int id)
        {
            SE_Users model = new SE_Users();
            try
            {
                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(id.ToString()));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/EditStudentDetails?Values=", _Array);
                Result<SE_Users> _Result = JsonConvert.DeserializeObject<Result<SE_Users>>(response);

                if (_Result.Status)
                {
                    model.UserId = _Result.Data.UserId;
                    model.FullName = AES_Algorithm.DecryptString(_Result.Data.FirstName) + " " + AES_Algorithm.DecryptString(_Result.Data.LastName);
                    model.FirstName = AES_Algorithm.DecryptString(_Result.Data.FirstName);
                    model.LastName = AES_Algorithm.DecryptString(_Result.Data.LastName);
                    model.Email = StringEncrypt.Decrypt(_Result.Data.Email);
                    model.Mobile = StringEncrypt.Decrypt(_Result.Data.Mobile);
                    model.RoleId = _Result.Data.RoleId;
                    model.RoleDesc = _Result.Data.RoleDesc;
                    model.IsActive = _Result.Data.IsActive;
                    model.Batches = _Result.Data.Batches != "" ? _Result.Data.Batches : "- NA -";
                }

                return View("../PartialViews/StudentDetailsSideBar", model);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult UpdateStudentDetails(SE_Users _User)
        {
            SE_Users Users = new SE_Users();
            try
            {
                //Server-Side Validations
                if (_User.FirstName == null || Sanitizer.GetSafeHtmlFragment(_User.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "First Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.LastName == null || Sanitizer.GetSafeHtmlFragment(_User.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Last Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                Users = new SE_Users();
                Users.UserId = _User.UserId;
                Users.FirstName = RSAPattern.Encrypt(_User.FirstName);
                Users.LastName = RSAPattern.Encrypt(_User.LastName);
                Users.IsActive = _User.IsActive;

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Users);
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/UpdateStudentDetails?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                if (_Result.Status)
                    SessionHandler.SessionStudentsList = null;

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Uploads
        public ActionResult UploadDocuments()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            ViewBag.Course_dll = Reusable.CourseList(); // All Courses
            return View();
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult UploadDocuments(string _Empty)
        {
            try
            {
                SE_Uploads _Upload = new SE_Uploads();
                if (Request.Files.Count > 0)
                {
                    var file = Request.Files[0];
                    string _FileName = Path.GetFileName(file.FileName);
                    string _FileExtention = Path.GetExtension(_FileName);
                    if (_FileExtention == ".pdf")
                    {
                        _Upload.FileName = _FileName;
                        _Upload.FileExt = _FileExtention;
                        _Upload.CourseId = int.Parse(Request.Form["CourseId"]).ToString();

                        //API Call		
                        ArrayList _Array = new ArrayList();
                        _Array.Add(RSAPattern.Encrypt(_Upload.CourseId));
                        _Array.Add(RSAPattern.Encrypt(_Upload.FileName));
                        _Array.Add(RSAPattern.Encrypt(_Upload.FileExt));

                        string response = ApiHelper.PostData_Json("api/CPanelAdmin/UploadDocuments?Values=", _Array);
                        Result _Result = JsonConvert.DeserializeObject<Result>(response);
                        if (_Result.Status)
                        {
                            string _Path = Path.Combine(Server.MapPath("~/Uploads/Documents/"), _Upload.CourseId + " ^_^ " + _FileName);
                            file.SaveAs(_Path);
                        }
                        return Json(_Result, JsonRequestBehavior.AllowGet);
                    }
                    else
                        return Json(new Result(false, 500, "No File Exists", null), JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new Result(false, 500, "Upload Only PDF Files", null), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetUploadedDocuments()
        {
            List<SE_Uploads> _list = new List<SE_Uploads>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Data = ApiHelper.PostData_Json("api/CPanelAdmin/GetUploadedDocuments?Values=", _Array);
                Result<List<SE_Uploads>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Uploads>>>(_Data);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.Id),
                                 Convert.ToString(c.CourseId),
                                 Convert.ToString(c.CourseDesc),
                                 Convert.ToString(StringEncrypt.Decrypt(c.FileName)),
                                 Convert.ToString(StringEncrypt.Decrypt(c.FileExt))
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DownloadFile(string CID, string FName)
        {
            try
            {
                string fileName = CID + " ^_^ " + FName;
                string _Path = Server.MapPath("~/Uploads/Documents/");

                string file = Path.Combine(_Path, fileName);
                if (System.IO.File.Exists(file))
                    return Json(new Result(true, 200, fileName, null), JsonRequestBehavior.AllowGet);
                else
                    return Json(new Result(false, 500, GlobalVariables.Shared.ErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(true, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteFile(string MID, string CID, string FName)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(MID));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/DeleteFile?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                if (_Result.Status)
                {
                    string fileName = CID + " ^_^ " + FName;
                    string _Path = Server.MapPath("~/Uploads/Documents/");
                    string file = Path.Combine(_Path, fileName);
                    if (System.IO.File.Exists(file))
                        System.IO.File.Delete(file);
                }
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult UploadVideos()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            ViewBag.Batch_dll = Reusable.BatchList(); // All Batches
            return View();
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult UploadVideos(SE_Uploads _Video)
        {
            try
            {
                //Server-Side Validation
                if (Sanitizer.GetSafeHtmlFragment(_Video.BatchId.ToString()) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Video.BatchId.ToString()), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Batch"), JsonRequestBehavior.AllowGet);
                if (Sanitizer.GetSafeHtmlFragment(_Video.Url) == null || Sanitizer.GetSafeHtmlFragment(_Video.Url) == "")
                    return Json(new Result(false, 500, "Validation Error", "Url should not be Empty"), JsonRequestBehavior.AllowGet);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_Video.BatchId.ToString()));
                _Array.Add(RSAPattern.Encrypt(_Video.Url));

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/UploadVideos?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetUploadedVideos()
        {
            List<SE_Uploads> _list = new List<SE_Uploads>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Data = ApiHelper.PostData_Json("api/CPanelAdmin/GetUploadedVideos?Values=", _Array);
                Result<List<SE_Uploads>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Uploads>>>(_Data);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.Id),
                                 Convert.ToString(c.BatchId),
                                 Convert.ToString(c.BatchCode),
                                 Convert.ToString(StringEncrypt.Decrypt(c.Url)),
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteVideo(string VRID)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(VRID));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/DeleteVideo?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Course Category
        public ActionResult CourseCategory()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetCourseCategory()
        {
            List<SE_RefValues> _list = new List<SE_RefValues>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Data = ApiHelper.PostData_Json("api/CPanelAdmin/GetCourseCategory?Values=", _Array);
                Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Data);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.Id),
                                 Convert.ToString(c.Code),
                                 Convert.ToString(c.Description)
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertUpdateCourseCategory(string Code, string Description, string ButtonType)
        {
            try
            {
                if (ButtonType == "Save")
                {
                    if (Code == null || Sanitizer.GetSafeHtmlFragment(Code) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Code), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Code).Length > 5 || Sanitizer.GetSafeHtmlFragment(Code).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Code should not be Empty and must contain only Alphabets with Min of 2 & Max of 5 characters"), JsonRequestBehavior.AllowGet);
                    if (Description == null || Sanitizer.GetSafeHtmlFragment(Description) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Description), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Description).Length > 25 || Sanitizer.GetSafeHtmlFragment(Description).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain only Alphabets with Min of 2 & Max of 30 characters"), JsonRequestBehavior.AllowGet);
                }
                else if (ButtonType == "Update")
                {
                    if (Description == null || Sanitizer.GetSafeHtmlFragment(Description) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Description), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Description).Length > 25 || Sanitizer.GetSafeHtmlFragment(Description).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain only Alphabets with Min of 2 & Max of 30 characters"), JsonRequestBehavior.AllowGet);
                }

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(Code));
                _Array.Add(RSAPattern.Encrypt(Description));
                _Array.Add(RSAPattern.Encrypt(ButtonType));

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/InsertUpdateCourseCategory?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteCourseCategory(string Code)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(Code));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/DeleteCourseCategory?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Creating Course
        public ActionResult CreateCourse()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            ViewBag.CCategory_dll = Reusable.CourseCategoryList(); // All Categories
            return View();
        }

        public JsonResult GetCourse()
        {
            List<SE_Course> _list = new List<SE_Course>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Data = ApiHelper.PostData_Json("api/CPanelAdmin/GetCourse?Values=", _Array);
                Result<List<SE_Course>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Course>>>(_Data);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.CourseId),
                                 Convert.ToString(c.CategoryId),
                                 Convert.ToString(c.CategoryDesc),
                                 Convert.ToString(c.Title),
                                 Convert.ToString(c.Desc)
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CreateCourse(SE_Course _Course)
        {
            try
            {
                //Server-Side Validation
                if (_Course.btnType == "Save")
                {
                    if (Sanitizer.GetSafeHtmlFragment(_Course.CategoryId.ToString()) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Course.CategoryId.ToString()), @"^[0-9]+$") == false)
                        return Json(new Result(false, 500, "Validation Error", "Please Select Category"), JsonRequestBehavior.AllowGet);
                    if (Sanitizer.GetSafeHtmlFragment(_Course.Title) == null || Sanitizer.GetSafeHtmlFragment(_Course.Title) == "" || Sanitizer.GetSafeHtmlFragment(_Course.Title).Length > 100 || Sanitizer.GetSafeHtmlFragment(_Course.Title).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Title should not be Empty and must contain Min of 2 & Max of 100 characters"), JsonRequestBehavior.AllowGet);
                    if (Sanitizer.GetSafeHtmlFragment(_Course.Desc) == null || Sanitizer.GetSafeHtmlFragment(_Course.Desc) == "" || Sanitizer.GetSafeHtmlFragment(_Course.Desc).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain Min of 2 characters"), JsonRequestBehavior.AllowGet);
                }
                else if (_Course.btnType == "Update")
                {
                    if (Sanitizer.GetSafeHtmlFragment(_Course.Desc) == null || Sanitizer.GetSafeHtmlFragment(_Course.Desc) == "" || Sanitizer.GetSafeHtmlFragment(_Course.Desc).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain Min of 2 characters"), JsonRequestBehavior.AllowGet);
                }

                SymmetricAlgorithm aes = new AesManaged();
                byte[] key = aes.Key; // Key propery contains the key of the aes algorithm you can create your own   

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_Course.CategoryId.ToString()));
                _Array.Add(_Course.Title);
                _Array.Add(_Course.Desc);
                _Array.Add(RSAPattern.Encrypt(_Course.btnType));

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/InsertUpdateCreateCourse?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                if (_Result.Status)
                    SessionHandler.SessionCourseList = null;

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteCourse(string Title)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(Title));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/DeleteCourse?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Course Details
        public ActionResult CourseDetails()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetCourseDetails()
        {
            List<SE_CourseDetails> _list = new List<SE_CourseDetails>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Data = ApiHelper.PostData_Json("api/CPanelAdmin/GetCourseDetails?Values=", _Array);
                Result<List<SE_CourseDetails>> _Result = JsonConvert.DeserializeObject<Result<List<SE_CourseDetails>>>(_Data);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.CDetailsId),
                                 Convert.ToString(c.CourseId),
                                 Convert.ToString(c.CourseTitle),
                                 Convert.ToString(c.CategoryId),
                                 Convert.ToString(c.CategoryDesc),
                                 Convert.ToString(c.Currency),
                                 Convert.ToString(c.Price),
                                 Convert.ToString(c.Rating),
                                 Convert.ToString(c.Duration),
                                 Convert.ToString(c.NumOfClasses),
                                 Convert.ToString(c.Image),
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [CSRF_AntiForgeryToken]
        public ActionResult AddCourseDetails()
        {
            SE_CourseDetails model = new SE_CourseDetails();
            try
            {
                ViewBag.Course_dll = Reusable.CourseList(); // All Courses
                ViewBag.Caption = "Add Record";
                ViewBag.Button = "Save";
                return View("../PartialViews/AddCourseDetailsSideBar", model);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertUpdateCourseDetails(SE_CourseDetails _CDetails)
        {
            try
            {
                //Server-Side Validation
                if (Sanitizer.GetSafeHtmlFragment(_CDetails.CourseId.ToString()) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CDetails.CourseId.ToString()), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Course"), JsonRequestBehavior.AllowGet);
                if (_CDetails.Currency == null || Sanitizer.GetSafeHtmlFragment(_CDetails.Currency) == "" || Sanitizer.GetSafeHtmlFragment(_CDetails.Currency).Length > 3)
                    return Json(new Result(false, 500, "Validation Error", "Currency should not be Empty and must contain Max of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_CDetails.Price == null || Sanitizer.GetSafeHtmlFragment(_CDetails.Price) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CDetails.Price), @"^((\d+(\\.\d{0,2})?)|((\d*(\.\d{1,2}))))$") == false || Sanitizer.GetSafeHtmlFragment(_CDetails.Rating).Length > 20)
                    return Json(new Result(false, 500, "Validation Error", "Price should not be Empty and must contain Max of 20 digits"), JsonRequestBehavior.AllowGet);
                if (_CDetails.Rating == null || Sanitizer.GetSafeHtmlFragment(_CDetails.Rating) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CDetails.Rating), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_CDetails.Rating).Length > 1)
                    return Json(new Result(false, 500, "Validation Error", "Rating should not be Empty and must contain only 1 digit"), JsonRequestBehavior.AllowGet);
                if (_CDetails.Duration == null || Sanitizer.GetSafeHtmlFragment(_CDetails.Duration) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CDetails.Duration), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_CDetails.Duration).Length > 5)
                    return Json(new Result(false, 500, "Validation Error", "Duration should not be Empty and must must contain Max of 5 digits"), JsonRequestBehavior.AllowGet);
                if (_CDetails.NumOfClasses == null || Sanitizer.GetSafeHtmlFragment(_CDetails.NumOfClasses) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CDetails.NumOfClasses), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_CDetails.NumOfClasses).Length > 5)
                    return Json(new Result(false, 500, "Validation Error", "Num Of Classes should not be Empty and must contain Max of 5 digits"), JsonRequestBehavior.AllowGet);

                if (_CDetails.btnType == "Save")
                {
                    if (_CDetails.Image != null)
                    {
                        List<string> _ext = Reusable.ProfilePicExtentions();
                        if (!_ext.Contains(_CDetails.ImgType))
                            return Json(new Result(false, 500, "Validation Error", "Upload Images of Extentions .JPG, .JPEG, .PNG"), JsonRequestBehavior.AllowGet);
                    }
                    else
                        return Json(new Result(false, 500, "Validation Error", "Upload a Images"), JsonRequestBehavior.AllowGet);
                }
                else if (_CDetails.btnType == "Update")
                {
                    if (_CDetails.Image != null)
                    {
                        List<string> _ext = Reusable.ProfilePicExtentions();
                        if (!_ext.Contains(_CDetails.ImgType))
                            return Json(new Result(false, 500, "Validation Error", "Upload Images of Extentions .JPG, .JPEG, .PNG"), JsonRequestBehavior.AllowGet);
                    }
                }
                else
                    return Json(new Result(false, 500, "Validation Error", "Internal Server Error"), JsonRequestBehavior.AllowGet);

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_CDetails.CourseId.ToString()));
                _Array.Add(RSAPattern.Encrypt(_CDetails.Currency.ToString()));
                _Array.Add(RSAPattern.Encrypt(_CDetails.Price.ToString()));
                _Array.Add(RSAPattern.Encrypt(_CDetails.Rating.ToString()));
                _Array.Add(RSAPattern.Encrypt(_CDetails.Duration.ToString()));
                _Array.Add(RSAPattern.Encrypt(_CDetails.NumOfClasses.ToString()));
                _Array.Add(_CDetails.Image);
                _Array.Add(_CDetails.CDetailsId);
                _Array.Add(RSAPattern.Encrypt(_CDetails.btnType));

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/InsertUpdateCourseDetails?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [CSRF_AntiForgeryToken]
        public ActionResult EditCourseDetails(int id)
        {
            SE_CourseDetails model = new SE_CourseDetails();
            try
            {
                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(id.ToString()));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/EditCourseDetails?Values=", _Array);
                Result<SE_CourseDetails> _Result = JsonConvert.DeserializeObject<Result<SE_CourseDetails>>(response);

                if (_Result.Status)
                {
                    model.CDetailsId = _Result.Data.CDetailsId;
                    model.CourseId = _Result.Data.CourseId;
                    ViewBag.Course_dll = Reusable.CourseList(); // All Courses
                    model.CourseTitle = _Result.Data.CourseTitle;
                    model.CategoryId = _Result.Data.CategoryId;
                    model.CategoryDesc = _Result.Data.CategoryDesc;
                    model.Currency = _Result.Data.Currency;
                    model.Price = _Result.Data.Price;
                    model.Rating = _Result.Data.Rating;
                    model.Duration = _Result.Data.Duration;
                    model.NumOfClasses = _Result.Data.NumOfClasses;
                    model.Image = _Result.Data.Image;
                }

                ViewBag.PKId = RSAPattern.Encrypt(_Result.Data.CDetailsId.ToString());
                ViewBag.Caption = "Edit Record";
                ViewBag.Button = "Update";
                return View("../PartialViews/AddCourseDetailsSideBar", model);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteCourseDetails(string ID)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(ID));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/DeleteCourseDetails?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Course Content
        public ActionResult CourseContent()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            ViewBag.CCoCourse_dll = Reusable.CourseList(); // All Courses
            return View();
        }

        public JsonResult GetCourseContent()
        {
            List<SE_CourseContent> _list = new List<SE_CourseContent>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Data = ApiHelper.PostData_Json("api/CPanelAdmin/GetCourseContent?Values=", _Array);
                Result<List<SE_CourseContent>> _Result = JsonConvert.DeserializeObject<Result<List<SE_CourseContent>>>(_Data);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.ContentId),
                                 Convert.ToString(c.CourseId),
                                 Convert.ToString(c.CourseDesc),
                                 Convert.ToString(c.Content),
                                 Convert.ToString(GetShortData(c.Content))
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        private string GetShortData(string _Data) // Getting Course Content
        {
            string StripHtml = Regex.Replace(_Data, "<.*?>|&.*?;", string.Empty);
            StripHtml = StripHtml.ToString().Length > 30 ? StripHtml.ToString().Substring(0, 30) + "...." : StripHtml.ToString();
            return StripHtml;
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertUpdateCourseContent(SE_CourseContent _CContent)
        {
            try
            {
                //Server-Side Validation
                if (Sanitizer.GetSafeHtmlFragment(_CContent.CourseId.ToString()) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_CContent.CourseId.ToString()), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Course"), JsonRequestBehavior.AllowGet);
                if (_CContent.Content == null || Sanitizer.GetSafeHtmlFragment(_CContent.Content) == "")
                    return Json(new Result(false, 500, "Validation Error", "Content should not be Empty"), JsonRequestBehavior.AllowGet);

                if (_CContent.btnType == "Update")
                {
                    if (_CContent.ContentId == null || Sanitizer.GetSafeHtmlFragment(_CContent.ContentId) == "")
                        return Json(new Result(false, 500, "Validation Error", "ContentId should not be Empty"), JsonRequestBehavior.AllowGet);
                }

                //API Call		
                ArrayList _Array = new ArrayList();
                if (_CContent.btnType == "Update")
                    _Array.Add(RSAPattern.Encrypt(_CContent.ContentId.ToString()));
                else
                    _Array.Add(_CContent.ContentId);
                _Array.Add(RSAPattern.Encrypt(_CContent.CourseId.ToString()));
                _Array.Add(_CContent.Content.Remove(_CContent.Content.Length - 316));
                _Array.Add(RSAPattern.Encrypt(_CContent.btnType.ToString()));

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/InsertUpdateCourseContent?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteCourseContent(string ID)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(ID));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/DeleteCourseContent?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Batches
        public ActionResult CreateBatch()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            ViewBag.Course_dll = Reusable.CourseList(); // All Courses
            return View();
        }

        [HttpPost]
        public JsonResult AutoCompleteStudents(string prefix)
        {
            List<SelectListItem> StudentsList = Reusable.StudentsList(); // All Students

            //List<string> SList = new List<string>();
            //foreach (var Val in StudentsList)
            //    if (Val.Text.StartsWith(prefix.ToLower()))
            //        SList.Add(Val.Text.ToString());

            List<string> SList = new List<string>();
            foreach (var Val in StudentsList)
                SList.Add(Val.Text.ToString());

            SList = SList.FindAll(s => s.IndexOf(prefix, StringComparison.OrdinalIgnoreCase) >= 0);
            return Json(SList);
        }

        public JsonResult GetBatchDetails()
        {
            List<SE_Batches> _list = new List<SE_Batches>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Data = ApiHelper.PostData_Json("api/CPanelAdmin/GetBatchDetails?Values=", _Array);
                Result<List<SE_Batches>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Batches>>>(_Data);

                _list = _Result.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.BatchId),
                                 Convert.ToString(c.BatchCode),
                                 Convert.ToString(c.CourseId),
                                 Convert.ToString(c.CourseDesc),
                                 Convert.ToString(c.FullDateTime),
                                 Convert.ToString(c.NumOfStudents)
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CreateBatch(SE_Batches _Batch)
        {
            try
            {
                //Server-Side Validation
                if (Sanitizer.GetSafeHtmlFragment(_Batch.CourseId.ToString()) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Batch.CourseId.ToString()), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Course"), JsonRequestBehavior.AllowGet);
                if (Sanitizer.GetSafeHtmlFragment(_Batch.StaffName) == null || Sanitizer.GetSafeHtmlFragment(_Batch.StaffName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Batch.StaffName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_Batch.StaffName).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Batch.StaffName).Length < 2)
                    return Json(new Result(false, 500, "Validation Error", "Staff Name should not be Empty and must contain only Alphabets with Min of 2 & Max of 50 characters"), JsonRequestBehavior.AllowGet);
                if (Sanitizer.GetSafeHtmlFragment(_Batch.BatchStartDate.ToString()) == null || Sanitizer.GetSafeHtmlFragment(_Batch.BatchStartDate.ToString()) == "")
                    return Json(new Result(false, 500, "Validation Error", "Batch Start Date should not be Empty"), JsonRequestBehavior.AllowGet);
                if (Sanitizer.GetSafeHtmlFragment(_Batch.BatchTime.ToString()) == null || Sanitizer.GetSafeHtmlFragment(_Batch.BatchTime.ToString()) == "")
                    return Json(new Result(false, 500, "Validation Error", "Batch Time should not be Empty"), JsonRequestBehavior.AllowGet);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_Batch.CourseId.ToString()));
                _Array.Add(RSAPattern.Encrypt(_Batch.StaffName));
                _Array.Add(RSAPattern.Encrypt(_Batch.BatchStartDate.ToString()));
                _Array.Add(RSAPattern.Encrypt(_Batch.BatchTime));
                _Array.Add(_Batch.SingleValStudents);

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/CreateBatch?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                if (_Result.Status)
                    SessionHandler.SessionBatchList = null;
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [CSRF_AntiForgeryToken]
        public ActionResult EditBatchDetails(int id)
        {
            SE_Batches model = new SE_Batches();
            try
            {
                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(id.ToString()));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/EditBatchDetails?Values=", _Array);
                Result<SE_Batches> _Result = JsonConvert.DeserializeObject<Result<SE_Batches>>(response);

                if (_Result.Status)
                {
                    model.BatchId = _Result.Data.BatchId;
                    model.BatchCode = _Result.Data.BatchCode;
                    model.CourseId = _Result.Data.CourseId;
                    ViewBag.Course_dll = Reusable.CourseList(); // All Courses
                    model.CourseDesc = _Result.Data.CourseDesc;
                    model.StaffName = _Result.Data.StaffName;
                    model.BatchStartDate = _Result.Data.BatchStartDate.Date;
                    model.OnlyBatchStartDate = _Result.Data.BatchStartDate.ToString("yyyy-MM-dd");
                    model.BatchTime = _Result.Data.BatchTime;
                    ViewBag.Students_dll = Reusable.StudentsList(); // All Students
                    model.AssignedStudents = _Result.Data.AssignedStudents;
                }

                ViewBag.PKId = RSAPattern.Encrypt(_Result.Data.BatchId.ToString());
                return View("../PartialViews/AddBatchDetailsSideBar", model);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult UpdateBatchDetails(SE_Batches _Batch)
        {
            try
            {
                //Server-Side Validation
                if (Sanitizer.GetSafeHtmlFragment(_Batch.StaffName) == null || Sanitizer.GetSafeHtmlFragment(_Batch.StaffName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Batch.StaffName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_Batch.StaffName).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Batch.StaffName).Length < 2)
                    return Json(new Result(false, 500, "Validation Error", "Staff Name should not be Empty and must contain only Alphabets with Min of 2 & Max of 50 characters"), JsonRequestBehavior.AllowGet);
                if (Sanitizer.GetSafeHtmlFragment(_Batch.BatchStartDate.ToString()) == null || Sanitizer.GetSafeHtmlFragment(_Batch.BatchStartDate.ToString()) == "")
                    return Json(new Result(false, 500, "Validation Error", "Batch Start Date should not be Empty"), JsonRequestBehavior.AllowGet);
                if (Sanitizer.GetSafeHtmlFragment(_Batch.BatchTime.ToString()) == null || Sanitizer.GetSafeHtmlFragment(_Batch.BatchTime.ToString()) == "")
                    return Json(new Result(false, 500, "Validation Error", "Batch Time should not be Empty"), JsonRequestBehavior.AllowGet);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_Batch.StaffName));
                _Array.Add(RSAPattern.Encrypt(_Batch.BatchStartDate.ToString()));
                _Array.Add(RSAPattern.Encrypt(_Batch.BatchTime));
                _Array.Add(_Batch.BatchId.ToString());
                _Array.Add(_Batch.SingleValStudents);

                string response = ApiHelper.PostData_Json("api/CPanelAdmin/UpdateBatchDetails?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                if (_Result.Status)
                    SessionHandler.SessionBatchList = null;
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteBatch(string ID)
        {
            try
            {
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(ID));
                string response = ApiHelper.PostData_Json("api/CPanelAdmin/DeleteBatch?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion
    }
}