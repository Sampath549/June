﻿using Application.App_Start;
using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [RoutePrefix("api/UserPresentation")]
    public class UserPresentationApiController : ApiController
    {
        UserPresentationDAL _ObjUserPresentation = new UserPresentationDAL();

        [HttpPost, Route("CreateUserRequestForm")]
        public Result CreateUserRequestForm(ArrayList Array)
        {
            try
            {
                SE_Forms Forms = new SE_Forms();
                foreach (JObject val in Array)
                    Forms = val.ToObject<SE_Forms>();

                Forms.FormType = StringEncrypt.Encrypt(GlobalVariables.Shared.RequestFormType);
                Forms.Name = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Forms.Name));
                Forms.Email = StringEncrypt.Encrypt(RSAPattern.Decrypt(Forms.Email));
                Forms.Mobile = StringEncrypt.Encrypt(RSAPattern.Decrypt(Forms.Mobile));
                Forms.Course = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Forms.Course));
                Forms.Message = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Forms.Message));

                int _Status = _ObjUserPresentation.InsertForms(Forms);

                if (_Status == 1)
                    return Result.Success(200, "Success", "Request Submited Successfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("SearchCourse")]
        public Result<List<int>> SearchCourse(ArrayList Array)
        {
            List<int> _lst = new List<int>();
            try
            {
                string Course = string.Empty;
                foreach (string val in Array)
                    Course = val.ToString();
                _lst = _ObjUserPresentation.SearchCourse(Course);
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetPopularCourses")]
        public Result<List<SE_UserCourses>> GetPopularCourses(ArrayList Array)
        {
            List<SE_UserCourses> _lst = new List<SE_UserCourses>();
            try
            {
                _lst = _ObjUserPresentation.GetPopularCourses();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetAllCourses")]
        public Result<List<SE_UserCourses>> GetAllCourses(ArrayList Array)
        {
            List<SE_UserCourses> _lst = new List<SE_UserCourses>();
            try
            {
                _lst = _ObjUserPresentation.GetAllCourses();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetCourseById")]
        public Result<List<SE_UserCourses>> GetCourseById(ArrayList Array)
        {
            List<SE_UserCourses> _lst = new List<SE_UserCourses>();
            try
            {
                string CourseId = string.Empty;
                foreach (string val in Array)
                    CourseId = val.ToString();

                _lst = _ObjUserPresentation.GetCourseById(CourseId);
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("CreateUserContactForm")]
        public Result CreateUserContactForm(ArrayList Array)
        {
            try
            {
                SE_Forms Forms = new SE_Forms();
                foreach (JObject val in Array)
                    Forms = val.ToObject<SE_Forms>();

                Forms.FormType = StringEncrypt.Encrypt(GlobalVariables.Shared.ContactFormType);
                Forms.Name = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Forms.Name));
                Forms.Email = StringEncrypt.Encrypt(RSAPattern.Decrypt(Forms.Email));
                Forms.Mobile = StringEncrypt.Encrypt(RSAPattern.Decrypt(Forms.Mobile));
                Forms.Course = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Forms.Course));
                Forms.Message = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Forms.Message));

                int _Status = _ObjUserPresentation.InsertForms(Forms);

                if (_Status == 1)
                    return Result.Success(200, "Success", "Request Submited Successfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }
    }
}
