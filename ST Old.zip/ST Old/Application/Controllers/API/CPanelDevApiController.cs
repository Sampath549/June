﻿using Application.App_Start;
using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Application.Controllers.API
{
    [RoutePrefix("api/CPanelDev")]
    public class CPanelDevApiController : ApiController
    {
        CPanelDevDAL _ObjCPanelDev = new CPanelDevDAL();
        SE_Users Users = new SE_Users();

        [HttpPost, Route("CreateAllUsers")]
        public Result CreateAllUsers(ArrayList Array)
        {
            try
            {
                Users = new SE_Users();
                foreach (JObject val in Array)
                    Users = val.ToObject<SE_Users>();

                string ActualFName, ActualLName, ActualEmail, RandomPwd, SaltKey = string.Empty;
                ActualFName = RSAPattern.Decrypt(Users.FirstName);
                ActualLName = RSAPattern.Decrypt(Users.LastName);
                ActualEmail = RSAPattern.Decrypt(Users.Email);

                Users.PersonalKey = AES_Algorithm.EncryptString(Guid.NewGuid().ToString());
                Users.FirstName = AES_Algorithm.EncryptString(ActualFName);
                Users.LastName = AES_Algorithm.EncryptString(ActualLName);
                Users.Email = StringEncrypt.Encrypt(RSAPattern.Decrypt(Users.Email));
                Users.Mobile = StringEncrypt.Encrypt(RSAPattern.Decrypt(Users.Mobile));
                Users.RoleIdVal = RSAPattern.Decrypt(Users.RoleIdVal.ToString());
                SaltKey = PwdEncryption.GeneratePassword();
                Users.SaltKey = AES_Algorithm.EncryptString(SaltKey);
                RandomPwd = PwdEncryption.GeneratePassword();
                Users.Password = PwdEncryption.EncodePassword(RandomPwd, SaltKey);

                //Temp
                Reusable.TempPwd(0, ActualEmail, RandomPwd);

                int _Status = _ObjCPanelDev.InsertUsers(Users);

                bool _SendMail = false;
                if (_Status == 1)
                {
                    if (Convert.ToInt32(Users.RoleIdVal) != GlobalVariables.Shared.StudentRoleId)
                    {
                        EmailHelper _EmailHelper = EmailHelper.Instance;
                        string _MessageBody = @"<div id='Template' width='100%' height=450'>
                                            <p>Dear <b>" + ActualFName + @" " + ActualLName + @"</b>..!!,</p>
                                            <p>Thank you for Joining EuroBharat. Here are the details.</p>
                                            <div style='margin-left:40px; color:initial;'>
                                            <table style='border:0'>
                                                <tr>
                                                    <td style='border:0'> Email:</td>
                                                    <td style='border:0'><strong>" + ActualEmail + @"</strong></td>
                                                </tr>
                                                <tr>
                                                    <td style='border:0'> Password:</td>
                                                    <td style='border:0'><strong>" + RandomPwd + @"</strong></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                        <p style='margin-bottom: 0px'><strong> Important Note :</strong></p>
                                        <div style='margin-left:40px; margin-top: -15px; color:initial;'>
                                            <table style = 'border:0'>
                                                <tr>
                                                    <td style='border:0'>a. Please find the attached file for better understanding of EuroBharat.</td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                    </div>";
                        List<EmailAttachment> _Attachments = new List<EmailAttachment>();
                        _Attachments.Add(new EmailAttachment("Welcome.pdf", File.ReadAllBytes(System.Web.Hosting.HostingEnvironment.MapPath("~/Helper/Documents/Welcome.pdf"))));
                        string emailTo = string.Empty;
                        if (GlobalVariables.Shared.SendActualMails)
                            emailTo = ActualEmail;
                        else
                            emailTo = GlobalVariables.Shared.SendDefaultEmailTo;

                        if (!GlobalVariables.Shared.DontSendMail)
                            _SendMail = _EmailHelper.SendWithTemplate(emailTo, "", "Welcome Email", _EmailHelper.HTMLSanitize(_MessageBody), _Attachments);
                        else
                            _SendMail = true;
                    }
                    _SendMail = true;
                }

                if (_Status == 1 && _SendMail == false)
                    return Result.Failed(500, "Email Sending Failed", "User Created Successfully but Email Sending Failed");
                else if (_Status == 101)
                    return Result.Failed(500, "Duplicate Record", "Email / Mobile already exists");
                else
                    return Result.Success(200, "Success", "User Created Successfully");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("SendMails")]
        public Result SendMails(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                foreach (string val in Array)
                    _lst.Add(RSAPattern.Decrypt(val.ToString()));

                DataSet _Result = _ObjCPanelDev.GetMailData(_lst[0], _lst[1]);

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                    {
                        string RandomPwd, SaltKey = string.Empty;
                        SaltKey = PwdEncryption.GeneratePassword();
                        RandomPwd = PwdEncryption.GeneratePassword();

                        SE_Users Users = new SE_Users();
                        Users.UserId = Convert.ToInt32(dr["StudentId"]);
                        Users.FirstName = AES_Algorithm.DecryptString(dr["FirstName"].ToString());
                        Users.LastName = AES_Algorithm.DecryptString(dr["LastName"].ToString());
                        Users.Email = StringEncrypt.Decrypt(dr["Email"].ToString());
                        Users.SaltKey = AES_Algorithm.EncryptString(SaltKey);
                        Users.Password = PwdEncryption.EncodePassword(RandomPwd, SaltKey);

                        //Temp
                        Reusable.TempPwd(Users.UserId, Users.Email, RandomPwd);

                        int _Status = _ObjCPanelDev.UpdateSendMailUsers(Users);

                        bool _SendMail = false;
                        if (_Status == 1)
                            _SendMail = SendMailsExt(_Status, Users.FirstName, Users.LastName, Users.Email, RandomPwd);
                    }
                return Result.Success(200, "Success", "Mail(s) Sent");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        private bool SendMailsExt(int _Status, string FName, string LName, string Email, string Pwd)
        {
            bool _SendMail = false;
            if (_Status == 1)
            {
                EmailHelper _EmailHelper = EmailHelper.Instance;
                string _MessageBody = @"<div id='Template' width='100%' height=450'>
                                            <p>Dear <b>" + FName + @" " + LName + @"</b>..!!,</p>
                                            <p>Thank you for Joining EuroBharat. Here are the details.</p>
                                            <div style='margin-left:40px; color:initial;'>
                                            <table style='border:0'>
                                                <tr>
                                                    <td style='border:0'> Email:</td>
                                                    <td style='border:0'><strong>" + Email + @"</strong></td>
                                                </tr>
                                                <tr>
                                                    <td style='border:0'> Password:</td>
                                                    <td style='border:0'><strong>" + Pwd + @"</strong></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                        <p style='margin-bottom: 0px'><strong> Important Note :</strong></p>
                                        <div style='margin-left:40px; margin-top: -15px; color:initial;'>
                                            <table style = 'border:0'>
                                                <tr>
                                                    <td style='border:0'>a. Please find the attached file for better understanding of EuroBharat.</td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                    </div>";
                List<EmailAttachment> _Attachments = new List<EmailAttachment>();
                _Attachments.Add(new EmailAttachment("Welcome.pdf", File.ReadAllBytes(System.Web.Hosting.HostingEnvironment.MapPath("~/Helper/Documents/Welcome.pdf"))));
                string emailTo = string.Empty;
                if (GlobalVariables.Shared.SendActualMails)
                    emailTo = Email;
                else
                    emailTo = GlobalVariables.Shared.SendDefaultEmailTo;

                if (!GlobalVariables.Shared.DontSendMail)
                    _SendMail = _EmailHelper.SendWithTemplate(emailTo, "", "Welcome Email", _EmailHelper.HTMLSanitize(_MessageBody), _Attachments);
                else
                    _SendMail = true;
            }
            return _SendMail;
        }
    }
}
