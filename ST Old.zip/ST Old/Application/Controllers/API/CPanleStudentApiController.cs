﻿using Application.App_Start;
using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [RoutePrefix("api/CPanelStudent")]
    public class CPanleStudentApiController : ApiController
    {
        SE_Users Users = new SE_Users();
        CPanelStudentDAL _ObjCPanelStudent = new CPanelStudentDAL();

        [HttpPost, Route("GetStudentDashboard")]
        public Result<SE_StudentDashboard> GetStudentDashboard(ArrayList Array)
        {
            SE_StudentDashboard _lst = new SE_StudentDashboard();
            try
            {
                string _Id = string.Empty;
                foreach (string val in Array)
                    _Id = RSAPattern.Decrypt(val);

                _lst = _ObjCPanelStudent.GetStudentDashboard(Convert.ToInt32(_Id));
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("StudentsBatchList")]
        public Result<List<SE_RefValues>> StudentsBatchList(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                string _Id = string.Empty;
                foreach (string val in Array)
                    _Id = RSAPattern.Decrypt(val);

                _lst = _ObjCPanelStudent.StudentsBatchList(Convert.ToInt32(_Id));
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetStudentCourseMaterial")]
        public Result<List<SE_Uploads>> GetStudentCourseMaterial(ArrayList Array)
        {
            List<SE_Uploads> _Uploads = new List<SE_Uploads>();
            try
            {
                List<string> _lst = new List<string>();
                foreach (string val in Array)
                    _lst.Add(RSAPattern.Decrypt(val));

                _Uploads = _ObjCPanelStudent.GetStudentCourseMaterial(_lst[0], _lst[1]);
                return Result.Success(_Uploads, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_Uploads, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetStudentBatchVideos")]
        public Result<List<SE_Uploads>> GetStudentBatchVideos(ArrayList Array)
        {
            List<SE_Uploads> _Uploads = new List<SE_Uploads>();
            try
            {
                List<string> _lst = new List<string>();
                foreach (string val in Array)
                    _lst.Add(RSAPattern.Decrypt(val));

                _Uploads = _ObjCPanelStudent.GetStudentBatchVideos(_lst[0], _lst[1]);
                return Result.Success(_Uploads, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_Uploads, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }
    }
}
