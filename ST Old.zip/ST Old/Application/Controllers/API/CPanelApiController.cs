﻿using Application.App_Start;
using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [RoutePrefix("api/CPanel")]
    public class CPanelApiController : ApiController
    {
        #region Global Variables
        CPanelDAL _ObjCPanel = new CPanelDAL();
        SharedDAL _ObjShared = new SharedDAL();
        #endregion

        [HttpPost, Route("LoginAuthentication")]
        public Result<SE_Users> LoginAuthentication(ArrayList Array)
        {
            SE_Users _Result = new SE_Users();
            try
            {
                List<string> _Data = new List<string>();
                foreach (string val in Array)
                    _Data.Add(RSAPattern.Decrypt(val));

                string _Email = StringEncrypt.Encrypt(_Data[0]);
                _Result = _ObjCPanel.AuthenticatedUser(_Email, PwdEncryption.EncodePassword(_Data[1].ToString(), AES_Algorithm.DecryptString(_ObjShared.GetSaltKeyByEmail(_Email))));
                _Result.RedirectUrl = Reusable.RedirectPage(_Result.RoleCode);

                if (_Result.Status == 1)
                {
                    _Result.FirstName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.FirstName));
                    _Result.LastName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.LastName));
                    _Result.Email = RSAPattern.Encrypt(StringEncrypt.Decrypt(_Result.Email));
                    _Result.Mobile = RSAPattern.Encrypt(StringEncrypt.Decrypt(_Result.Mobile));

                    return Result.Success(_Result, 200, GlobalVariables.Shared.SucessMsg);
                }
                else if (_Result.Status == 0)
                    return Result.Failed(_Result, 500, GlobalVariables.Shared.InvalidUserPwdMsg);
                else
                    return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }        

        [HttpPost, Route("BindMenus")]
        public Result<string> BindMenus(ArrayList Array)
        {
            string _Role = string.Empty;
            try
            {
                foreach (string val in Array)
                    _Role = RSAPattern.Decrypt(val);

                string _Result = _ObjCPanel.GetMenus(_Role);
                _Result = _Result.Replace(Environment.NewLine, string.Empty).Trim();

                return Result.Success(_Result, 200, "Success", "Change Password is Succesfully");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed("", 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetCountries")]
        public Result<List<SE_RefValues>> GetCountries(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjShared.GetCountries();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetStates")]
        public Result<List<SE_RefValues>> GetStates(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjShared.GetStates();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("UserDetails")]
        public Result<SE_Users> UserDetails(ArrayList Array)
        {
            string _Email = string.Empty;
            SE_Users _Result = new SE_Users();
            try
            {
                foreach (string val in Array)
                    _Email = StringEncrypt.Encrypt(RSAPattern.Decrypt(val.ToString()));

                _Result = _ObjCPanel.UserDetails(_Email);

                if (_Result.Gender != null)
                    _Result.Gender = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.Gender));
                if (_Result.Address != null)
                    _Result.Address = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.Address));
                if (_Result.City != null)
                    _Result.City = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.City));
                if (_Result.ZipCode != null)
                    _Result.ZipCode = RSAPattern.Encrypt(_Result.ZipCode);

                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("UserProfile")]
        public Result UserProfile(ArrayList Array)
        {
            SE_Users _Details = new SE_Users();
            SE_Users _Records = new SE_Users();

            try
            {
                foreach (JObject val in Array)
                    _Details = val.ToObject<SE_Users>();

                _Records.FirstName = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.FirstName));
                _Records.LastName = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.LastName));
                _Records.Email = StringEncrypt.Encrypt(RSAPattern.Decrypt(_Details.Email));

                if (_Details.Gender != null)
                    _Records.Gender = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.Gender));
                if (_Details.Address != null)
                    _Records.Address = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.Address));
                if (_Details.City != null)
                    _Records.City = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.City));
                if (_Details.StateId != null)
                    _Records.StateId = RSAPattern.Decrypt(_Details.StateId);
                if (_Details.CountryId != null)
                    _Records.CountryId = RSAPattern.Decrypt(_Details.CountryId);
                if (_Details.ZipCode != null)
                    _Records.ZipCode = RSAPattern.Decrypt(_Details.ZipCode);

                int _Result = _ObjCPanel.UpdateUserProfile(_Records);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Details Updated Successfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("ChangePassword")]
        public Result ChangePassword(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (string val in Array)
                    _lst.Add(val);

                string OldPassword, OldSaltKey, Password = string.Empty;
                Password = RSAPattern.Decrypt(_lst[1]);
                OldSaltKey = _ObjShared.GetSaltKeyById(RSAPattern.Decrypt(_lst[2]));
                OldPassword = PwdEncryption.EncodePassword(RSAPattern.Decrypt(_lst[0]), AES_Algorithm.DecryptString(OldSaltKey));

                string SaltKey = PwdEncryption.GeneratePassword();
                string NewPassword = PwdEncryption.EncodePassword(RSAPattern.Decrypt(_lst[1]), SaltKey);
                string NewSaltKey = AES_Algorithm.EncryptString(SaltKey);

                int _Result = _ObjCPanel.ChangePassword(Convert.ToInt32(RSAPattern.Decrypt(_lst[2])), OldPassword, OldSaltKey, NewPassword, NewSaltKey);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Change Password is Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Incorrect Old Password");
                else if (_Result == 100)
                    return Result.Failed(500, "Error", "User does not Exists");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("RolesList")]
        public Result<List<SE_RefValues>> RolesList(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjShared.RolesList();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }
    }
}
