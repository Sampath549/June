﻿using Application.App_Start;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    public class UserController : Controller
    {
        [ContentSecurityPolicy]
        public ActionResult Home()
        {
            List<SE_UserCourses> _UserCourses = new List<SE_UserCourses>();

            try
            {

                ViewBag.LatestNews = Reusable.LatestNews();
                ViewBag.UpcomingClasses = Reusable.UpcomingClasses();
                ViewBag.LatestVideos = Reusable.LatestVideos();

                //API Call
                ArrayList _Array = new ArrayList();
                string response = ApiHelper.PostData_Json_NToken("api/UserPresentation/GetPopularCourses?Values=", _Array);
                Result<List<SE_UserCourses>> _Result = JsonConvert.DeserializeObject<Result<List<SE_UserCourses>>>(response);
                return View(_Result.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost]
        public JsonResult AutoCompleteCourses(string prefix)
        {
            List<SelectListItem> CourseList = Reusable.CourseList(); // All Students
            List<string> CList = new List<string>();

            foreach (var Val in CourseList)
            {
                if (Convert.ToInt32(Val.Value) != 0)
                    CList.Add(Val.Text.ToString());
            }

            CList = CList.FindAll(s => s.IndexOf(prefix, StringComparison.OrdinalIgnoreCase) >= 0);
            return Json(CList);
        }

        [ContentSecurityPolicy]
        public ActionResult SearchCourse(string Course)
        {
            try
            {
                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Course);
                string response = ApiHelper.PostData_Json_NToken("api/UserPresentation/SearchCourse?Values=", _Array);
                Result<List<int>> _Result = JsonConvert.DeserializeObject<Result<List<int>>>(response);

                if (_Result.Data.Count > 0)
                    return RedirectToAction("CourseDetails", new { CourseId = _Result.Data[0] });
                else
                    return RedirectToAction("Courses");
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult LatestNews()
        {
            try
            {
                List<SE_News> _News = Reusable.LatestNews();
                return View(_News);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult LatestNewsDetails(string Id)
        {
            try
            {
                List<SE_News> _News = Reusable.LatestNews();
                ViewBag.RelatedNews = _News;
                _News = _News.Where(i => i.NewsId == Convert.ToInt32(Id)).ToList();
                return View(_News[0]);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult Calender()
        {
            try
            {
                List<SE_UpcomingClasses> _Classes = Reusable.UpcomingClasses();
                return View(_Classes);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult LatestVideos()
        {
            try
            {
                List<SE_LatestVideos> _Videos = Reusable.LatestVideos();
                List<SE_News> _News = Reusable.LatestNews();
                ViewBag.RelatedNews = _News;
                return View(_Videos);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CreateUserRequestForm(SE_Forms _Forms)
        {
            try
            {
                //Server-Side Validations
                if (_Forms.Name == null || Sanitizer.GetSafeHtmlFragment(_Forms.Name) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Forms.Name), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_Forms.Name).Length > 100)
                    return Json(new Result(false, 500, "Validation Error", "Name should not be Empty and must contain only Alphabets"), JsonRequestBehavior.AllowGet);
                if (_Forms.Email == null || Sanitizer.GetSafeHtmlFragment(_Forms.Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Forms.Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_Forms.Email).Length > 100)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format"), JsonRequestBehavior.AllowGet);
                if (_Forms.Mobile == null || Sanitizer.GetSafeHtmlFragment(_Forms.Mobile) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Forms.Mobile), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_Forms.Mobile).Length > 15)
                    return Json(new Result(false, 500, "Validation Error", "Mobile should not be Empty and must contain only Numbers"), JsonRequestBehavior.AllowGet);
                if (_Forms.Course == null || Sanitizer.GetSafeHtmlFragment(_Forms.Course) == "" || Sanitizer.GetSafeHtmlFragment(_Forms.Course).Length > 150)
                    return Json(new Result(false, 500, "Validation Error", "Course should not be Empty"), JsonRequestBehavior.AllowGet);
                if (_Forms.Message == null || Sanitizer.GetSafeHtmlFragment(_Forms.Message) == "" || Sanitizer.GetSafeHtmlFragment(_Forms.Message).Length > 300)
                    return Json(new Result(false, 500, "Validation Error", "Message should not be Empty and must contain only Alphabets with Maximum of 300 characters"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                SE_Forms _Data = new SE_Forms();
                _Data.Name = RSAPattern.Encrypt(_Forms.Name);
                _Data.Email = RSAPattern.Encrypt(_Forms.Email.ToLower());
                _Data.Mobile = RSAPattern.Encrypt(_Forms.Mobile);
                _Data.Course = RSAPattern.Encrypt(_Forms.Course);
                _Data.Message = RSAPattern.Encrypt(_Forms.Message);

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(_Data);
                string response = ApiHelper.PostData_Json_NToken("api/UserPresentation/CreateUserRequestForm?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [ContentSecurityPolicy]
        public ActionResult About()
        {
            return View();
        }

        [ContentSecurityPolicy]
        public ActionResult Courses()
        {
            List<SE_UserCourses> _UserCourses = new List<SE_UserCourses>();
            try
            {
                //API Call
                ArrayList _Array = new ArrayList();
                string response = ApiHelper.PostData_Json_NToken("api/UserPresentation/GetAllCourses?Values=", _Array);
                Result<List<SE_UserCourses>> _Result = JsonConvert.DeserializeObject<Result<List<SE_UserCourses>>>(response);
                return View(_Result.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult CourseDetails(string CourseId)
        {
            List<SE_UserCourses> _UserCourses = new List<SE_UserCourses>();
            try
            {
                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(CourseId);
                string response = ApiHelper.PostData_Json_NToken("api/UserPresentation/GetCourseById?Values=", _Array);
                Result<List<SE_UserCourses>> _Result = JsonConvert.DeserializeObject<Result<List<SE_UserCourses>>>(response);
                return View(_Result.Data[0]);
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult Blogs()
        {
            return View();
        }

        [ContentSecurityPolicy]
        public ActionResult BlogDetails()
        {
            return View();
        }

        [ContentSecurityPolicy]
        public ActionResult FAQ()
        {
            return View();
        }

        [ContentSecurityPolicy]
        public ActionResult Contact()
        {
            return View();
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CreateUserContactForm(SE_Forms _Forms)
        {
            try
            {
                //Server-Side Validations
                if (_Forms.Name == null || Sanitizer.GetSafeHtmlFragment(_Forms.Name) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Forms.Name), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_Forms.Name).Length > 100)
                    return Json(new Result(false, 500, "Validation Error", "Name should not be Empty and must contain only Alphabets"), JsonRequestBehavior.AllowGet);
                if (_Forms.Email == null || Sanitizer.GetSafeHtmlFragment(_Forms.Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Forms.Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_Forms.Email).Length > 100)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format"), JsonRequestBehavior.AllowGet);
                if (_Forms.Mobile == null || Sanitizer.GetSafeHtmlFragment(_Forms.Mobile) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Forms.Mobile), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_Forms.Mobile).Length > 15)
                    return Json(new Result(false, 500, "Validation Error", "Mobile should not be Empty and must contain only Numbers"), JsonRequestBehavior.AllowGet);
                if (_Forms.Course == null || Sanitizer.GetSafeHtmlFragment(_Forms.Course) == "" || Sanitizer.GetSafeHtmlFragment(_Forms.Course).Length > 150)
                    return Json(new Result(false, 500, "Validation Error", "Course should not be Empty"), JsonRequestBehavior.AllowGet);
                if (_Forms.Message == null || Sanitizer.GetSafeHtmlFragment(_Forms.Message) == "" || Sanitizer.GetSafeHtmlFragment(_Forms.Message).Length > 300)
                    return Json(new Result(false, 500, "Validation Error", "Message should not be Empty and must contain only Alphabets with Maximum of 300 characters"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                SE_Forms _Data = new SE_Forms();
                _Data.Name = RSAPattern.Encrypt(_Forms.Name);
                _Data.Email = RSAPattern.Encrypt(_Forms.Email.ToLower());
                _Data.Mobile = RSAPattern.Encrypt(_Forms.Mobile);
                _Data.Course = RSAPattern.Encrypt(_Forms.Course);
                _Data.Message = RSAPattern.Encrypt(_Forms.Message);

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(_Data);
                string response = ApiHelper.PostData_Json_NToken("api/UserPresentation/CreateUserContactForm?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
    }
}