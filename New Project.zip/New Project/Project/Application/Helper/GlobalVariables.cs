﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace Application.Helper
{
    public sealed class GlobalVariables
    {
        private static readonly GlobalVariables shared = new GlobalVariables();

        public readonly string OAuthClientId;
        public readonly string OAuthClientSecret;
        public readonly string OAuthTokenExpireSeconds;
        public readonly string PrivateKey;
        public readonly string PublicKey;

        public readonly string ConfigUrl;
        public readonly bool InsertErrorLog;
        public readonly bool ReCaptcha;

        public readonly string SessionExpired;
        public readonly string InternalServerError;

        public readonly string InternalServerErrorMsg;

        static GlobalVariables()
        {
        }

        private GlobalVariables()
        {
            OAuthClientId = WebConfigurationManager.AppSettings["OAuthClientId"];
            OAuthClientSecret = WebConfigurationManager.AppSettings["OAuthClientSecret"];
            OAuthTokenExpireSeconds = WebConfigurationManager.AppSettings["OAuthTokenExpireSeconds"];
            PrivateKey = WebConfigurationManager.AppSettings["PrivateKey"].ToString();
            PublicKey = WebConfigurationManager.AppSettings["PublicKey"].ToString();

            ConfigUrl = WebConfigurationManager.AppSettings["ConfigUrl"];

            ReCaptcha = Convert.ToBoolean(WebConfigurationManager.AppSettings["InsertErrorLog"]);
            InsertErrorLog = Convert.ToBoolean(WebConfigurationManager.AppSettings["InsertErrorLog"]);

            InternalServerError = WebConfigurationManager.AppSettings["InternalServerError"];
            SessionExpired = WebConfigurationManager.AppSettings["SessionExpired"];

            InternalServerErrorMsg = "Internal Server Error";
        }

        public static GlobalVariables Shared
        {
            get { return shared; }
        }
    }
}