﻿using Application.Models.SharedEntities;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Helper
{
    public static class Reusable
    {
        public static string BindMenus()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                {
                    //API Call		
                    ArrayList _Array = new ArrayList();
                    _Array.Add(RSAPattern.Encrypt(_SessionUserDetails.RoleCode));
                    string _Menu = ApiHelper.PostData_Json("api/CPanel/BindMenus?Values=", _Array);
                    Result<string> _Result = JsonConvert.DeserializeObject<Result<string>>(_Menu);

                    SessionHandler.Menus = _Result.Data;
                }
                return SessionHandler.Menus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}