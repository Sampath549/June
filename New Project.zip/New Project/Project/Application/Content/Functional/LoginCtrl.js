﻿$(document).ready(function () {
    $('#btnLogin').click(function (event) {
        event.preventDefault();

        $.ajax({
            type: "POST",
            url: "/Login/LoginAuthentication",
            data: { _User: $('#username').val(), _Password: $('#password').val() },
            dataType: "json",
            cache: false,
            success: function (response) {
                if (!response[0].Status)
                    alert("Username OR Password is Incorrect")
                else {
                    if (response[0].RoleCode == 'DEV')
                        window.location.href = "/Login/MyResult1";
                    else if (response[0].RoleCode == 'ADM')
                        window.location.href = "/Login/MyResult2";
                    else
                        alert("Role not Assigned")
                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert("Something Went Wrong")
            }
        });
    });
});