﻿using Application.App_Start;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Device.Location;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace Application.Controllers
{
    public class CPanelController : Controller
    {
        #region Design Pages for Login, Registration, ForgotPassword
        // Note: 
        // 1) Content Security Policy for all the Startup pages.
        // 2) Error Redirecting to the Page depending on the status code. And can choose whether to insert in Error log text document or not.    

        [ContentSecurityPolicy]
        public ActionResult Login()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult Registration()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult ForgotPassword()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        #endregion

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult LoginAuthentication(string _User, string _Password, string _ReCaptcha)
        {
            SE_Users Users = new SE_Users();
            ArrayList _Array = new ArrayList();
            try
            {
                //Checking ReCaptcha Required or Not
                if (GlobalVariables.Shared.ReCaptcha)
                {
                    bool chk = isCaptchaValid(_ReCaptcha);
                    if (!chk)
                        return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);
                }

                //Server-Side Validations
                if (_User == null || Sanitizer.GetSafeHtmlFragment(_User) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false)
                    return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);
                if (_Password == null || Sanitizer.GetSafeHtmlFragment(_Password) == "")
                    return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);

                //RSA Encryption
                Users = new SE_Users();
                Users.Email = RSAPattern.Encrypt(_User);
                Users.Password = RSAPattern.Encrypt(_Password);
                Users.IPAddress = Request.UserHostAddress;
                Users.EntryType = "";
                Users.EntryFrom = "Web";
                Users.BrowserName = Request.Browser.Browser;
                Users.BrowserVersion = Request.Browser.Version;
                Users.ResolutionWidth = Screen.PrimaryScreen.Bounds.Width.ToString();
                Users.ResolutionHeight = Screen.PrimaryScreen.Bounds.Height.ToString();
                string[] LatLon = GetLatLon().Split('^'); // GEO Location
                Users.Latitude = LatLon[0];
                Users.Longitude = LatLon[1];
                Users.Location = LatLon[2];

                //Audit
                ArrayList _Audit = new ArrayList();
                _Audit.Add(Users);
                string responseAudit = ApiHelper.PostData_Json_NToken("api/CPanel/Audit?Values=", _Audit);

                //API Call
                _Array = new ArrayList();
                _Array.Add(Users.Email);
                _Array.Add(Users.Password);

                string response = ApiHelper.PostData_Json_NToken("api/CPanel/LoginAuthentication?Values=", _Array);
                Result<SE_Users> _Result = JsonConvert.DeserializeObject<Result<SE_Users>>(response);

                if (_Result.Data.Status == 1)
                {
                    //Access Token
                    SessionHandler.AuthName = _User;
                    SessionHandler.AuthPwd = _Password;

                    _Result.Data.FirstName = RSAPattern.Decrypt(_Result.Data.FirstName);
                    _Result.Data.LastName = RSAPattern.Decrypt(_Result.Data.LastName);
                    _Result.Data.Email = RSAPattern.Decrypt(_Result.Data.Email);
                    _Result.Data.Mobile = RSAPattern.Decrypt(_Result.Data.Mobile);

                    string FullName = _Result.Data.FirstName + " " + _Result.Data.LastName;
                    SessionHandler.WelcomeNameTitle = FullName;
                    if (FullName.Length > 25)
                        FullName = FullName.Substring(0, 25) + "...";
                    SessionHandler.WelcomeName = FullName;

                    if (_Result.Data.ProfilePic != null)
                        SessionHandler.ProfilePic = _Result.Data.ProfilePic;

                    SessionHandler.UserDetails = _Result.Data;
                    return Json(new Result<SE_Users>(_Result.Data, _Result.Status, _Result.StatusCode, _Result.Caption, _Result.Message), JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new Result<SE_Users>(_Result.Data, _Result.Status, _Result.StatusCode, _Result.Caption, _Result.Message), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<SE_Users>(Users, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        private bool isCaptchaValid(string res)
        {
            var result = false;
            var captchaResponse = res;
            var secretKey = "6Le8IokUAAAAAJnKCaDOrbkMKVHaw9v1Cgq8GchF";
            var apiUrl = "https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}";
            var requestUri = string.Format(apiUrl, secretKey, captchaResponse);
            var request = (HttpWebRequest)WebRequest.Create(requestUri);

            using (WebResponse response = request.GetResponse())
            {
                using (StreamReader stream = new StreamReader(response.GetResponseStream()))
                {
                    JObject jResponse = JObject.Parse(stream.ReadToEnd());
                    var isSuccess = jResponse.Value<bool>("success");
                    result = (isSuccess) ? true : false;
                }
            }
            return result;
        }
        private string GetLatLon()
        {
            string Latitude = string.Empty;
            string Longitude = string.Empty;
            string Location = string.Empty;

            GeoCoordinateWatcher watcher = new GeoCoordinateWatcher();
            watcher.TryStart(false, TimeSpan.FromMilliseconds(5000));
            GeoCoordinate coord = watcher.Position.Location;
            if (!watcher.Position.Location.IsUnknown)
            {
                Latitude = watcher.Position.Location.Latitude.ToString();
                Longitude = watcher.Position.Location.Longitude.ToString();
                ////Sam Change Code
                //IGeocoder geocoder = new GoogleGeocoder(GlobalVariables.Shared.IPLocationAPIKey);
                //IEnumerable<Address> addresses = geocoder.ReverseGeocode(Convert.ToDouble(Users.Latitude), Convert.ToDouble(Users.Longitude));
                //Users.Location = ((Geocoding.Google.GoogleAddress[])(addresses))[0].FormattedAddress; 
                Location = "";
            }
            else
            {
                GetLatLon();
            }
            watcher.Stop();
            return Latitude + "^" + Longitude + "^" + Location;
        }
    }
}