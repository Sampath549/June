﻿using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [RoutePrefix("api/Test")]
    public class TestController : ApiController
    {
        [HttpPost, Authorize(Roles = "DEV"), Route("SampleCheck1")]
        public IHttpActionResult SampleCheck1()
        {
            return Ok("Developer Authorize Successful");
        }

        [HttpPost, Authorize(Roles = "ADM"), Route("SampleCheck2")]
        public IHttpActionResult SampleCheck2()
        {
            return Ok("Admin Authorize Successful");
        }

        [HttpPost, Route("LoginAuthentication")]
        public Result<SE_Users> LoginAuthentication(ArrayList ArrayAudit)
        {
            SE_Users _Result = new SE_Users();
            try
            {
                List<string> Users = new List<string>();
                foreach (string val in ArrayAudit)
                    Users.Add(val);

                TokenDAL _ObjToken = new TokenDAL();
                _Result = _ObjToken.TokenAuthentication(Users[0], Users[1]);

                if (_Result.Status == 1)
                    return Result.Success(_Result, 200, "Success", "Success");
                else
                    return Result.Failed(_Result, 500, "Error", "Error");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost, Authorize(Roles = "DEV"), Route("MyResult1")]
        public Result<string> MyResult1()
        {
            return Result.Success("Developer Authorize Successful", 200, "Success", "Success");
        }

        [HttpPost, Authorize(Roles = "ADM"), Route("MyResult2")]
        public Result<string> MyResult2()
        {
            return Result.Success("Admin Authorize Successful", 200, "Success", "Success");
        }
    }
}
