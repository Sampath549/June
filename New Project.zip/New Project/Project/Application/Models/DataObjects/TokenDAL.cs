﻿using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class TokenDAL : DataAccessComponent
    {
        public SE_Users TokenAuthentication(string Email, string Password)
        {
            SE_Users _Result = new SE_Users();

            if (Email == "sam1" && Password == "123")
            {
                _Result.Status = 1;
                _Result.RoleCode = "DEV";
            }
            else if (Email == "sam2" && Password == "567")
            {
                _Result.Status = 1;
                _Result.RoleCode = "ADM";
            }
            else
                _Result.Status = 0;

            return _Result;
        }
    }
}