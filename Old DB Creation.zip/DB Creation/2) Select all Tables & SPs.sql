
USE Emprime_Dev

SELECT * FROM [tbl_Users]
SELECT * FROM [Ref_Roles] 
SELECT * FROM [tbl_Audits]
SELECT * FROM [tbl_UserMapping]  
SELECT * FROM [tbl_UserSecurityQuestions]  
SELECT * FROM [Ref_Countries]  
SELECT * FROM [Ref_States]  
SELECT * FROM [tbl_ResetPwdLog]  
SELECT * FROM [tbl_Menus] 
SELECT * FROM [tbl_SubMenus]
SELECT * FROM [tbl_AssignMenus]
SELECT * FROM [tbl_AccommodationPosts]
SELECT * FROM [tbl_PagesForComments]
SELECT * FROM [tbl_Comments]
EXEC USP_Insert_Registration
EXEC USP_Get_AuthenticatedUser
EXEC USP_Insert_Audit
EXEC USP_Update_FailedLoginAttempts
EXEC USP_Insert_ResetPwdLog
EXEC USP_Update_ResetPwd
EXEC USP_Get_MenuListByRole
EXEC USP_Update_OneTimeLogin
EXEC USP_InsertUpdate_Roles
EXEC USP_Delete_Roles
EXEC USP_InsertUpdate_MyProfile
EXEC USP_InsertUpdate_Menus
EXEC USP_Delete_Menus
EXEC USP_InsertUpdate_SubMenus
EXEC USP_Delete_SubMenus
EXEC USP_InsertUpdate_AssignedMenus
EXEC USP_Delete_AssignedMenus
EXEC USP_InsertUpdate_Countries
EXEC USP_Delete_Countries
EXEC USP_InsertUpdate_States
EXEC USP_Delete_States
EXEC [USP_Get_Comments]
EXEC [USP_Insert_Comments]
EXEC [USP_Insert_ReplyComments]