-- Search a Column Name in Stored Procedure
SELECT      c.name  AS 'ColumnName'
            ,t.name AS 'TableName'
FROM        sys.columns c
JOIN        sys.tables  t   ON c.object_id = t.object_id
WHERE       c.name LIKE '%IsLawson%'
ORDER BY    TableName
            ,ColumnName;
--- END ---
---
-- Search text in Stored Procedure
SELECT ROUTINE_NAME, ROUTINE_DEFINITION
FROM INFORMATION_SCHEMA.ROUTINES 
WHERE ROUTINE_DEFINITION LIKE '%while%' 
AND ROUTINE_TYPE='PROCEDURE'
--- END ---
---

