USE EuroBharat

IF OBJECT_ID (N'[Ref_Roles]', N'U') IS NOT NULL 
   DROP TABLE [Ref_Roles]

CREATE TABLE [Ref_Roles]
(
[RoleId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_RefRoleId PRIMARY KEY ([RoleId]),
CONSTRAINT UC_RefRoleCode UNIQUE ([Code])
)

INSERT [Ref_Roles] ([Code], [Description]) VALUES ('DEV', 'Developer')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('SA', 'Super Admin')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('ADM', 'Admin')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('USR', 'User')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('BUS', 'Business')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('COMM', 'Community')

SELECT * FROM [Ref_Roles]  

----- END -----

IF OBJECT_ID (N'[tbl_Users]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Users]

CREATE TABLE [tbl_Users]
(
[UserId]				INT					NOT NULL IDENTITY(1,1),
[PersonalKey]			VARCHAR(800)		NOT NULL,
[FirstName]				VARCHAR(800)		NOT NULL,
[LastName]				VARCHAR(800)		NOT NULL,
[RoleId]				INT					NOT NULL,
[Password]				VARCHAR(800)		NOT NULL,
[SaltKey]				VARCHAR(800)		NOT NULL,
[EmailId]				VARCHAR(800)		NOT NULL,
[EmailCheck]				VARCHAR(800)		NOT NULL,
[Mobile]				VARCHAR(800)		NOT NULL,
[MobileCheck] 				VARCHAR(800)		NOT NULL,
[Photo]					VARCHAR(MAX)		NULL,
[ImgType]				VARCHAR(800)		NULL,
[Gender]				VARCHAR(300)			NULL,
[IsFirstTimeLogin]		BIT					DEFAULT 1,
[FailedLoginAttempts]	INT					DEFAULT 0,
[DisableAccountTime]		DATETIME			NULL,
[IsActive]				BIT					DEFAULT 1,
[CreatedBy]				INT					NOT NULL,
[CreatedDate]			DATETIME			DEFAULT GETDATE(),
[ModifiedBy]			INT					NULL,
[ModifiedDate]			DATETIME			NULL,
CONSTRAINT PK_tblUserId PRIMARY KEY ([UserId]),
CONSTRAINT FK_tblURole FOREIGN KEY ([CreatedBy]) REFERENCES [Ref_Roles]([RoleId]),
CONSTRAINT FK_tblUCreated FOREIGN KEY ([CreatedBy]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_tblUModified FOREIGN KEY ([ModifiedBy]) REFERENCES [tbl_Users]([UserId])
)

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[EmailCheck],[Mobile],[MobileCheck],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
(
'2W6ppjh+6bi2veYXNrz3LyQVLFaj+r7/9CBL2horM8MhYF/kvm5kmSZ0t//tAStkHf0IWR8cPYE8kvPO7Qmc7w==',
'AhU+KNMJioCmoJw2oT+65g2UG+mIbJUYX2v0/BCMP6c=', 
'bF3touMtIMA9H+OOVGFlNctvgi6FTNaZmF6GVQU8aw8=', 
1,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=', 
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=', 
'wHJuzGDS7F+tj6L1bEgk9ndvWaf9T9Ub7DOTvUUWfll/4fEFoDpYyV1hzLBhM61o', 
'Xk4Zw+C8PndeMJkBKVSVw5/gINK/7S+nubH4M5gQmeg=', 
'h1TIGpbN6h6XheJsxVtJyw72ufPQnyxjHGc3WbgA3os=',
'wWAOX1vUTy3SOlULE+99Bw==',
1,1,1,GETDATE()
)
---- Actual Values
--FirstName - Sampath
--LastName - Bandari
--Email - sampath.bandari51@gmail.com
--Mobile - 8121839354
--Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[EmailCheck],[Mobile],[MobileCheck],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
(
'AQqQ1INsGQmMDOX8+4aZ475FFmIBpU2BK/RD4qHdYtWkuzz5ZUBnq9/G5blj3OyZstL3IK8jCRkKxAEYo4fhlQ==',
'ELFhhNKjihz5utTrLqUVFnsHGzZaHoS2bBGQy1MCHFc=', 
'tjeTUqYYpuQYBS4pi8Wcsev7kZ+Yl8oDlsy9/8W7M6o=', 
4,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=', 
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=', 
'2IjwLTvWRbCAB5mIz6j+ZV94wv+riRUveQgN3GMMhDahQQKZA/SCsx8/JPhog3Cf', 
'YooH3Y2Ncyj7gcd7BrWVd3iUA+3eMACooOuB/wLp3hY=', 
'HAJxB6sxIbu2rtzGpXhJdZpDRj/kzdreKyRzRLM8EBs=',
'7p9ZrVaITz3LnhTZcDi2Ag==',
1,1,1,GETDATE()
)
---- Actual Values
--FirstName - User
--LastName - Account
--Email - ebtesting00002@gmail.com
--Mobile - 1234567890
--Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[EmailCheck],[Mobile],[MobileCheck],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
(
'yew8atBL/XW9qs6j4OdI4pDVEkCFN2q4KioHJ45ETHvx8w/TQ4YOcQVaF7UgOZ0WxM5Hl7zCFSwk9klXcGfRRA==',
'5NvhW91m6j3xpG7QdPnBxlVG5J79w7klbtuh/inHv+c=', 
'I6Jl6hM9Rpb0qsWbmoAFQQ+b5leoZiNdvvFx8VGTMlU=', 
5,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=', 
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=', 
'1eCE3LUF+dTRw4TrFlKA7i9faxAQu11XeAndCKrxMp2vIix2rt0R4Dlh31EzF47w', 
'wRs/IyAAWgrznAhQ0AIgDSvJiLc+IelDUBMzeKdW+Yk=', 
'wPUt0ppxKrZ+XU6V6o7CTqo2AqY0hPSiVVBnDMAHc5U=',
'IkxfPELO9OT1u+TQM71F9g==',
1,1,1,GETDATE()
)
---- Actual Values
--FirstName - Business
--LastName - Account
--Email - ebtesting00002@gmail.com
--Mobile - 1234554321
--Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[EmailCheck],[Mobile],[MobileCheck],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
(
'JY0/YMQjqk1ZbKJClbISqrJyfVECmtaRxhQlNLuLh+sEx6keZZf98GTncImpnKrStgrQ3E6KRxXJFDx1v2gxNw==',
'AUJvqIHjABBLt2jV44doyg17rRJqHRfr2u7jy8XO3mc=', 
'mMMZ/gD1hDTipVhv+IHlM2VYuUof98FBO00LuEfZrG4=', 
6,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=', 
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=', 
'ZQ1Q7f+krNSb+tljrgtl3yC/N0V2Powc0bixZxgjtvFALK15y5uL06njNH+kiLcY', 
'DNxhNXAzaB5yWkbHcWfu3JaU9k8n6OEHcULtXYhsa48=', 
'S8DVXWj+wFcH3zoxGZ7Deu6P8IhnYnZtZ/XI/+cfMpM=',
'wsLSWf+rEMYxydNj5y52pg==',
1,1,1,GETDATE()
)
---- Actual Values
--FirstName - Community
--LastName - Account
--Email - ebTesting00003@gmail.com
--Mobile - 1231231230
--Password - Euro@123

SELECT * FROM [tbl_Users]

----- END -----

IF OBJECT_ID (N'[tbl_Audits]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Audits]

CREATE TABLE [tbl_Audits]
(
[UserId]			INT				NOT NULL,
[IPAddress]			VARCHAR(100)		NOT NULL,
[EntryType]			VARCHAR(10)		NOT NULL,
[EntryFrom]			VARCHAR(10)		NOT NULL,
[Browser]			VARCHAR(600)	NOT NULL,
[Resolution]		VARCHAR(50)		NOT NULL,
[Location]			VARCHAR(500)	NOT NULL,
[Latitude]			VARCHAR(50)		NOT NULL,
[Longitude]			VARCHAR(50)		NOT NULL,
[AccessTime]		DATETIME		NOT NULL,
[IsSuccess]			BIT				NOT NULL,
CONSTRAINT UC_ALUserATime UNIQUE ([UserId], [AccessTime]),
CONSTRAINT FK_ALUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId])
)

SELECT * FROM [tbl_Audits]

----- END -----

IF OBJECT_ID (N'[tbl_UserSecurityQuestions]', N'U') IS NOT NULL 
   DROP TABLE [tbl_UserSecurityQuestions]

CREATE TABLE [tbl_UserSecurityQuestions]
(
[UserId]			INT				NOT NULL,
[SecurityQue]		VARCHAR(200)	NOT NULL,
[SecurityAns]		VARCHAR(200)	NULL,
CONSTRAINT UC_USQUserSecurity UNIQUE ([UserId], [SecurityQue]),
CONSTRAINT FK_USQUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId])
)

SELECT * FROM [tbl_UserSecurityQuestions]  

----- END -----

IF OBJECT_ID (N'[Ref_Countries]', N'U') IS NOT NULL 
   DROP TABLE [Ref_Countries]

CREATE TABLE [Ref_Countries]
(
[CountryId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_CountryId PRIMARY KEY ([CountryId]),
CONSTRAINT UC_CountryCodeDesc UNIQUE ([Code],[Description])
)

INSERT [Ref_Countries] ([Code], [Description]) VALUES ('AUS', 'Austria')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('BEL', 'Belgium')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('BUL', 'Bulgaria')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('CRO', 'Croatia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('CYP', 'Cyprus')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('CZE', 'Czechia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('DEN', 'Denmark')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('EST', 'Estonia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('FIN', 'Finland')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('FRA', 'France')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('GER', 'Germany')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('GRE', 'Greece')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('HUN', 'Hungary')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('IRE', 'Ireland')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('ITA', 'Italy')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('LAT', 'Latvia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('LIT', 'Lithuania')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('LUX', 'Luxembourg')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('MAL', 'Malta')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('NET', 'Netherlands')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('POL', 'Poland')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('POR', 'Portugal')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('ROM', 'Romania')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('SLO', 'Slovakia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('SLOV', 'Slovenia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('SPA', 'Spain')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('SWE', 'Sweden')

SELECT * FROM [Ref_Countries]  

----- END -----
IF OBJECT_ID (N'[Ref_States]', N'U') IS NOT NULL 
   DROP TABLE [Ref_States]

CREATE TABLE [Ref_States]
(
[StateId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CountryId]		INT				NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_StateId PRIMARY KEY ([StateId]),
CONSTRAINT FK_CState FOREIGN KEY ([CountryId]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT UC_StateCodeDesc UNIQUE ([Code],[Description])
)

INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('BER', 'Berlin', 11)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('HAM', 'Hamburg', 11)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('SAA', 'Saarland', 11)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('WAR', 'Warsaw', 21)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('OPO', 'Opole', 21)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('MAS', 'Masovian', 21)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('BUD', 'Budapest', 13)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('FEJ', 'Fejer', 13)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('NOG', 'Nograd', 13)

SELECT * FROM [Ref_States]  

----- END -----

IF OBJECT_ID (N'[tbl_UserMapping]', N'U') IS NOT NULL 
   DROP TABLE [tbl_UserMapping]

CREATE TABLE [tbl_UserMapping]
(
[UserId]					INT				NOT NULL,
[IsPermanentAddress]		BIT				NULL,
[PermanentStreetAddress]	VARCHAR(MAX)	NULL,
[PermanentCity]				VARCHAR(800)	NULL,
[PermanentState]			INT				NULL,
[PermanentCountry]			INT				NULL,
[PermanentZipCode]			BIGINT			NULL,
[CurrentStreetAddress]		VARCHAR(MAX)	NULL,
[CurrentCity]				VARCHAR(800)	NULL,
[CurrentState]				INT				NULL,
[CurrentCountry]			INT				NULL,
[CurrentZipCode]			BIGINT			NULL,
CONSTRAINT FK_UMUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_UMPState FOREIGN KEY ([PermanentState]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_UMPCountry FOREIGN KEY ([PermanentCountry]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT FK_UMCState FOREIGN KEY ([CurrentState]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_UMCCountry FOREIGN KEY ([CurrentCountry]) REFERENCES [Ref_Countries]([CountryId])
)

SELECT * FROM [tbl_UserMapping]  

----- END -----

IF OBJECT_ID (N'[tbl_ResetPwdLog]', N'U') IS NOT NULL 
   DROP TABLE [tbl_ResetPwdLog]

CREATE TABLE [tbl_ResetPwdLog]
(
[ResetPwdLogId]		INT				NOT NULL IDENTITY(1,1),
[UserId]			INT				NOT NULL,
[GuidVal]			VARCHAR(800)	NOT NULL,
[IsReset]			BIT				NOT NULL,
[EntryDate]			DATETIME		NOT NULL
CONSTRAINT PK_ResetPwdLogId PRIMARY KEY ([ResetPwdLogId]),
CONSTRAINT FK_RPwdUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId])
)

SELECT * FROM [tbl_ResetPwdLog]

----- END -----

IF OBJECT_ID (N'[tbl_Menus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Menus]

CREATE TABLE [tbl_Menus]
(
[ParentId]		INT				NOT NULL IDENTITY(1,1),
[Header]		VARCHAR(50)		NOT NULL,
[Controller]	VARCHAR(50)		NULL,
[Action]		VARCHAR(50)		NULL,
[HavingChild]	BIT				NOT NULL,
[Order]			INT				NOT NULL,
[Icon]			VARCHAR(50)		NOT NULL,
CONSTRAINT PK_ParentId PRIMARY KEY ([ParentId]),
CONSTRAINT UC_PHeaderControllerAction UNIQUE ([Header],[Controller],[Action])
)

INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Dashboard', 'CPanelDev', 'Dashboard', 0, 1, 'fa fa-bookmark-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('All Users', NULL, NULL, 1, 2, 'fa fa-user-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Master Data', NULL, NULL, 1, 3, 'fa fa-star-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Error Log', 'CPanelDev', 'ViewErrorLog', 0, 4, 'fa fa-exclamation-triangle')

INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Dashboard', 'CPanelUser', 'Dashboard', 0, 1, 'fa fa-bookmark-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Accommodation', NULL, NULL, 1, 2, 'fa fa-user-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Buy / Sell',  NULL, NULL, 1, 3, 'fa fa-star-o')

SELECT * FROM [tbl_Menus]  

----- END -----

IF OBJECT_ID (N'[tbl_SubMenus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_SubMenus]

CREATE TABLE [tbl_SubMenus]
(
[ChildId]		INT 			NOT NULL IDENTITY(1,1),
[ParentId]		INT				NOT NULL,
[Header]		VARCHAR(50)		NOT NULL,
[Controller]	VARCHAR(50)		NOT NULL,
[Action]		VARCHAR(50)		NOT NULL,
[Order]			INT				NOT NULL,
CONSTRAINT PK_ChildId PRIMARY KEY ([ChildId]),
CONSTRAINT FK_SMenusParentId FOREIGN KEY ([ParentId]) REFERENCES [tbl_Menus]([ParentId]),
CONSTRAINT UC_CHeaderControllerAction UNIQUE ([Header],[Controller],[Action])
)

INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Create', 'CPanelDev', 'CreateAllUsers', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Details', 'CPanelDev', 'AllUserDetails', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Roles', 'CPanelDev', 'CreateRole', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Menus', 'CPanelDev', 'CreateMenus', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Sub Menus', 'CPanelDev', 'CreateSubMenus', 3)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Assigned Menus', 'CPanelDev', 'CreateAssignedMenus', 4)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Countries', 'CPanelDev', 'CreateCountries', 5)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'States', 'CPanelDev', 'CreateStates', 6)

INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (6, 'Posts', 'CPanelUser', 'AccommodationPosts', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (6, 'Requests', 'CPanelUser', 'AccommodationRequests', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (7, 'Posts', 'CPanelUser', 'BuySellPosts', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (7, 'Requests', 'CPanelUser', 'BuySellRequests', 2)

SELECT * FROM [tbl_SubMenus]

----- END -----

IF OBJECT_ID (N'[tbl_AssignMenus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_AssignMenus]

CREATE TABLE [tbl_AssignMenus]
(
[AssignMenuId]	INT 	NOT NULL IDENTITY(1,1),
[ParentId]		INT		NOT NULL,
[RoleId]		INT		NOT NULL,
CONSTRAINT PK_AssignMenuId PRIMARY KEY ([AssignMenuId]),
CONSTRAINT FK_AMenusParentId FOREIGN KEY ([ParentId]) REFERENCES [tbl_Menus]([ParentId]),
CONSTRAINT FK_AMenusRoleId FOREIGN KEY ([RoleId]) REFERENCES [Ref_Roles]([RoleId]),
CONSTRAINT UC_AMenusParentRole UNIQUE ([ParentId],[RoleId])
)

INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (1, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (2, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (3, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (4, 1)

INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (5, 4)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (6, 4)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (7, 4)

SELECT * FROM [tbl_AssignMenus]

----- END -----

IF OBJECT_ID (N'[tbl_AccommodationPosts]', N'U') IS NOT NULL 
   DROP TABLE [tbl_AccommodationPosts]

CREATE TABLE [tbl_AccommodationPosts]
(
[AccommodationPostId]		INT 			NOT NULL IDENTITY(1,1),
[UserId]					INT				NOT NULL,
[Title]						VARCHAR(30)		NOT NULL,
[RoomType]					VARCHAR(50)		NOT NULL,
[Address]					VARCHAR(50)		NOT NULL,
[City]						VARCHAR(30)		NOT NULL,
[StateId]					INT				NOT NULL,
[CountryId]					INT				NOT NULL,
[ZipCode]					BIGINT			NOT NULL,
[ImagePath]					VARCHAR(MAX)	NULL,
[ImgType]					VARCHAR(100)	NULL,
[Description]				VARCHAR(300)	NOT NULL,
[CreatedDate]				DATETIME		NOT NULL
CONSTRAINT PK_AccommodationPostId PRIMARY KEY ([AccommodationPostId]),
CONSTRAINT FK_AccPUserId FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_AccPStateId FOREIGN KEY ([StateId]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_AccPCountryId FOREIGN KEY ([CountryId]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT UC_AccPTitle UNIQUE ([Title],[UserId],[Address])	
)
----- END -----

IF OBJECT_ID (N'[tbl_PagesForComments]', N'U') IS NOT NULL 
   DROP TABLE [tbl_PagesForComments]

CREATE TABLE [tbl_PagesForComments]
(
[PageId]		INT 			NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_CPageId PRIMARY KEY ([PageId]),
CONSTRAINT UC_CPCode UNIQUE ([Code])
)

INSERT INTO [tbl_PagesForComments] ([Code], [Description]) VALUES ('ACPOS', 'AccPosts')

----- END -----

IF OBJECT_ID (N'[tbl_Comments]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Comments]

CREATE TABLE [tbl_Comments]
(
[CommentId]		INT				NOT NULL IDENTITY(1,1),
[UserId]		INT				NOT NULL,
[PageId]		INT				NOT NULL,
[PageColumnId]	INT				NOT NULL,
[Comments]		VARCHAR(500)	NOT NULL,
[ParentCommentId]	INT			NOT NULL,
[HavingParentCommentId]	BIT		NOT NULL DEFAULT 0,
[CommentedDate]	DATETIME		DEFAULT GETDATE(),
CONSTRAINT PK_CommentId PRIMARY KEY ([CommentId]),
CONSTRAINT FK_CommUserId FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_CommPageId FOREIGN KEY ([PageId]) REFERENCES [tbl_PagesForComments]([PageId])
)

----- END -----


