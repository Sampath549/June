USE [EuroBharat]

GO
CREATE PROCEDURE [USP_Insert_Registration]
( 
  @PersonalKey      VARCHAR(800),
  @FirstName		VARCHAR(800),
  @LastName         VARCHAR(800),
  @Email            VARCHAR(800),
  @Mobile           VARCHAR(800),
  @RoleCode         VARCHAR(10),
  @Password         VARCHAR(800),
  @SaltKey          VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 
	INSERT INTO [EuroDB].[tbl_Users] (PersonalKey, FirstName, LastName, EmailId, Mobile, RoleId, [Password], SaltKey, CreatedBy)
	VALUES (@PersonalKey, @FirstName, @LastName, @Email, @Mobile,(SELECT RoleId FROM [Ref_Roles] WHERE Code = @RoleCode), @Password, @SaltKey, 1)
END		

----- END -----

GO
CREATE PROCEDURE [USP_Get_AuthenticatedUser]
( 
 @EmailId	VARCHAR(800),  
 @Password		VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 

	DECLARE @Status					VARCHAR(5),  
			@UserId					INT = NULL,  
			@FirstName				VARCHAR(800) = NULL,
			@LastName				VARCHAR(800) = NULL,
			@FullName				VARCHAR(800) = NULL,
			@Email					VARCHAR(800) = NULL,
			@Mobile					VARCHAR(800) = NULL,
			@RoleID					INT = NULL,  
			@RoleCode				VARCHAR(50) = NULL,  
			@IsFirstTimeLogin		BIT = NULL,
			@ProfilePic				VARCHAR(MAX) = NULL,
			@FailedLoginAttempts	INT = NULL,
			@DisableAccountTime		DATETIME = NULL,
			@TimeDiff				INT = NULL

	IF (SELECT Count(*) FROM [EuroDB].[tbl_Users] WHERE EmailId = @Email AND @Password = @Password) = 0  
		BEGIN  
			SET @Status = 0   
			SET @DisableAccountTime = (SELECT DisableAccountTime FROM [EuroDB].[tbl_Users] WHERE  EmailId = @EmailId) 
			SET @FailedLoginAttempts = (SELECT FailedLoginAttempts FROM [EuroDB].[tbl_Users] WHERE  EmailId = @EmailId)
		END  
	ELSE  
		BEGIN  
			SELECT  @Status = 1,  
					@UserId = U.UserId,  
					@FirstName = U.FirstName,  
					@LastName = U.LastName, 
					@FullName = (U.FirstName + ' ' + U.LastName),  
					@Email = U.EmailId,  
					@Mobile = U.Mobile,  
					@RoleID = U.RoleId,  
					@RoleCode = R.Code,  
					@ProfilePic = U.Photo,
					@IsFirstTimeLogin = U.IsFirstTimeLogin,		 
					@FailedLoginAttempts = U.FailedLoginAttempts,
					@DisableAccountTime = U.DisableAccountTime 
			FROM   
				[EuroDB].[tbl_Users] U
			INNER JOIN [EuroDB].[Ref_Roles] R ON U.RoleId = R.RoleId
			WHERE U.EmailId = @Email  AND U.[Password] = @Password

			IF (SELECT Count(*) FROM [EuroDB].[tbl_UserMapping] WHERE UserId = @UserId) = 0  
				BEGIN
					INSERT INTO [EuroDB].[tbl_UserMapping] (UserId) VALUES (@UserId)
				END

			DECLARE @DisableTime DATETIME
			SET @DisableTime = (SELECT DisableAccountTime FROM [EuroDB].[tbl_Users] WHERE UserId = (SELECT UserId FROM [EuroDB].[tbl_Users] WHERE EmailId = @EmailId))

			IF(@DisableTime) IS NULL
				BEGIN
					UPDATE [EuroDB].[tbl_Users] SET FailedLoginAttempts = NULL, DisableAccountTime = NULL WHERE UserId= (SELECT UserId FROM [EuroDB].[tbl_Users] WHERE EmailId = @EmailId)
				END
			ELSE
				SET @TimeDiff = (SELECT DATEDIFF (mi, @DisableTime, GETDATE()))
				IF((SELECT DATEDIFF (mi, @DisableTime, GETDATE())) >= 5)
					BEGIN
						UPDATE [EuroDB].[tbl_Users] SET FailedLoginAttempts = NULL, DisableAccountTime = NULL WHERE UserId= (SELECT UserId FROM [EuroDB].[tbl_Users] WHERE EmailId = @EmailId)
					END
	  END  


	SELECT @Status AS [Status],
			@UserId AS UserId,
			@FirstName AS FirstName,
			@LastName AS LastName,
			@FullName AS FullName,
			@Email AS Email,
			@Mobile AS Mobile,
			@RoleID AS RoleID, 
			@RoleCode AS RoleCode,
			@ProfilePic AS Photo,
			@IsFirstTimeLogin AS IsFirstTimeLogin,
			@FailedLoginAttempts AS FailedLoginAttempts, 
			@DisableAccountTime AS DisableAccountTime, 
			@TimeDiff AS TimeDiff
END 

----- END -----

GO
CREATE PROCEDURE [USP_Insert_Audit]
( 
  @UserId INT,
  @IPAddr VARCHAR(100),
  @EntryType VARCHAR(10),
  @EntryFrom VARCHAR(10),
  @Browser VARCHAR(600),
  @Resolution VARCHAR(50),
  @Location VARCHAR(500),
  @Latitude VARCHAR(50),
  @Longitude VARCHAR(50),
  @IsSuccess BIT
) 
AS 
BEGIN 
	SET NOCOUNT ON; 

	INSERT INTO [EuroDB].[tbl_Audits] (UserId, IPAddress, EntryType, EntryFrom, Browser, Resolution, [Location], Latitude, Longitude, AccessTime, IsSuccess) 
	VALUES (@UserId, @IPAddr, @EntryType, @EntryFrom, @Browser, @Resolution, @Location, @Latitude, @Longitude, GETDATE(), @IsSuccess)
END 

----- END -----

GO
CREATE PROCEDURE [USP_Update_FailedLoginAttempts]
(  
  @UserId INT
)  
AS  
BEGIN  
	SET NOCOUNT ON;  

	IF (SELECT FailedLoginAttempts FROM [EuroDB].[tbl_Users] WHERE UserId = @UserId) IS NOT NULL
		BEGIN
			DECLARE @CountNum INT
			SET @CountNum = (SELECT FailedLoginAttempts FROM [EuroDB].[tbl_Users] WHERE UserId = @UserId) + 1 
			IF(@CountNum > 4)
				BEGIN
					UPDATE [EuroDB].[tbl_Users] SET FailedLoginAttempts = @CountNum, DisableAccountTime = GETDATE() WHERE UserId = @UserId
				END
			ELSE
				BEGIN
					UPDATE [EuroDB].[tbl_Users] SET FailedLoginAttempts = @CountNum WHERE UserId = @UserId
				END
		END
	ELSE
		BEGIN
			UPDATE [EuroDB].[tbl_Users] SET FailedLoginAttempts = 1 WHERE UserId = @UserId
		END
  END  

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Insert_ResetPwdLog]
( 
  @UserId		INT,
  @GuidVal		VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 
	INSERT INTO [EuroDB].[tbl_ResetPwdLog] (UserId, GuidVal, IsReset, EntryDate)
	VALUES (@UserId, @GuidVal, 0, GETDATE())
END	

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Update_ResetPwd]
(  
  @UserId INT,
  @Password VARCHAR(800),
  @SaltKey VARCHAR(800),
  @GuidVal VARCHAR(800),
  @ExpiryTime INT,
  @OutputResult INT = 0 OUT
)  
AS  
BEGIN  
	SET NOCOUNT ON;  
	DECLARE @CurrentTime DATETIME = GETDATE()
	DECLARE @DiffTime INT = (SELECT DATEDIFF(MINUTE,(SELECT EntryDate FROM [EuroDB].[tbl_ResetPwdLog] WHERE GuidVal = @GuidVal), @CurrentTime))
	IF(@DiffTime > @ExpiryTime)
		BEGIN
			SET @OutputResult = 99 --Expierd
		END
	ELSE
		BEGIN
			IF((SELECT IsReset FROM [EuroDB].[tbl_ResetPwdLog] WHERE GuidVal = @GuidVal) > 0)
				BEGIN
					SET @OutputResult = 100 --Already Update
				END
			ELSE
				BEGIN	
					BEGIN TRANSACTION;
					SAVE TRANSACTION MySavePoint;

						BEGIN TRY
							UPDATE [EuroDB].[tbl_ResetPwdLog] SET IsReset = 1 WHERE GuidVal = @GuidVal
							UPDATE [EuroDB].[tbl_Users] SET [Password] = @Password , [SaltKey] = @SaltKey WHERE UserId = @UserId
							SET @OutputResult = 1	
						END TRY
						BEGIN CATCH
							IF @@TRANCOUNT > 0
							BEGIN
								SET @OutputResult = 0
								ROLLBACK TRANSACTION MySavePoint; 
							END
						END CATCH
						COMMIT TRANSACTION 
					END
				END
		
END 
-- EXEC [USP_Update_ResetPassword] 2,'asd','dsa','Ojypmq83TwS8IJXRzJ/nXC9V2gdu7HFcwYVdpwIpQ+tgkvIcNXeBwGjay1wgDsp1f1/jd6LI/AFKjWSCB70jNw==',900, 0

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Get_MenuListByRole]
(
	@RoleCode	VARCHAR(10)
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RoleId INT
	SET @RoleId= (SELECT RoleId FROM [EuroDB].[Ref_Roles] WHERE Code = @RoleCode)

	SELECT
		AM.ParentId,
		M.Header,
		M.Controller,
		M.[Action],
		M.HavingChild,
		M.[Order],
		M.Icon
	FROM [EuroDB].[tbl_AssignMenus] AS AM
	INNER JOIN [EuroDB].[tbl_Menus] M ON M.ParentId= AM.ParentId
	WHERE AM.RoleId = @RoleId
	
	SELECT
		AM.ParentId,
		SM.Header,
		SM.Controller,
		SM.[Action],
		SM.[Order]
	FROM [EuroDB].[tbl_AssignMenus] AS AM
	INNER JOIN [EuroDB].[tbl_SubMenus] SM ON SM.ParentId= AM.ParentId
	WHERE AM.RoleId = @RoleId	

END
-- EXEC USP_Get_MenuListByRole 132,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Update_OneTimeLogin]
(
	@UserId INT ,
	@OldPwd VARCHAR(800),
	@OldKey VARCHAR(800),
	@NewPwd VARCHAR(800),
	@NewKey VARCHAR(800),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF((SELECT COUNT(*) FROM [EuroDB].[tbl_Users] WHERE UserId = @UserId) > 0)
		BEGIN
			IF((SELECT COUNT(*) FROM [EuroDB].[tbl_Users] WHERE [Password] = @OldPwd AND SaltKey = @OldKey) > 0)
				BEGIN
					UPDATE [EuroDB].[tbl_Users] SET [Password] = @NewPwd , SaltKey = @NewKey, IsFirstTimeLogin = 0 WHERE UserId = @UserId
					SET @OutPut = 1 
				END
			ELSE
				SET @OutPut = 99 -- Old Password Incorrect
		END
	ELSE
		SET @OutPut = 100 -- No User
END

-- EXEC [USP_Update_OneTimeLogin] 132,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_InsertUpdate_Roles]
(
	@Code VARCHAR(5),
	@Desc VARCHAR(100),
	@btnType VARCHAR(15),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF(@btnType = 'Save')
		BEGIN
			IF((SELECT COUNT(*) FROM [EuroDB].[Ref_Roles] WHERE Code= @Code) = 0)
				BEGIN				
					INSERT INTO [EuroDB].[Ref_Roles] (Code, [Description], CreatedDate) VALUES (@Code, @Desc, GETDATE())
					SET @OutPut = 1
				END
			ELSE
				SET @OutPut = 99 -- Duplicate Code
		END
	ELSE IF(@btnType = 'Update')
		BEGIN
			UPDATE [EuroDB].[Ref_Roles] SET [Description] = @Desc, ModifiedDate = GETDATE() WHERE Code = @Code
			SET @OutPut = 1 
		END
	ELSE 
		SET @OutPut = 100 -- Button Text
END
-- EXEC [USP_InsertUpdate_Roles] 132,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Delete_Roles]
(
	@Code VARCHAR(5),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF((SELECT COUNT(*) FROM [EuroDB].[Ref_Roles] WHERE Code= @Code) > 0)
		BEGIN				
			DELETE FROM [EuroDB].[Ref_Roles] WHERE Code = @Code
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Duplicate Code
END
-- EXEC [USP_Delete_Roles] 132,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_InsertUpdate_MyProfile]
(
	@ActualEmail		VARCHAR(800),
	@FirstName			VARCHAR(800),
	@LastName			VARCHAR(800),
	@Gender				VARCHAR(500) = NULL,
	@PAddress			VARCHAR(800) = NULL,
	@PCity				VARCHAR(800) = NULL,
	@PStateId			INT = NULL,
	@PCountryId			INT = NULL,
	@PZipCode			BIGINT = NULL,
	@isCurrentPermanent	BIT = NULL,
	@CAddress			VARCHAR(800) = NULL,
	@CCity				VARCHAR(800) = NULL,
	@CStateId			INT = NULL,
	@CCountryId			INT = NULL,
	@CZipCode			BIGINT = NULL,
	@ProfilePic			VARCHAR(MAX) = NULL,
	@ImgType			VARCHAR(800) = NULL,
	@OutputResult		INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;
	
	BEGIN TRANSACTION;
	SAVE TRANSACTION MySavePoint;
		BEGIN TRY
		
		DECLARE @UserId INT
		SET @UserId= (SELECT UserId FROM [EuroDB].[tbl_Users] WHERE EmailId = @ActualEmail)
		
		IF(@isCurrentPermanent = 1)
			BEGIN
				UPDATE [EuroDB].[tbl_Users] SET [FirstName] = @FirstName, [LastName] = @LastName, [Gender] = @Gender, [Photo] = @ProfilePic, ImgType = @ImgType, [ModifiedDate] = GETDATE() WHERE UserId = @UserId
				UPDATE [EuroDB].[tbl_UserMapping] 
							SET [IsPermanentAddress] = @isCurrentPermanent,	
								[PermanentStreetAddress] = @PAddress,
								[PermanentCity] = @PCity,
								[PermanentState] = @PStateId,
								[PermanentCountry] = @PCountryId,
								[PermanentZipCode] = @PZipCode,
								[CurrentStreetAddress] = NULL,
								[CurrentCity] = NULL,
								[CurrentState] = NULL,
								[CurrentCountry] = NULL,
								[CurrentZipCode] = NULL
							WHERE UserId = @UserId
				SET @OutputResult = 1	
			END	
		ELSE
			BEGIN
				UPDATE [EuroDB].[tbl_Users] SET [FirstName] = @FirstName, [LastName] = @LastName, [Gender] = @Gender, [Photo] = @ProfilePic, ImgType = @ImgType, [ModifiedDate] = GETDATE() WHERE UserId = @UserId
				UPDATE [EuroDB].[tbl_UserMapping] 
							SET [IsPermanentAddress] = @isCurrentPermanent,	
								[PermanentStreetAddress] = @PAddress,
								[PermanentCity] = @PCity,
								[PermanentState] = @PStateId,
								[PermanentCountry] = @PCountryId,
								[PermanentZipCode] = @PZipCode,
								[CurrentStreetAddress] = @CAddress,
								[CurrentCity] = @CCity,
								[CurrentState] = @CStateId,
								[CurrentCountry] = @CCountryId,
								[CurrentZipCode] = @CZipCode
							WHERE UserId = @UserId
				SET @OutputResult = 1	
			END
			
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
			BEGIN
				SET @OutputResult = 0
				ROLLBACK TRANSACTION MySavePoint; 
			END
		END CATCH
		COMMIT TRANSACTION 
	END	
--EXEC USP_InsertUpdate_MyProfile

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_InsertUpdate_Menus]
(
	@Type			VARCHAR(15),
	@ParentId		INT = NULL,
	@Header			VARCHAR(50),
	@Controller		VARCHAR(50) = NULL,
	@Action			VARCHAR(50) = NULL,
	@HavingChild	BIT,
	@Order			INT,
	@Icon			VARCHAR(50),
	@OutPut			INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF(@Type = 'Insert')
		BEGIN
			INSERT INTO [EuroDB].[tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES (@Header, @Controller, @Action, @HavingChild, @Order, @Icon)
			SET @OutPut = 1
		END
	ELSE IF(@Type = 'Update')
		BEGIN
			UPDATE [EuroDB].[tbl_Menus] SET [Header] = @Header, [Controller] = @Controller, [Action] = @Action, [HavingChild] = @HavingChild, [Order] = @Order, [Icon] = @Icon WHERE ParentId = @ParentId
			SET @OutPut = 1
		END
	ELSE 
		SET @OutPut = 0
END
-- EXEC [USP_InsertUpdate_Menus] 132,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Delete_Menus]
(
	@ParentId		INT,
	@OutPut			INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF((SELECT COUNT(*) FROM [EuroDB].[tbl_Menus] WHERE ParentId= @ParentId) > 0)
		BEGIN				
			DELETE FROM [EuroDB].[tbl_Menus] WHERE ParentId = @ParentId
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Not Id
END
-- EXEC [USP_Delete_Menus] 132,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_InsertUpdate_SubMenus]
(
	@Type			VARCHAR(15),
	@ChildId		INT = NULL,
	@ParentId		INT,
	@Header			VARCHAR(50),
	@Controller		VARCHAR(50) = NULL,
	@Action			VARCHAR(50) = NULL,
	@Order			INT,
	@OutPut			INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF(@Type = 'Insert')
		BEGIN
			INSERT INTO [EuroDB].[tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (@ParentId, @Header, @Controller, @Action, @Order)
			SET @OutPut = 1
		END
	ELSE IF(@Type = 'Update')
		BEGIN
			UPDATE [EuroDB].[tbl_SubMenus] SET  [ParentId] = @ParentId, [Header] = @Header, [Controller] = @Controller, [Action] = @Action, [Order] = @Order WHERE ChildId = @ChildId
			SET @OutPut = 1
		END
	ELSE 
		SET @OutPut = 0
END
-- EXEC [[USP_InsertUpdate_SubMenus] 132,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Delete_SubMenus]
(
	@ChildId		INT,
	@OutPut			INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF((SELECT COUNT(*) FROM [EuroDB].[tbl_SubMenus] WHERE ChildId= @ChildId) > 0)
		BEGIN				
			DELETE FROM [EuroDB].[tbl_SubMenus] WHERE ChildId = @ChildId
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Not Id
END
-- EXEC [USP_Delete_SubMenus] 132,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_InsertUpdate_AssignedMenus]
(
	@Type				VARCHAR(15),
	@AssignedMenuId		INT = NULL,
	@ParentId			INT,
	@RoleId				INT,
	@OutPut			INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF(@Type = 'Insert')
		BEGIN
			INSERT INTO  [EuroDB].[tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (@ParentId, @RoleId)
			SET @OutPut = 1
		END
	ELSE IF(@Type = 'Update')
		BEGIN
			UPDATE [EuroDB].[tbl_AssignMenus] SET [ParentId] = @ParentId, [RoleId] = @RoleId WHERE AssignMenuId= @AssignedMenuId
			SET @OutPut = 1
		END
	ELSE 
		SET @OutPut = 0
END

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Delete_AssignedMenus]
(
	@AssignMenuId		INT,
	@OutPut				INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF((SELECT COUNT(*) FROM [EuroDB].[tbl_AssignMenus] WHERE AssignMenuId = @AssignMenuId) > 0)
		BEGIN				
			DELETE FROM [EuroDB].[tbl_AssignMenus] WHERE AssignMenuId = @AssignMenuId
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Not Id
END

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Get_UserMappingDetails]
( 
 @Email	VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 

	DECLARE @UserId INT
	
	IF (SELECT Count(*) FROM [EuroDB].[tbl_Users] WHERE EmailId = @Email) > 0  
		BEGIN  
			SET @UserId= (SELECT UserId FROM [EuroDB].[tbl_Users] WHERE EmailId = @Email)

			SELECT	U.UserId,
					U.Gender,
					U.Photo,  
					U.ImgType,  
					UM.IsPermanentAddress, 
					UM.PermanentStreetAddress [PAddress],
					UM.PermanentCity [PCity],
					UM.PermanentState [PStateId],
					UM.PermanentCountry [PCountryId],
					UM.PermanentZipCode [PZipCode],
					UM.CurrentStreetAddress [CAddress],
					UM.CurrentCity [CCity],
					UM.CurrentState [CStateId],
					UM.CurrentCountry [CCountryId],
					UM.CurrentZipCode [CZipCode]
			FROM   
				[EuroDB].[tbl_Users] U
			INNER JOIN [EuroDB].[tbl_UserMapping] UM ON U.UserId = UM.UserId
			WHERE U.UserId = @UserId
		END  
END 

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_InsertUpdate_Countries]
(
	@Type			VARCHAR(15),
	@Id				INT = NULL,
	@Code			VARCHAR(50) = NULL,
	@Desc			VARCHAR(50) = NULL,
	@OutPut			INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF(@Type = 'Insert')
		BEGIN
			INSERT INTO [EuroDB].[Ref_Countries] ([Code], [Description]) VALUES (@Code, @Desc)
			SET @OutPut = 1
		END
	ELSE IF(@Type = 'Update')
		BEGIN
			UPDATE [EuroDB].[Ref_Countries] SET [Description] = @Desc WHERE CountryId = @Id
			SET @OutPut = 1
		END
	ELSE 
		SET @OutPut = 0
END

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Delete_Countries]
(
	@Id		INT,
	@OutPut			INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF((SELECT COUNT(*) FROM [EuroDB].[Ref_Countries] WHERE CountryId= @Id) > 0)
		BEGIN				
			DELETE FROM [EuroDB].[Ref_Countries] WHERE CountryId = @Id
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Not Id
END

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Insert_AccPosts]
(
	@UserId			INT,
	@Title			VARCHAR(30),
	@RoomType		VARCHAR(50),
	@Address		VARCHAR(50),
	@City			VARCHAR(30),
	@StateId		INT,
	@CountryId		INT,
	@Description	VARCHAR(300),
	@ZipCode		BIGINT,
	@ImagePath		VARCHAR(MAX) = NULL,
	@ImgType		VARCHAR(100) = NULL,
	@OutPut			INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO [EuroDB].[tbl_AccommodationPosts] ([UserId], [Title], [RoomType], [Address], [City], [StateId], [CountryId], [ZipCode], [Description], [ImagePath], [ImgType], [CreatedDate]) VALUES (@UserId, @Title, @RoomType, @Address, @City, @StateId, @CountryId, @ZipCode, @Description,@ImagePath, @ImgType, GETDATE())
	SET @OutPut = 1
END
-- EXEC [USP_Insert_AccPosts] 132,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Get_Comments]
(
	@PageId			INT,
	@PageColumnId	INT
)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		C.CommentId,
		C.ParentCommentId,
		C.[Comments ] AS [Comments],
		C.UserId,
		C.PageId, 
		C.PageColumnId,
		C.HavingParentCommentId,
		U.FirstName,
		U.LastName,
		U.Photo,
		C.CommentedDate,
		(SELECT COUNT(*) FROM [EuroDB].[tbl_Comments] WHERE PageId = @PageId AND PageColumnId = @PageId) TotalComments
	FROM [EuroDB].[tbl_Comments] C
	INNER JOIN [EuroDB].[tbl_Users] U ON U.UserId = C.UserId
	WHERE C.PageId = @PageId AND C.PageColumnId = @PageColumnId AND ParentCommentId = 0
	ORDER By C.CommentedDate

	SELECT 
		C.CommentId,
		C.ParentCommentId,
		C.[Comments ] AS [Comments],
		C.UserId,
		C.PageId, 
		C.PageColumnId,
		C.HavingParentCommentId,
		U.FirstName,
		U.LastName,
		U.Photo,
		C.CommentedDate
	FROM [EuroDB].[tbl_Comments] C
	INNER JOIN [EuroDB].[tbl_Users] U ON U.UserId = C.UserId
	WHERE C.PageId = @PageId AND C.PageColumnId = @PageColumnId AND C.HavingParentCommentId != 0 AND ParentCommentId != 0
	ORDER By C.CommentedDate
END
-- EXEC [USP_Get_Comments] 1,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Insert_Comments]
(
	@UserId				INT,
	@PageIdVal			VARCHAR(100),
	@PageColumnId		INT,
	@Comments			VARCHAR(500),
	@OutPut				INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRANSACTION;
	SAVE TRANSACTION MySavePoint;
		BEGIN TRY
			INSERT INTO [EuroDB].[tbl_Comments] ([UserId], [PageId], [PageColumnId], [Comments ], [ParentCommentId], [CommentedDate]) VALUES (@UserId, (SELECT PageId FROM [EuroDB].[tbl_PagesForComments] WHERE [Description] = @PageIdVal), @PageColumnId, @Comments, 0, GETDATE())
			SET @OutPut = 1	
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				BEGIN
					SET @OutPut = 0
					ROLLBACK TRANSACTION MySavePoint; 
				END
		END CATCH
		COMMIT TRANSACTION 
END
-- EXEC [USP_Insert_Comments] 2,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Insert_ReplyComments]
(
	@UserId				INT,
	@PageIdVal			VARCHAR(100),
	@PageColumnId		INT,
	@Comments			VARCHAR(500),
	@ParentCommentId	INT,
	@OutPut				INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRANSACTION;
	SAVE TRANSACTION MySavePoint;
		BEGIN TRY
			INSERT INTO [EuroDB].[tbl_Comments] ([UserId], [PageId], [PageColumnId], [Comments ], [ParentCommentId],HavingParentCommentId, [CommentedDate]) VALUES (@UserId, (SELECT PageId FROM [EuroDB].[tbl_PagesForComments] WHERE [Description] = @PageIdVal), @PageColumnId, @Comments, @ParentCommentId, 1, GETDATE())
			UPDATE [EuroDB].[tbl_Comments] SET HavingParentCommentId = 1 WHERE CommentId = @ParentCommentId
			SET @OutPut = 1	
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				BEGIN
					SET @OutPut = 0
					ROLLBACK TRANSACTION MySavePoint; 
				END
		END CATCH
		COMMIT TRANSACTION 
END
-- EXEC [USP_Insert_ReplyComments] 2,4


----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Delete_AccPosts]
(
	@UserId				INT,
	@AccPostId			INT,
	@OutPut				INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRANSACTION;
	SAVE TRANSACTION MySavePoint;
		BEGIN TRY
			DELETE FROM [EuroDB].[tbl_Comments] WHERE PageId = 1 AND PageColumnId = @AccPostId
			DELETE FROM [EuroDB].[tbl_AccommodationPosts] WHERE UserId = @UserId AND AccommodationPostId = @AccPostId
			SET @OutPut = 1	
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				BEGIN
					SET @OutPut = 0
					ROLLBACK TRANSACTION MySavePoint; 
				END
		END CATCH
		COMMIT TRANSACTION 
END
-- EXEC [USP_Delete_AccPosts] 2,4

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Get_GridAccPosts]
(
	@PNum		INT,
	@PSize		INT,
	@UID		INT
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Val INT
	SET @Val = (@PNum * @PSize) - @PSize

	SELECT 
		AP.AccommodationPostId, 
	    AP.UserId,
        U.FirstName,
	    U.LastName,
	    AP.Title,
	    AP.RoomType,
	    AP.[Address],
	    AP.City,
	    AP.StateId,
	    S.[Description] [StateDesc],
	    C.[Description] [CountryDesc],
	    AP.CountryId,
	    AP.ZipCode,
	    AP.[Description],
		AP.[ImagePath],
		AP.[ImgType],
	    AP.CreatedDate,
        (SELECT (SELECT DATENAME(DW,AP.CreatedDate))+', '+ DATENAME(MONTH, GETDATE())+ RIGHT(CONVERT(VARCHAR(200), AP.CreatedDate, 107), 9)) AS [DateLongString],
        (SELECT COUNT(*) FROM [EuroDB].[tbl_Comments] WHERE PageId = 1 AND PageColumnId = AP.AccommodationPostId) TotalComments,
		(SELECT COUNT(*) FROM [tbl_AccommodationPosts] WHERE UserId = @UID) TotalRecords
    FROM [EuroDB].[tbl_AccommodationPosts] AP
    INNER JOIN [EuroDB].[Ref_States] S ON AP.StateId = S.StateId
    INNER JOIN [EuroDB].[Ref_Countries] C ON AP.CountryId = C.CountryId  
    INNER JOIN [EuroDB].[tbl_Users] U ON AP.UserId = U.UserId  
    ORDER BY AP.CreatedDate DESC
	OFFSET @Val ROWS
	FETCH NEXT @PSize ROWS ONLY;

END
-- EXEC [USP_Get_GridAccPosts] 3,5,2

----- END -----

GO
CREATE PROCEDURE [dbo].[USP_Get_AccPostById]
(
	@IDVal		INT
)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		AP.AccommodationPostId, 
	    AP.UserId,
        U.FirstName,
	    U.LastName,
	    AP.Title,
	    AP.RoomType,
	    AP.[Address],
	    AP.City,
	    AP.StateId,
	    S.[Description] [StateDesc],
	    C.[Description] [CountryDesc],
	    AP.CountryId,
	    AP.ZipCode,
	    AP.[Description],
		AP.[ImagePath],
		AP.[ImgType],
	    AP.CreatedDate,
        (SELECT (SELECT DATENAME(DW,AP.CreatedDate))+', '+ DATENAME(MONTH, GETDATE())+ RIGHT(CONVERT(VARCHAR(200), AP.CreatedDate, 107), 9)) AS [DateLongString],
        (SELECT COUNT(*) FROM [EuroDB].[tbl_Comments] WHERE PageId = 1 AND PageColumnId = AP.AccommodationPostId) TotalComments,
		(SELECT COUNT(*) FROM [EuroDB].[tbl_AccommodationPosts] WHERE UserId = @IDVal) TotalRecords
    FROM [EuroDB].[tbl_AccommodationPosts] AP
    INNER JOIN [EuroDB].[Ref_States] S ON AP.StateId = S.StateId
    INNER JOIN [EuroDB].[Ref_Countries] C ON AP.CountryId = C.CountryId  
    INNER JOIN [EuroDB].[tbl_Users] U ON AP.UserId = U.UserId  
	WHERE AP.AccommodationPostId=@IDVal
END
-- EXEC [USP_Get_AccPostById] 1

----- END -----

