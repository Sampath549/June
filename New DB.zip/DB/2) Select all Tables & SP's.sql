USE [EuroBharat]

SELECT * FROM [tbl_Users]
SELECT * FROM [tbl_Audits]
SELECT * FROM [tbl_UserSecurityQuestions]
SELECT * FROM [tbl_UserMapping]
SELECT * FROM [tbl_ResetPwdLog]
SELECT * FROM [tbl_Menus]
SELECT * FROM [tbl_SubMenus]
SELECT * FROM [tbl_AssignMenus]
SELECT * FROM [tbl_AccommodationPosts]
SELECT * FROM [tbl_PagesForComments]
SELECT * FROM [tbl_Comments]

SELECT * FROM [Ref_Roles]
SELECT * FROM [Ref_Countries]
SELECT * FROM [Ref_States]

