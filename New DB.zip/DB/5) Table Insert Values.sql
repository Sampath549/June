USE [EuroBharat]

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('2W6ppjh+6bi2veYXNrz3LyQVLFaj+r7/9CBL2horM8MhYF/kvm5kmSZ0t//tAStkHf0IWR8cPYE8kvPO7Qmc7w==','AhU+KNMJioCmoJw2oT+65g2UG+mIbJUYX2v0/BCMP6c=','bF3touMtIMA9H+OOVGFlNctvgi6FTNaZmF6GVQU8aw8=',1,'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=','uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=','Xk4Zw+C8PndeMJkBKVSVw5/gINK/7S+nubH4M5gQmeg=','wWAOX1vUTy3SOlULE+99Bw==',1,1,1,GETDATE())
-- Actual Values : FirstName - Sampath, LastName - Bandari, Email - sampath.bandari51@gmail.com, Mobile - 8121839354, Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('AQqQ1INsGQmMDOX8+4aZ475FFmIBpU2BK/RD4qHdYtWkuzz5ZUBnq9/G5blj3OyZstL3IK8jCRkKxAEYo4fhlQ==','ELFhhNKjihz5utTrLqUVFnsHGzZaHoS2bBGQy1MCHFc=','tjeTUqYYpuQYBS4pi8Wcsev7kZ+Yl8oDlsy9/8W7M6o=',4,'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=','uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=','YooH3Y2Ncyj7gcd7BrWVd3iUA+3eMACooOuB/wLp3hY=','7p9ZrVaITz3LnhTZcDi2Ag==',1,1,1,GETDATE())
-- Actual Values : FirstName - User, LastName - Account, Email - ebtesting00001@gmail.com, Mobile - 1234567890, Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('yew8atBL/XW9qs6j4OdI4pDVEkCFN2q4KioHJ45ETHvx8w/TQ4YOcQVaF7UgOZ0WxM5Hl7zCFSwk9klXcGfRRA==','5NvhW91m6j3xpG7QdPnBxlVG5J79w7klbtuh/inHv+c=','I6Jl6hM9Rpb0qsWbmoAFQQ+b5leoZiNdvvFx8VGTMlU=',5,'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=','uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=','wRs/IyAAWgrznAhQ0AIgDSvJiLc+IelDUBMzeKdW+Yk=','IkxfPELO9OT1u+TQM71F9g==',1,1,1,GETDATE())
-- Actual Values : FirstName - Business, LastName - Account, Email - ebtesting00002@gmail.com, Mobile - 1234554321, Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('JY0/YMQjqk1ZbKJClbISqrJyfVECmtaRxhQlNLuLh+sEx6keZZf98GTncImpnKrStgrQ3E6KRxXJFDx1v2gxNw==','AUJvqIHjABBLt2jV44doyg17rRJqHRfr2u7jy8XO3mc=','mMMZ/gD1hDTipVhv+IHlM2VYuUof98FBO00LuEfZrG4=',6,'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=','uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=','DNxhNXAzaB5yWkbHcWfu3JaU9k8n6OEHcULtXYhsa48=','wsLSWf+rEMYxydNj5y52pg==',1,1,1,GETDATE()
)
-- Actual Values : FirstName - Community, LastName - Account, Email - ebTesting00003@gmail.com, Mobile - 1231231230, Password - Euro@123

----- END -----

INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Dashboard', 'CPanelDev', 'Dashboard', 0, 1, 'fa fa-bookmark-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('All Users', NULL, NULL, 1, 2, 'fa fa-user-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Master Data', NULL, NULL, 1, 3, 'fa fa-star-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Error Log', 'CPanelDev', 'ViewErrorLog', 0, 4, 'fa fa-exclamation-triangle')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Dashboard', 'CPanelUser', 'Dashboard', 0, 1, 'fa fa-bookmark-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Accommodation', NULL, NULL, 1, 2, 'fa fa-user-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Buy / Sell',  NULL, NULL, 1, 3, 'fa fa-star-o')

----- END -----

INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Create', 'CPanelDev', 'CreateAllUsers', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Details', 'CPanelDev', 'AllUserDetails', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Roles', 'CPanelDev', 'CreateRole', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Menus', 'CPanelDev', 'CreateMenus', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Sub Menus', 'CPanelDev', 'CreateSubMenus', 3)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Assigned Menus', 'CPanelDev', 'CreateAssignedMenus', 4)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Countries', 'CPanelDev', 'CreateCountries', 5)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'States', 'CPanelDev', 'CreateStates', 6)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (6, 'Posts', 'CPanelUser', 'AccommodationPosts', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (6, 'Requests', 'CPanelUser', 'AccommodationRequests', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (7, 'Posts', 'CPanelUser', 'BuySellPosts', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (7, 'Requests', 'CPanelUser', 'BuySellRequests', 2)

----- END -----

INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (1, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (2, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (3, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (4, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (5, 4)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (6, 4)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (7, 4)

----- END -----

INSERT INTO [tbl_PagesForComments] ([Code], [Description]) VALUES ('ACPOS', 'AccPosts')

----- END -----
