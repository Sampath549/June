﻿using APIService.Helper;
using APIService.Models.DataObjects;
using APIService.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIService.Controllers
{
    [Authorize(Roles = "USR"), RoutePrefix("api/CPanelUser")]
    public class CPanelUserController : ApiController
    {
        #region Global Variables
        CPanelUserDAL _ObjCPanelUser = new CPanelUserDAL();
        #endregion

        #region Accommodation Posts
        [HttpPost, Route("GridAccPosts")]
        public Result<List<SE_Accommodation>> GridAccPosts(ArrayList Array)
        {
            List<int> _lstPage = new List<int>();
            List<SE_Accommodation> _Result = new List<SE_Accommodation>();
            try
            {
                foreach (JArray val in Array)
                    _lstPage = val.ToObject<List<int>>();

                _Result = _ObjCPanelUser.GridAccPosts(_lstPage[0], _lstPage[1], _lstPage[2]);
                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("SinglePosts")]
        public Result<ViewPost_Comments> SinglePosts(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            ViewPost_Comments _Result = new ViewPost_Comments();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                _Result = _ObjCPanelUser.SinglePosts(Convert.ToInt32(_lst[0]));
                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertAccPosts")]
        public Result InsertAccPosts(ArrayList Array)
        {
            SE_Accommodation _AccPosts = new SE_Accommodation();
            try
            {
                foreach (JObject val in Array)
                    _AccPosts = val.ToObject<SE_Accommodation>();

                int _Result = _ObjCPanelUser.InsertAccPosts(_AccPosts);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Inserted Succesfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }


        [HttpPost, Route("DeleteAccPosts")]
        public Result DeleteAccPosts(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                int _Result = _ObjCPanelUser.DeleteAccPosts(Convert.ToInt32(_lst[0]), Convert.ToInt32(_lst[1]));

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertComments")]
        public Result InsertComments(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                int _Result = _ObjCPanelUser.InsertComments(_lst[0], Convert.ToInt32(_lst[1]), _lst[2], Convert.ToInt32(_lst[3]));

                if (_Result == 1)
                    return Result.Success(200, "Success", "Comment Posted Succesfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertReplyComments")]
        public Result InsertReplyComments(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                int _Result = _ObjCPanelUser.InsertReplyComments(_lst[0], Convert.ToInt32(_lst[1]), _lst[2], Convert.ToInt32(_lst[3]), Convert.ToInt32(_lst[4]));

                if (_Result == 1)
                    return Result.Success(200, "Success", "Comment Posted Succesfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        #endregion
    }
}
