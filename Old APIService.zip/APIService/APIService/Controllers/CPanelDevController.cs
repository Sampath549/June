﻿using APIService.Helper;
using APIService.Models.DataObjects;
using APIService.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIService.Controllers
{
    [Authorize(Roles = "DEV"), RoutePrefix("api/CPanelDev")]
    public class CPanelDevController : ApiController
    {
        #region Global Variables
        CPanelDevDAL _ObjCPanelDev = new CPanelDevDAL();
        SharedDAL _ObjShared = new SharedDAL();
        #endregion

        #region Roles
        [HttpPost, Route("GetRolesGrid")]
        public Result<List<SE_RefValues>> GetRolesGrid(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanelDev.GetRolesGrid();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("SaveUpdateRole")]
        public Result SaveUpdateRole(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string Code, Desc, btnType = string.Empty;
                Code = RSAPattern.Decrypt(_lst[0]);
                Desc = RSAPattern.Decrypt(_lst[1]);
                btnType = RSAPattern.Decrypt(_lst[2]);

                int _Result = _ObjCPanelDev.SaveUpdateRole(Code, Desc, btnType);

                if (_Result == 1 && btnType == "Save")
                    return Result.Success(200, "Success", "Record Saved Succesfully");
                if (_Result == 1 && btnType == "Update")
                    return Result.Success(200, "Success", "Record Update Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Duplicate Code");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("DeleteRole")]
        public Result DeleteRole(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string Code = string.Empty;
                Code = RSAPattern.Decrypt(_lst[0]);

                int _Result = _ObjCPanelDev.DeleteRole(Code);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Code Does Not Exist");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
        #endregion

        #region Menus
        [HttpPost, Route("GetMenusGrid")]
        public Result<List<SE_Menus>> GetMenusGrid(ArrayList Array)
        {
            List<SE_Menus> _lst = new List<SE_Menus>();
            try
            {
                _lst = _ObjCPanelDev.GetMenusGrid();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertUpdateMenus")]
        public Result InsertUpdateMenus(ArrayList Array)
        {
            SE_Menus _Menus = new SE_Menus();
            try
            {
                foreach (JObject val in Array)
                    _Menus = val.ToObject<SE_Menus>();

                string Type = string.Empty;
                if (_Menus.ParentId == null || _Menus.ParentId.ToString() == "")
                    Type = "Insert";
                else
                    Type = "Update";

                int _Result = _ObjCPanelDev.InsertUpdateMenus(_Menus, Type);

                if (_Result == 1)
                {
                    if (_Menus.ParentId == null || _Menus.ParentId.ToString() == "")
                        return Result.Success(200, "Success", "Record Inserted Succesfully");
                    else
                        return Result.Success(200, "Success", "Record Updated Succesfully");
                }
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("EditMenus")]
        public Result<SE_Menus> EditMenus(ArrayList Array)
        {
            List<int> _lst = new List<int>();
            SE_Menus _Result = new SE_Menus();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<int>>();
                _Result = _ObjCPanelDev.EditMenus(_lst[0]);
                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("DeleteMenus")]
        public Result DeleteMenus(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string ParentId = string.Empty;
                ParentId = RSAPattern.Decrypt(_lst[0]);

                int _Result = _ObjCPanelDev.DeleteMenus(Convert.ToInt32(ParentId));

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
        #endregion

        #region Sub Menus
        [HttpPost, Route("GetSubMenusGrid")]
        public Result<List<SE_SubMenus>> GetSubMenusGrid(ArrayList Array)
        {
            List<SE_SubMenus> _lst = new List<SE_SubMenus>();
            try
            {
                _lst = _ObjCPanelDev.GetSubMenusGrid();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertUpdateSubMenus")]
        public Result InsertUpdateSubMenus(ArrayList Array)
        {
            SE_SubMenus _SubMenus = new SE_SubMenus();
            try
            {
                foreach (JObject val in Array)
                    _SubMenus = val.ToObject<SE_SubMenus>();

                string Type = string.Empty;
                if (_SubMenus.ChildId == null || _SubMenus.ChildId.ToString() == "")
                    Type = "Insert";
                else
                    Type = "Update";

                int _Result = _ObjCPanelDev.InsertUpdateSubMenus(_SubMenus, Type);

                if (_Result == 1)
                {
                    if (_SubMenus.ChildId == null || _SubMenus.ChildId.ToString() == "")
                        return Result.Success(200, "Success", "Record Inserted Succesfully");
                    else
                        return Result.Success(200, "Success", "Record Updated Succesfully");
                }
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("EditSubMenus")]
        public Result<SE_SubMenus> EditSubMenus(ArrayList Array)
        {
            List<int> _lst = new List<int>();
            SE_SubMenus _Result = new SE_SubMenus();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<int>>();
                _Result = _ObjCPanelDev.EditSubMenus(_lst[0]);
                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("DeleteSubMenus")]
        public Result DeleteSubMenus(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string ParentId = string.Empty;
                ParentId = RSAPattern.Decrypt(_lst[0]);

                int _Result = _ObjCPanelDev.DeleteSubMenus(Convert.ToInt32(ParentId));

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
        #endregion

        #region Assigned Menus
        [HttpPost, Route("GetAssignedMenusGrid")]
        public Result<List<SE_AssignedMenus>> GetAssignedMenusGrid(ArrayList Array)
        {
            List<SE_AssignedMenus> _lst = new List<SE_AssignedMenus>();
            try
            {
                _lst = _ObjCPanelDev.GetAssignedMenusGrid();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertUpdateAssignedMenus")]
        public Result InsertUpdateAssignedMenus(ArrayList Array)
        {
            SE_AssignedMenus _AMenus = new SE_AssignedMenus();
            try
            {
                foreach (JObject val in Array)
                    _AMenus = val.ToObject<SE_AssignedMenus>();

                string Type = string.Empty;
                if (_AMenus.AssignedMenuId == null || _AMenus.AssignedMenuId.ToString() == "")
                    Type = "Insert";
                else
                    Type = "Update";

                int _Result = _ObjCPanelDev.InsertUpdateAssignedMenus(_AMenus, Type);

                if (_Result == 1)
                {
                    if (_AMenus.AssignedMenuId == null || _AMenus.AssignedMenuId.ToString() == "")
                        return Result.Success(200, "Success", "Record Inserted Succesfully");
                    else
                        return Result.Success(200, "Success", "Record Updated Succesfully");
                }
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("EditAssignedMenus")]
        public Result<SE_AssignedMenus> EditAssignedMenus(ArrayList Array)
        {
            List<int> _lst = new List<int>();
            SE_AssignedMenus _Result = new SE_AssignedMenus();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<int>>();
                _Result = _ObjCPanelDev.EditAssignedMenus(_lst[0]);
                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("DeleteAssignedMenus")]
        public Result DeleteAssignedMenus(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string ParentId = string.Empty;
                ParentId = RSAPattern.Decrypt(_lst[0]);

                int _Result = _ObjCPanelDev.DeleteAssignedMenus(Convert.ToInt32(ParentId));

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
        #endregion

        #region Countries
        [HttpPost, Route("GetCountriesGrid")]
        public Result<List<SE_RefValues>> GetCountriesGrid(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanelDev.GetCountriesGrid();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertUpdateCountries")]
        public Result InsertUpdateCountries(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string Id, Code, Desc, Type = string.Empty;
                Id = RSAPattern.Decrypt(_lst[0]);
                Code = RSAPattern.Decrypt(_lst[1]);
                Desc = RSAPattern.Decrypt(_lst[2]);

                if (Convert.ToInt32(Id) == 0)
                    Type = "Insert";
                else
                    Type = "Update";

                int _Result = _ObjCPanelDev.InsertUpdateCountries(Id, Code, Desc, Type);

                if (_Result == 1)
                {
                    if (Convert.ToInt32(Id) == 0)
                        return Result.Success(200, "Success", "Record Inserted Succesfully");
                    else
                        return Result.Success(200, "Success", "Record Updated Succesfully");
                }
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("EditCountries")]
        public Result<SE_RefValues> EditCountries(ArrayList Array)
        {
            List<int> _lst = new List<int>();
            SE_RefValues _Result = new SE_RefValues();
            try
            {
                foreach (JArray val in Array)

                    _lst = val.ToObject<List<int>>();
                _Result = _ObjCPanelDev.EditCountries(_lst[0]);
                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("DeleteCountries")]
        public Result DeleteCountries(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string Id = string.Empty;
                Id = RSAPattern.Decrypt(_lst[0]);

                int _Result = _ObjCPanelDev.DeleteCountries(Convert.ToInt32(Id));

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
        #endregion

        #region States
        [HttpPost, Route("GetStatesGrid")]
        public Result<List<SE_States>> GetStatesGrid(ArrayList Array)
        {
            List<SE_States> _lst = new List<SE_States>();
            try
            {
                _lst = _ObjCPanelDev.GetStatesGrid();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertUpdateStates")]
        public Result InsertUpdateStates(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string Id, CountryId, Code, Desc, Type = string.Empty;
                Id = RSAPattern.Decrypt(_lst[0]);
                CountryId = RSAPattern.Decrypt(_lst[1]);
                Code = RSAPattern.Decrypt(_lst[2]);
                Desc = RSAPattern.Decrypt(_lst[3]);

                if (Convert.ToInt32(Id) == 0)
                    Type = "Insert";
                else
                    Type = "Update";

                int _Result = _ObjCPanelDev.InsertUpdateStates(Id, CountryId, Code, Desc, Type);

                if (_Result == 1)
                {
                    if (Convert.ToInt32(Id) == 0)
                        return Result.Success(200, "Success", "Record Inserted Succesfully");
                    else
                        return Result.Success(200, "Success", "Record Updated Succesfully");
                }
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("EditStates")]
        public Result<SE_States> EditStates(ArrayList Array)
        {
            List<int> _lst = new List<int>();
            SE_States _Result = new SE_States();
            try
            {
                foreach (JArray val in Array)

                    _lst = val.ToObject<List<int>>();
                _Result = _ObjCPanelDev.EditStates(_lst[0]);
                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("DeleteStates")]
        public Result DeleteStates(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string Id = string.Empty;
                Id = RSAPattern.Decrypt(_lst[0]);

                int _Result = _ObjCPanelDev.DeleteStates(Convert.ToInt32(Id));

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
        #endregion
    }
}
