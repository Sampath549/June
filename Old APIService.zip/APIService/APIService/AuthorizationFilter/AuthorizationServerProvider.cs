﻿using APIService.Models;
using APIService.Models.DataObjects;
using APIService.Models.SharedEntities;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OAuth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;

namespace APIService.AuthorizationFilter
{
    public class AuthorizationServerProvider : OAuthAuthorizationServerProvider
    {
        private LoginDAL objLogin;
        public AuthorizationServerProvider()
        {
            objLogin = new LoginDAL();
        }
        public override Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            var objOauthValues = new OAuth();
            context.Validated();

            string _ClientId;
            string _ClientSecret;
            context.TryGetFormCredentials(out _ClientId, out _ClientSecret);

            if (_ClientId == objOauthValues.OauthClient && _ClientSecret == objOauthValues.OauthClientSecret)
            {
                context.Validated(_ClientId);
            }
            else
            {
                context.SetError("invalid_client", "Client credentials could not be retrieved from the Authorization header");
                context.Rejected();
            }
            return base.ValidateClientAuthentication(context);
        }
        public override Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            var allowedOrigin = "*";
            context.OwinContext.Response.Headers.Add("Access-Control-Allow-Origin", new[] { allowedOrigin });

            SE_Users _User = objLogin.TokenAuthentication(context.UserName, context.Password);
            if (_User.Status == 0)
            {
                context.SetError("invalid_grant", "The user name or password is incorrect.");
                context.Rejected();
            }
            else
            {
                var oAuthIdentity = new ClaimsIdentity(context.Options.AuthenticationType);
                oAuthIdentity.AddClaim(new Claim(ClaimTypes.Role, _User.RoleCode));
                var ticket = new AuthenticationTicket(oAuthIdentity, new AuthenticationProperties());
                context.Validated(ticket);
            }
            return base.GrantResourceOwnerCredentials(context);
            //context.Validated(new ClaimsIdentity(context.Options.AuthenticationType));


            //return Task.Factory.StartNew(() =>
            //{
            //    var userName = context.UserName;
            //    var password = context.Password;

            //    var user = objLogin.TokenAuthentication(context.UserName, context.Password);
            //    if (user.Status != 0)
            //    {
            //        var claims = new List<Claim>()
            //            {
            //                new Claim(ClaimTypes.Sid, Convert.ToString(user.UserId)),
            //                new Claim(ClaimTypes.Name, "asdf"),
            //                new Claim(ClaimTypes.Email, "abc")
            //            };

            //        string[] Roles = new string[] { "Admin", "User" };
            //        foreach (var role in Roles)
            //            claims.Add(new Claim(ClaimTypes.Role, role));

            //        var data = new Dictionary<string, string>
            //            {
            //                { "userName", "asdf" },
            //                { "roles", string.Join(",", Roles)}
            //            };

            //        var properties = new AuthenticationProperties(data);

            //        ClaimsIdentity oAuthIdentity = new ClaimsIdentity(claims, context.Options.AuthenticationType);

            //        var ticket = new AuthenticationTicket(oAuthIdentity, properties);
            //        context.Validated(ticket);
            //    }
            //    else
            //    {
            //        context.SetError("invalid_grant", "The user name or password is incorrect");
            //    }
            //});

        }
    }
}