﻿using APIService.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace APIService.Models.DataObjects
{
    public partial class CPanelDAL : DataAccessComponent
    {
        public int OneTimePassword(int UserId, string OldPwd, string OldKey, string NewPwd, string NewKey)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Update_OneTimeLogin";
                cmd.Parameters.Add("@UserId", SqlDbType.VarChar).Value = UserId;
                cmd.Parameters.Add("@OldPwd", SqlDbType.VarChar).Value = OldPwd;
                cmd.Parameters.Add("@OldKey", SqlDbType.VarChar).Value = OldKey;
                cmd.Parameters.Add("@NewPwd", SqlDbType.VarChar).Value = NewPwd;
                cmd.Parameters.Add("@NewKey", SqlDbType.VarChar).Value = NewKey;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch
            {
                return Status;
            }
            finally
            {
                con.Close();
            }
        }
        public string GetMenus(string RoleCode)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_MenuListByRole", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@RoleCode", RoleCode);

                        da.Fill(_Result);
                    }
                }
                return JsonMenusList(_Result);
            }
            catch (WebException ex)
            { throw ex; }
        }
        public string JsonMenusList(DataSet _Result)
        {
            try
            {
                var _Menus = new StringBuilder();
                if (_Result.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < _Result.Tables[0].Rows.Count; i++)
                    {
                        if (!Convert.ToBoolean(_Result.Tables[0].Rows[i]["HavingChild"]))
                            _Menus.Append("<li id='menu" + i + "'><a href='/" + _Result.Tables[0].Rows[i]["Controller"].ToString() + "/" + _Result.Tables[0].Rows[i]["Action"].ToString() + "'><i class='" + _Result.Tables[0].Rows[i]["Icon"].ToString() + "'></i> " + _Result.Tables[0].Rows[i]["Header"].ToString() + "</a></li>");
                        else
                        {
                            _Menus.Append("<li id='menu" + i + "'>");
                            _Menus.Append("<a id='submenu" + i + "' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'><i class='" + _Result.Tables[0].Rows[i]["Icon"].ToString() + "'></i> " + _Result.Tables[0].Rows[i]["Header"].ToString() + "</a>");
                            _Menus.Append("<ul class='dropdown-menu' aria-labelledby='submenu" + i + "'>");
                            for (int j = 0; j < _Result.Tables[1].Rows.Count; j++)
                            {
                                if (Convert.ToInt32(_Result.Tables[0].Rows[i]["ParentId"]) == Convert.ToInt32(_Result.Tables[1].Rows[j]["ParentId"]))
                                    _Menus.Append("<li><a href='/" + _Result.Tables[1].Rows[j]["Controller"].ToString() + "/" + _Result.Tables[1].Rows[j]["Action"].ToString() + "'>" + _Result.Tables[1].Rows[j]["Header"].ToString() + "</a></li>");
                            }
                            _Menus.Append("</ul>");
                            _Menus.Append("</li>");
                        }
                    }
                }
                return _Menus.ToString();
            }
            catch (WebException ex)
            { throw ex; }
        }
        public int InsertUpdateMyProfile(SE_MyProfile _Records)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_InsertUpdate_MyProfile";

                cmd.Parameters.Add("@ActualEmail", SqlDbType.VarChar).Value = _Records.EmailCheck;
                cmd.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = _Records.FirstName;
                cmd.Parameters.Add("@LastName", SqlDbType.VarChar).Value = _Records.LastName;
                cmd.Parameters.Add("@Gender", SqlDbType.Char).Value = _Records.Gender;
                cmd.Parameters.Add("@PAddress", SqlDbType.VarChar).Value = _Records.PAddress;
                cmd.Parameters.Add("@PCity", SqlDbType.VarChar).Value = _Records.PCity;
                cmd.Parameters.Add("@PStateId", SqlDbType.Int).Value = _Records.PStateId;
                cmd.Parameters.Add("@PCountryId", SqlDbType.Int).Value = _Records.PCountryId;
                cmd.Parameters.Add("@PZipCode", SqlDbType.BigInt).Value = _Records.PZipCode;
                cmd.Parameters.Add("@isCurrentPermanent", SqlDbType.Bit).Value = _Records.isCurrentPermanent;
                cmd.Parameters.Add("@CAddress", SqlDbType.VarChar).Value = _Records.CAddress;
                cmd.Parameters.Add("@CCity", SqlDbType.VarChar).Value = _Records.CCity;
                cmd.Parameters.Add("@CStateId", SqlDbType.Int).Value = _Records.CStateId;
                cmd.Parameters.Add("@CCountryId", SqlDbType.Int).Value = _Records.CCountryId;
                cmd.Parameters.Add("@CZipCode", SqlDbType.BigInt).Value = _Records.CZipCode;
                cmd.Parameters.Add("@ProfilePic", SqlDbType.VarChar).Value = _Records.ProfilePic;
                cmd.Parameters.Add("@ImgType", SqlDbType.VarChar).Value = _Records.ImgType;

                SqlParameter outputIdParam = new SqlParameter("@OutputResult", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public SE_MyProfile UserMappingDetails(string EmailCheck)
        {
            SE_MyProfile _Result = new SE_MyProfile();
            DataTable dtUserDetails = new DataTable();
            using (SqlConnection con = new SqlConnection(DB_ADOConnect))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand("USP_Get_UserMappingDetails", con);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.AddWithValue("@EmailCheck", EmailCheck);

                    da.Fill(dtUserDetails);

                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["UserId"].ToString()))
                        _Result.UserId = Convert.ToInt32(dtUserDetails.Rows[0]["UserId"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["Gender"].ToString()))
                        _Result.Gender = Convert.ToString(dtUserDetails.Rows[0]["Gender"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["Photo"].ToString()))
                        _Result.ProfilePic = Convert.ToString(dtUserDetails.Rows[0]["Photo"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["ImgType"].ToString()))
                        _Result.ImgType = Convert.ToString(dtUserDetails.Rows[0]["ImgType"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["IsPermanentAddress"].ToString()))
                        _Result.isCurrentPermanent = Convert.ToBoolean(dtUserDetails.Rows[0]["IsPermanentAddress"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["PAddress"].ToString()))
                        _Result.PAddress = Convert.ToString(dtUserDetails.Rows[0]["PAddress"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["PCity"].ToString()))
                        _Result.PCity = Convert.ToString(dtUserDetails.Rows[0]["PCity"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["PStateId"].ToString()))
                        _Result.PStateId = Convert.ToString(dtUserDetails.Rows[0]["PStateId"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["PCountryId"].ToString()))
                        _Result.PCountryId = Convert.ToString(dtUserDetails.Rows[0]["PCountryId"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["PZipCode"].ToString()))
                        _Result.PZipCode = Convert.ToString(dtUserDetails.Rows[0]["PZipCode"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["CAddress"].ToString()))
                        _Result.CAddress = Convert.ToString(dtUserDetails.Rows[0]["CAddress"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["CCity"].ToString()))
                        _Result.CCity = Convert.ToString(dtUserDetails.Rows[0]["CCity"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["CStateId"].ToString()))
                        _Result.CStateId = Convert.ToString(dtUserDetails.Rows[0]["CStateId"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["CCountryId"].ToString()))
                        _Result.CCountryId = Convert.ToString(dtUserDetails.Rows[0]["CCountryId"]);
                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["CZipCode"].ToString()))
                        _Result.CZipCode = Convert.ToString(dtUserDetails.Rows[0]["CZipCode"]);
                }
            }
            return _Result;
        }
    }
}