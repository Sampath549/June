﻿using APIService.Helper;
using APIService.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;

namespace APIService.Models.DataObjects
{
    public partial class LoginDAL : DataAccessComponent
    {
        SharedDAL _ObjShared = new SharedDAL();
        public SE_Users TokenAuthentication(string Email, string Password)
        {
            SE_Users _Result = new SE_Users();
            DataSet ds = new DataSet();
            string _Check = _ObjShared.GetSaltKeyByEmail(StringEncrypt.Encrypt(Email));
            if (_Check != null)
            {
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT R.Code AS RoleCode FROM [tbl_Users] U INNER JOIN [Ref_Roles] R ON U.RoleId = R.RoleId WHERE EmailCheck= @EmailCheck AND Password = @Password", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@EmailCheck", StringEncrypt.Encrypt(Email));
                        da.SelectCommand.Parameters.AddWithValue("@Password", PwdEncryption.EncodePassword(Password, AES_Algorithm.DecryptString(_Check)));

                        da.Fill(ds);
                    }
                }

                if (ds.Tables[0].Rows.Count > 0)
                {
                    _Result.Status = 1;
                    _Result.RoleCode = ds.Tables[0].Rows[0]["RoleCode"].ToString();
                }
                else
                    _Result.Status = 0;
            }
            else
                _Result.Status = 0;

            return _Result;
        }
        public int InsertRegistration(SE_Users _Data)
        {
            bool EmailMobileExists = CheckEmailMobile(_Data.EmailCheck, _Data.MobileCheck);
            if (!EmailMobileExists)
            {
                SqlConnection con = new SqlConnection(DB_ADOConnect);
                con.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "USP_Insert_Registration";
                    cmd.Parameters.Add("@PersonalKey", SqlDbType.VarChar).Value = _Data.PersonalKey;
                    cmd.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = _Data.FirstName;
                    cmd.Parameters.Add("@LastName", SqlDbType.VarChar).Value = _Data.LastName;
                    cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = _Data.Email;
                    cmd.Parameters.Add("@EmailCheck", SqlDbType.VarChar).Value = _Data.EmailCheck;
                    cmd.Parameters.Add("@Mobile", SqlDbType.VarChar).Value = _Data.Mobile;
                    cmd.Parameters.Add("@MobileCheck", SqlDbType.VarChar).Value = _Data.MobileCheck;
                    cmd.Parameters.Add("@RoleCode", SqlDbType.VarChar).Value = _Data.RoleCode;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = _Data.Password;
                    cmd.Parameters.Add("@SaltKey", SqlDbType.VarChar).Value = _Data.SaltKey;

                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    return 1;
                }
                catch (WebException ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
            else
                return 101; // Email Or Mobile already Exists
        }
        public bool CheckEmailMobile(string Email, string Mobile)
        {
            DataSet _Result = new DataSet();
            using (SqlConnection con = new SqlConnection(DB_ADOConnect))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand("SELECT Count(*) [Count] FROM [tbl_Users] WHERE EmailCheck=@Email OR MobileCheck=@Mobile", con);
                    da.SelectCommand.CommandType = CommandType.Text;
                    da.SelectCommand.Parameters.AddWithValue("@Email", Email);
                    da.SelectCommand.Parameters.AddWithValue("@Mobile", Mobile);

                    da.Fill(_Result);
                }
            }

            if (Convert.ToInt32(_Result.Tables[0].Rows[0]["Count"]) == 0)
                return false;
            else
                return true;
        }
        public SE_Users AuthenticatedUser(string EmailCheck, string Password)
        {
            SE_Users _Result = new SE_Users();
            DataTable dtUserDetails = new DataTable();
            using (SqlConnection con = new SqlConnection(DB_ADOConnect))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand("USP_Get_AuthenticatedUser", con);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.AddWithValue("@EmailCheck", EmailCheck);
                    da.SelectCommand.Parameters.AddWithValue("@Password", Password);

                    da.Fill(dtUserDetails);

                    if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["UserId"].ToString()))
                    {
                        _Result.Status = Convert.ToInt32(dtUserDetails.Rows[0]["Status"]);
                        _Result.UserId = Convert.ToInt32(dtUserDetails.Rows[0]["UserId"]);
                        _Result.FirstName = Convert.ToString(dtUserDetails.Rows[0]["FirstName"]);
                        _Result.LastName = Convert.ToString(dtUserDetails.Rows[0]["LastName"]);
                        _Result.FullName = Convert.ToString(dtUserDetails.Rows[0]["FullName"]);
                        _Result.EmailCheck = Convert.ToString(dtUserDetails.Rows[0]["EmailCheck"]);
                        _Result.MobileCheck = Convert.ToString(dtUserDetails.Rows[0]["MobileCheck"]);
                        _Result.RoleId = Convert.ToInt32(dtUserDetails.Rows[0]["RoleId"]);
                        _Result.RoleCode = Convert.ToString(dtUserDetails.Rows[0]["RoleCode"]);
                        _Result.IsFirstTimeLogin = Convert.ToBoolean(dtUserDetails.Rows[0]["IsFirstTimeLogin"]);
                        if (dtUserDetails.Rows[0]["Photo"] != DBNull.Value)
                            _Result.ProfilePic = Convert.ToString(dtUserDetails.Rows[0]["Photo"]);
                        if (dtUserDetails.Rows[0]["DisableAccountTime"] != DBNull.Value)
                            _Result.DisableAccountTime = Convert.ToDateTime(dtUserDetails.Rows[0]["DisableAccountTime"]);
                        if (dtUserDetails.Rows[0]["TimeDiff"] != DBNull.Value)
                            _Result.TimeDiff = Convert.ToInt32(dtUserDetails.Rows[0]["TimeDiff"]);
                    }
                    if (dtUserDetails.Rows[0]["FailedLoginAttempts"] != DBNull.Value)
                        _Result.FailedLoginAttempts = Convert.ToInt32(dtUserDetails.Rows[0]["FailedLoginAttempts"]);
                }
            }
            return _Result;
        }
        public int GetUserIdByEmail(string _Email)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT UserId FROM [tbl_Users] WHERE EmailCheck = @Email", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Email", _Email);
                        da.Fill(_Result);
                    }
                }
                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToInt32(_Result.Tables[0].Rows[0]["UserId"]);
                else
                    return 0;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public string GetFullNameByEmail(string _Email)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT FirstName, LastName FROM [tbl_Users] WHERE EmailCheck = @Email", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Email", _Email);
                        da.Fill(_Result);
                    }
                }
                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToString(_Result.Tables[0].Rows[0]["FirstName"]) + "^" + Convert.ToString(_Result.Tables[0].Rows[0]["LastName"]);
                else
                    return null;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public int InsertResetPwdLog(string GuidValue, string _Email)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            try
            {
                int UserId = GetUserIdByEmail(_Email);
                if (UserId > 0)
                {
                    DateTime CurrentDate = DateTime.Now;
                    DataSet ds = new DataSet();
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT MAX(EntryDate) AS MaxTime FROM [tbl_ResetPwdLog] WHERE UserId = @UserId", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@UserId", UserId);
                        da.Fill(ds);
                    }

                    if (ds.Tables[0].Rows[0]["MaxTime"] != DBNull.Value)
                    {
                        int TotalTime = Convert.ToInt32(CurrentDate.Subtract(Convert.ToDateTime(ds.Tables[0].Rows[0]["MaxTime"])).TotalMinutes);
                        int ExpiryTime = GlobalVariables.Shared._ForgotPwdClickAgain;
                        if (TotalTime < ExpiryTime)
                            return 201;
                    }

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "USP_Insert_ResetPwdLog";
                    cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
                    cmd.Parameters.Add("@GuidVal", SqlDbType.VarChar).Value = GuidValue;

                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    return 1;
                }
                else
                    return 0;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public string GetExpiryDate_IsReset(string GuidValue)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT EntryDate, IsReset FROM [tbl_ResetPwdLog] WHERE GuidVal = @GuidValue", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@GuidValue", GuidValue);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToString(_Result.Tables[0].Rows[0]["EntryDate"]) + "^" + Convert.ToString(_Result.Tables[0].Rows[0]["IsReset"]);
                else
                    return null;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public int ResetPassword(string EmailCheck, string Password, string SaltKey, string GuidVal)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                int UserId = GetUserIdByEmail(EmailCheck);
                if (UserId > 0)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "USP_Update_ResetPwd";
                    cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = Password;
                    cmd.Parameters.Add("@SaltKey", SqlDbType.VarChar).Value = SaltKey;
                    cmd.Parameters.Add("@GuidVal", SqlDbType.VarChar).Value = GuidVal;
                    cmd.Parameters.Add("@ExpiryTime", SqlDbType.Int).Value = GlobalVariables.Shared._EmailLinkExpiry;

                    SqlParameter OutputParam = new SqlParameter("@OutputResult", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };
                    cmd.Parameters.Add(OutputParam);
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();

                    Status = int.Parse(OutputParam.Value.ToString());
                    return Status;
                }
                else
                    return 0;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public bool InsertAuditLogin(int UserId, string IPAddr, string EntryType, string EntryFrom, string Browser, string Resolution, string Location, string Latitude, string Longitude, bool IsSuccess)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            try
            {
                if (UserId > 0)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "USP_Insert_Audit";
                    cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
                    cmd.Parameters.Add("@IPAddr", SqlDbType.VarChar).Value = IPAddr;
                    cmd.Parameters.Add("@EntryType", SqlDbType.VarChar).Value = EntryType;
                    cmd.Parameters.Add("@EntryFrom", SqlDbType.VarChar).Value = EntryFrom;
                    cmd.Parameters.Add("@Browser", SqlDbType.VarChar).Value = Browser;
                    cmd.Parameters.Add("@Resolution", SqlDbType.VarChar).Value = Resolution;
                    cmd.Parameters.Add("@Location", SqlDbType.VarChar).Value = Location;
                    cmd.Parameters.Add("@Latitude", SqlDbType.VarChar).Value = Latitude;
                    cmd.Parameters.Add("@Longitude", SqlDbType.VarChar).Value = Longitude;
                    cmd.Parameters.Add("@IsSuccess", SqlDbType.Bit).Value = IsSuccess;

                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    return true;
                }
                else
                    return false;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public void UpdateAttemptsFailed(int UserId)
        {
            DataSet _Result = new DataSet();
            using (SqlConnection con = new SqlConnection(DB_ADOConnect))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand("USP_Update_FailedLoginAttempts", con);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.AddWithValue("@UserId", UserId);
                    da.Fill(_Result);
                }
            }
        }
    }
}