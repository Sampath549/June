﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace APIService.Models
{
    public sealed class GlobalVariables
    {
        private static readonly GlobalVariables shared = new GlobalVariables();
        public readonly string OauthClientId;
        public readonly string OauthClientSecret;
        public readonly string OauthAccessTokenExpireSeconds;
        public string PrivateKey;
        public string PublicKey;
        public readonly string DevRole;
        public readonly string SuperAdminRole;
        public readonly string AdminRole;
        public readonly string UserRole;
        public readonly string BusinessRole;
        public readonly string CommunityRole;
        public string _AESKey;
        public string InsertErrorLog;
        public string _Host;
        public int _Port;
        public string _SenderEmail;
        public string _EmailUser;
        public string _EmailPwd;
        public bool _SendActualMails;
        public string _SendDefaultEmailTo;
        public string ClientUrl;
        public string _ResetPwdURL;
        public int _EmailLinkExpiry;
        public int _ForgotPwdClickAgain;

        static GlobalVariables()
        {
        }
        private GlobalVariables()
        {
            OauthClientId = WebConfigurationManager.AppSettings["OauthClientId"];
            OauthClientSecret = WebConfigurationManager.AppSettings["OauthClientSecret"];
            OauthAccessTokenExpireSeconds = WebConfigurationManager.AppSettings["OauthAccessTokenExpireSeconds"];
            PrivateKey = "<RSAKeyValue><Modulus>3SqgT67YOa+InXXxYLQgdcFxAtV3G6oHp9hUfyLciRtPHb0NcFsQ5ZjIB2VYFXc2NUIlysRo2hbmbWJMgU3gV/vL/ItQIb88owYFZx7Cd4qdQGTAw6xMh8RSl+mSHwMtMiJ8F3cZSEs9feXFLad0Yi7DonVl0NXoJU+I3eptEU0=</Modulus><Exponent>AQAB</Exponent><P>34LLnR5XdARSo0gf4JIhWBefsMnWLTwhgJZe+DfCrzqlAAm6ScDmx0bPL5RkH9+l28ngX0G1z5Cwwkoms6kyJw==</P><Q>/VCXbYcdvvJAjySZ9M6iFS4DasXy01X7AarySCBA+qw0vP0cQPqVhkbRlL+nufsvYkSgT4eZSphLKBE27eHtaw==</Q><DP>cPDKqo4Was10ZIWhdfzhVH47dz3GN/1WgH97Zbnnalwb3DUOKQ6Mjs29C7HUFjcQvEr6UagGkufuKX8Gp2orqQ==</DP><DQ>77x+E6J0fGo4v0AclJuaugC6Kyr8DRaqX4GxmqEr3hFsOBAz1StSp6oOX4Ci9FjNF2trbNkgMoC/YEQqgCf50Q==</DQ><InverseQ>vsHoBiTPU7B7TgwpbczYmFgdeaR5Qa3yYjtNdOiZlZ9bSeOuSA3SfJChAJjZaGkXhdl9Je9RunlrD9enPUrtJg==</InverseQ><D>HB8IZTlZGvSbzVGq0F325qIjCXY0/9p9wLS8AbJgEjrbs29PXyLlIhxsCqyzJ3+R7/GqNn8Eyf4xbGUcTzCkvq6Pc40tpmTrn6WK+zWia7Fza3db9/OP74VmBvMLhWCzlhfIcenb/00RaG+RH/gxdv9AOLw1ODW0F8Jap74cpI0=</D></RSAKeyValue>";
            PublicKey = WebConfigurationManager.AppSettings["PublicKey"].ToString();
            DevRole = "DEV";
            SuperAdminRole = "SA";
            AdminRole = "ADM";
            UserRole = "USR";
            BusinessRole = "BUS";
            CommunityRole = "COMM";

            _AESKey = WebConfigurationManager.AppSettings["AESKey"].ToString();
            InsertErrorLog = WebConfigurationManager.AppSettings["InsertErrorLog"].ToString();
            _Host = WebConfigurationManager.AppSettings["MailingHost"].ToString();
            _Port = Convert.ToInt32(WebConfigurationManager.AppSettings["MailingPort"]);
            _SenderEmail = WebConfigurationManager.AppSettings["SenderEmail"].ToString();
            _EmailUser = WebConfigurationManager.AppSettings["EmailUser"].ToString();
            _EmailPwd = WebConfigurationManager.AppSettings["EmailPwd"].ToString();
            _SendActualMails = Convert.ToBoolean(WebConfigurationManager.AppSettings["SendActualMails"]);
            _SendDefaultEmailTo = WebConfigurationManager.AppSettings["SendDefaultEmailTo"].ToString();
            ClientUrl = WebConfigurationManager.AppSettings["ConfigClientUrl"].ToString();
            _ResetPwdURL = WebConfigurationManager.AppSettings["ResetPwdURL"].ToString();
            _EmailLinkExpiry = Convert.ToInt32(WebConfigurationManager.AppSettings["EmailLinkExpiry"]);
            _ForgotPwdClickAgain = Convert.ToInt32(WebConfigurationManager.AppSettings["ForgotPwdClickAgain"]);
        }
        public static GlobalVariables Shared
        {
            get { return shared; }
        }
    }
}