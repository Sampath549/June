﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIService.Models
{
    public class OAuth
    {
        public string OauthClient = GlobalVariables.Shared.OauthClientId;
        public string OauthClientSecret = GlobalVariables.Shared.OauthClientSecret;
        public double OauthAccessTokenExpireSeconds = Convert.ToDouble(GlobalVariables.Shared.OauthAccessTokenExpireSeconds);
    }
}