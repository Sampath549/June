﻿using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using WebApp.App_Start;
using WebApp.Filters;
using WebApp.Helper;
using WebApp.Models.SharedEntities;

namespace WebApp.Controllers
{
    [MVCSessionFilter, MVCUserAuthorization]
    public class CPanelUserController : Controller
    {
        #region Dashboard
        public ActionResult Dashboard()
        {
            try
            {
                ViewBag.DisplayModalPopup = Reusable.CheckIsFirstTimeLogin();   // Model PopUp   
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
            return View();
        }
        #endregion

        #region Accommodation
        public ActionResult AccommodationPosts(int? PageNum)
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                List<int> _lstNum = new List<int>();
                _lstNum.Add(Convert.ToInt32(PageNum == null ? 1 : PageNum));
                _lstNum.Add(5);
                _lstNum.Add(_SessionUserDetails.UserId);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_lstNum);
                string response = ApiHelper.PostData_Json("api/CPanelUser/GridAccPosts?Values=", _Array);
                Result<List<SE_Accommodation>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Accommodation>>>(response);
                List_SE_Accommodation _lst = new List_SE_Accommodation();
                _lst.ListAccPosts = _Result.Data;

                return View(_lst);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        public ActionResult ViewAccPosts(int Id)
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus

            List<string> _Val = new List<string>();
            _Val.Add(Id.ToString());

            //API Call		
            ArrayList _Array = new ArrayList();
            _Array.Add(_Val);
            string response = ApiHelper.PostData_Json("api/CPanelUser/SinglePosts?Values=", _Array);
            Result<ViewPost_Comments> _Result = JsonConvert.DeserializeObject<Result<ViewPost_Comments>>(response);

            SE_Accommodation _Rec = new SE_Accommodation();
            _Rec.FullName = RSAPattern.Decrypt(_Result.Data.ViewPost.FirstName) + " " + RSAPattern.Decrypt(_Result.Data.ViewPost.LastName);
            _Rec.AccommodationId = _Result.Data.ViewPost.AccommodationId;
            _Rec.UserId = _Result.Data.ViewPost.UserId;
            _Rec.Title = _Result.Data.ViewPost.Title;
            _Rec.RoomType = _Result.Data.ViewPost.RoomType;
            _Rec.Address = _Result.Data.ViewPost.Address;
            _Rec.City = _Result.Data.ViewPost.City;
            _Rec.StateDesc = _Result.Data.ViewPost.StateDesc;
            _Rec.CountryDesc = _Result.Data.ViewPost.CountryDesc;
            _Rec.ZipCode = _Result.Data.ViewPost.ZipCode;
            _Rec.Description = _Result.Data.ViewPost.Description;
            _Rec.DateLongString = _Result.Data.ViewPost.DateLongString;
            _Rec.ImagePath = _Result.Data.ViewPost.ImagePath;
            _Rec.ImgType = _Result.Data.ViewPost.ImgType;

            List<SE_Comments> _Comments = new List<SE_Comments>();
            foreach (SE_Comments Val in _Result.Data.CommentsList.ToList())
            {
                SE_Comments SingleRec = new SE_Comments();
                SingleRec.CommentId = Val.CommentId;
                SingleRec.ParentCommentId = Val.ParentCommentId;
                SingleRec.Comments = Val.Comments;
                SingleRec.ReplyUserId = Val.ReplyUserId;
                SingleRec.PageId = Val.PageId;
                SingleRec.PageColumnId = Val.PageColumnId;
                SingleRec.ReplyFirstName = RSAPattern.Decrypt(Val.ReplyFirstName);
                SingleRec.ReplyLastName = RSAPattern.Decrypt(Val.ReplyLastName);
                SingleRec.ReplyPhoto = Val.ReplyPhoto.ToString();
                SingleRec.CommentedDate = Val.CommentedDate;
                SingleRec.FullStringDate = Val.CommentedDate.ToString("ddd, dd MMM yyyy") + ", " + Val.CommentedDate.ToString("hh:mm tt");
                SingleRec.HavingParentCommentId = Val.HavingParentCommentId;
                if (SingleRec.HavingParentCommentId)
                {
                    SingleRec.InnerComments = InnerResult(Val.InnerComments, SingleRec.CommentId);
                }
                else
                    SingleRec.InnerComments = new List<SE_Comments>();
                _Comments.Add(SingleRec);
            }

            ViewPost_Comments _Data = new ViewPost_Comments();
            _Data.ViewPost = _Rec;
            _Data.CommentsList = _Comments;
            _Data.TotalComments = _Result.Data.TotalComments;
            _Data.RawHTML = RawHTMLComments(_Comments);

            return View(_Data);
        }

        public string RawHTMLComments(IEnumerable<SE_Comments> _Comments)
        {

            string str = @"";
            List<SE_Comments> _Result = new List<SE_Comments>();
            foreach (SE_Comments Val in _Comments)
            {
                str += @"<li class='comment'>
                            <div class='comment-body'>
                                <div class='comment-author'>";

                if (Val.ReplyPhoto == "")
                    str += @"<span style = 'border: 1px solid #ccc; border-radius: 50%; float:left; height: 84px; margin-bottom:30px;  margin-right:25px; position:relative; width: 84px; max-width: 100%; color: #337ab7;font-size:50px; font-weight:700; line-height: 80px;text-align:center !important; vertical-align:middle;'>" + Val.ReplyFirstName.Trim().Substring(0, 1) + "</span>";
                else
                    str += @"<img class='avatar' src=" + Val.ReplyPhoto + " alt='Image'>";

                str += @"<span class='fn'>" + Val.ReplyFirstName + ' ' + Val.ReplyLastName + "</span>";
                str += @"</div>";

                str += @"<div class='comment-meta commentmetadata'><a href = '#' >" + Val.FullStringDate + " </a></div>";

                str += @"<div class='comment-content'>
                            <p>" + Val.Comments + "</p></div>";

                str += @"<div class='reply'>
                            <a href = '#' class='btn-link hrefLinkClick' onclick='MyFunc(" + Val.CommentId + ")'><i class='fa fa-reply' aria-hidden='true'></i> Reply</a>";
                str += @"<div id= '" + Val.CommentId + "' class='form-horizontal'></div>";
                str += @"</div></div>";

                if (Val.HavingParentCommentId && Val.InnerComments.Count > 0)
                {
                    str += InnerRawHTMLComments(Val.InnerComments);
                }
                str += " </li>";
            }
            return str;
        }

        public string InnerRawHTMLComments(IEnumerable<SE_Comments> _Comments)
        {
            string str = @"";
            if (_Comments.ToList().Count > 0)
            {
                str += @"<ul class='children'>";
                foreach (SE_Comments IC in _Comments)
                {
                    str += @"<li class='comment'>
                            <div class='comment-body'>
                                <div class='comment-author'>";

                    if (IC.ReplyPhoto == "")
                        str += @"<span style = 'border: 1px solid #ccc; border-radius: 50%; float:left; height: 84px; margin-bottom:30px;  margin-right:25px; position:relative; width: 84px; max-width: 100%; color: #337ab7;font-size:50px; font-weight:700; line-height: 80px;text-align:center !important; vertical-align:middle;'>" + IC.ReplyFirstName.Trim().Substring(0, 1) + "</span>";
                    else
                        str += @"<img class='avatar' src=" + IC.ReplyPhoto + " alt='Image'>";

                    str += @"<span class='fn'>" + IC.ReplyFirstName + ' ' + IC.ReplyLastName + "</span>";
                    str += @"</div>";

                    str += @"<div class='comment-meta commentmetadata'><a href = '#' >" + IC.FullStringDate + " </a></div>";

                    str += @"<div class='comment-content'>
                            <p>" + IC.Comments + "</p></div>";

                    str += @"<div class='reply'>
                            <a href = '#' class='btn-link hrefLinkClick' onclick='MyFunc(" + IC.CommentId + ")'><i class='fa fa-reply' aria-hidden='true'></i> Reply</a>";
                    str += @"<div id= '" + IC.CommentId + "' class='form-horizontal'></div>";
                    str += @"</div></div>";
                    if (IC.HavingParentCommentId && IC.InnerComments.Count > 0)
                    {
                        string InnerStr = InnerRawHTMLComments(IC.InnerComments);
                        str += InnerStr;
                    }
                    str += @"</li>";
                }
                str += " </ul>";
            }
            return str;
        }

        public List<SE_Comments> InnerResult(List<SE_Comments> _Result, int CommentId)
        {
            List<SE_Comments> _InnerResult = new List<SE_Comments>();
            foreach (SE_Comments Val in _Result)
            {
                SE_Comments SingleRec = new SE_Comments();
                if (CommentId == Val.ParentCommentId)
                {
                    SingleRec.CommentId = Val.CommentId;
                    SingleRec.ParentCommentId = Val.ParentCommentId;
                    SingleRec.Comments = Val.Comments;
                    SingleRec.ReplyUserId = Val.ReplyUserId;
                    SingleRec.PageId = Val.PageId;
                    SingleRec.PageColumnId = Val.PageColumnId;
                    SingleRec.ReplyFirstName = RSAPattern.Decrypt(Val.ReplyFirstName);
                    SingleRec.ReplyLastName = RSAPattern.Decrypt(Val.ReplyLastName);
                    SingleRec.ReplyPhoto = Val.ReplyPhoto.ToString();
                    SingleRec.CommentedDate = Val.CommentedDate;
                    SingleRec.FullStringDate = Val.CommentedDate.ToString("ddd, dd MMM yyyy") + ", " + Val.CommentedDate.ToString("hh:mm tt");
                    SingleRec.HavingParentCommentId = Val.HavingParentCommentId;
                    SingleRec.InnerComments = InnerResult(Val.InnerComments, SingleRec.CommentId);

                    _InnerResult.Add(SingleRec);
                }
            }
            return _InnerResult;
        }

        public ActionResult AddedAccPosts()
        {
            var model = new SE_Menus();
            ArrayList _Array = new ArrayList();

            ViewBag.AccPRoomTypes = Reusable.RoomTypes();

            string _States = ApiHelper.PostData_Json("api/Shared/GetStates?Values=", _Array);
            Result<List<SE_RefValues>> _ResultStates = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_States);
            ViewBag.AccPStates = Reusable.StatesList(_ResultStates);

            string _Countries = ApiHelper.PostData_Json("api/Shared/GetCountries?Values=", _Array);
            Result<List<SE_RefValues>> _ResultCountries = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Countries);
            ViewBag.AccPCountries = Reusable.CountriesList(_ResultCountries);

            return View("../PartialViews/AddAccPosts");
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertAccPosts(SE_Accommodation _Posts)
        {
            try
            {
                //Server-Side Validations
                if (_Posts.Title == null || Sanitizer.GetSafeHtmlFragment(_Posts.Title) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.Title).Length > 30 || Sanitizer.GetSafeHtmlFragment(_Posts.Title).Length < 5)
                    return Json(new Result(false, 500, "Validation Error", "Title should not be Empty and must have Min of 5 & Max of 30 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.RoomType == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.RoomType)) == "")
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_Posts.Address == null || Sanitizer.GetSafeHtmlFragment(_Posts.Address) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.Address).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Posts.Address).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Address should not be Empty and must have Min of 3 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.City == null || Sanitizer.GetSafeHtmlFragment(_Posts.City) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.City).Length > 30 || Sanitizer.GetSafeHtmlFragment(_Posts.City).Length < 2)
                    return Json(new Result(false, 500, "Validation Error", "City should not be Empty and must have Min of 2 & Max of 30 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.StateId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.StateId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.StateId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_Posts.CountryId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.CountryId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.CountryId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_Posts.ZipCode == null || Sanitizer.GetSafeHtmlFragment(_Posts.ZipCode) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.ZipCode).Length > 10 || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.ZipCode)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "ZipCode should not be Empty and must contain only Numbers with Max of 10 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.Description == null || Sanitizer.GetSafeHtmlFragment(_Posts.Description) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.Description).Length > 300 || Sanitizer.GetSafeHtmlFragment(_Posts.Description).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must have Min of 3 & Max of 300 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.ImagePath != null)
                {
                    List<string> _ext = Reusable.ProfilePicExtentions();
                    if (!_ext.Contains(_Posts.ImgType))
                        return Json(new Result(false, 500, "Validation Error", "Upload Images of Extentions .JPG, .JPEG, .PNG"), JsonRequestBehavior.AllowGet);
                }

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                _Posts.UserId = _SessionUserDetails.UserId;

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Posts);
                string response = ApiHelper.PostData_Json("api/CPanelUser/InsertAccPosts?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteAccPost(int DeleteAccPostID)
        {
            try
            {
                //Server-Side Validations
                if (Sanitizer.GetSafeHtmlFragment(DeleteAccPostID.ToString()) == "" || Sanitizer.GetSafeHtmlFragment(DeleteAccPostID.ToString()).Length > 10 || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(DeleteAccPostID)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Validation Error"), JsonRequestBehavior.AllowGet);

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                List<string> _Val = new List<string>();
                _Val.Add(_SessionUserDetails.UserId.ToString());
                _Val.Add(DeleteAccPostID.ToString());

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);

                string response = ApiHelper.PostData_Json("api/CPanelUser/DeleteAccPosts?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertComments(string Comments, string PageColumnId, string PageId)
        {
            try
            {
                //Server-Side Validations
                if (Comments == null || Sanitizer.GetSafeHtmlFragment(Comments) == "" || Sanitizer.GetSafeHtmlFragment(Comments).Length > 500 || Sanitizer.GetSafeHtmlFragment(Comments).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Comment should not be Empty and must have Min of 3 & Max of 500 Characters"), JsonRequestBehavior.AllowGet);

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;

                List<string> _Values = new List<string>();
                _Values.Add(Comments);
                _Values.Add(PageColumnId.ToString());
                _Values.Add(PageId.ToString());
                _Values.Add(_SessionUserDetails.UserId.ToString());
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Values);
                string response = ApiHelper.PostData_Json("api/CPanelUser/InsertComments?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertReplyComments(string Comments, string PageColumnId, string PageId, string ParentCommentId)
        {
            try
            {
                //Server-Side Validations
                if (Comments == null || Sanitizer.GetSafeHtmlFragment(Comments) == "" || Sanitizer.GetSafeHtmlFragment(Comments).Length > 500 || Sanitizer.GetSafeHtmlFragment(Comments).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Comment should not be Empty and must have Min of 3 & Max of 500 Characters"), JsonRequestBehavior.AllowGet);

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;

                List<string> _Values = new List<string>();
                _Values.Add(Comments);
                _Values.Add(PageColumnId.ToString());
                _Values.Add(PageId.ToString());
                _Values.Add(_SessionUserDetails.UserId.ToString());
                _Values.Add(ParentCommentId);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Values);
                string response = ApiHelper.PostData_Json("api/CPanelUser/InsertReplyComments?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult AccommodationRequests()
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                return View();
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }
        #endregion
    }
}
