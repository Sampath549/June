﻿using Microsoft.Office.Interop.Word;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using WebApp.App_Start;
using WebApp.Filters;
using WebApp.Helper;
using WebApp.Models.SharedEntities;

namespace WebApp.Controllers
{
    [MVCSessionFilter, MVCDevAuthorization]
    public class CPanelDevController : Controller
    {
        #region Global Variables
        //SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
        #endregion

        #region Dashboard
        public ActionResult Dashboard()
        {
            try
            {
                ViewBag.DisplayModalPopup = Reusable.CheckIsFirstTimeLogin();   // Model PopUp   
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
            return View();
        }
        #endregion

        #region Users
        public ActionResult CreateAllUsers()
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                ArrayList _Array = new ArrayList();
                string _Roles = ApiHelper.PostData_Json("api/Shared/RoleList?Values=", _Array);
                Result<List<SE_RefValues>> _ResultRoles = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Roles);
                ViewBag.Roles_dll = Reusable.RolesList(_ResultRoles);
                return View();
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CreateAllUsers(SE_Users _User)
        {
            SE_Users Users = new SE_Users();
            try
            {
                //Server-Side Validations
                if (_User.FirstName == null || Sanitizer.GetSafeHtmlFragment(_User.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "First Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.LastName == null || Sanitizer.GetSafeHtmlFragment(_User.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Last Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Email == null || Sanitizer.GetSafeHtmlFragment(_User.Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Email).Length > 75)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format with max of 75 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Mobile == null || Sanitizer.GetSafeHtmlFragment(_User.Mobile) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Mobile), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Mobile).Length != 10)
                    return Json(new Result(false, 500, "Validation Error", "Mobile should not be Empty and must contain only Numbers with 10 digits"), JsonRequestBehavior.AllowGet);
                if (Sanitizer.GetSafeHtmlFragment(_User.RoleId.ToString()) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.RoleId.ToString()), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Role"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                Users = new SE_Users();
                Users.FirstName = RSAPattern.Encrypt(_User.FirstName);
                Users.LastName = RSAPattern.Encrypt(_User.LastName);
                Users.Email = RSAPattern.Encrypt(_User.Email);
                Users.Mobile = RSAPattern.Encrypt(_User.Mobile);
                Users.RoleId = _User.RoleId;

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Users);
                string response = ApiHelper.PostData_Json_NToken("api/Login/Registration?Users=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result<SE_Users>(Users, false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult AllUserDetails()
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                return View();
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }
        #endregion

        #region C.R.U.D Roles
        public ActionResult CreateRole()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetRolesGrid()
        {
            List<SE_RefValues> _list = new List<SE_RefValues>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Roles = ApiHelper.PostData_Json("api/CPanelDev/GetRolesGrid?Values=", _Array);
                Result<List<SE_RefValues>> _ResultRoles = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Roles);

                _list = _ResultRoles.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString( c.Id ),          // 0   
                                 Convert.ToString( c.Code ),        // 1   
                                 Convert.ToString( c.Description),  // 2     
                             };

                return Json(new { aaData = result, URL = "", isRedirect = false }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { }, URL = "/Error/Unauthorized", isRedirect = true }, JsonRequestBehavior.AllowGet);
                //return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
                //return Json({ redirectUrl = Url.Action("Index", "Home"), isRedirect = true });
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult SaveUpdateRole(string Code, string Description, string ButtonType)
        {
            try
            {
                if (ButtonType == "Save")
                {
                    if (Code == null || Sanitizer.GetSafeHtmlFragment(Code) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Code), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Code).Length > 5 || Sanitizer.GetSafeHtmlFragment(Code).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Code should not be Empty and must contain only Alphabets with Minimum of 2 characters"), JsonRequestBehavior.AllowGet);
                    if (Description == null || Sanitizer.GetSafeHtmlFragment(Description) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Description), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Description).Length > 100 || Sanitizer.GetSafeHtmlFragment(Description).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain only Alphabets with Minimum of 2 characters"), JsonRequestBehavior.AllowGet);
                }
                else if (ButtonType == "Update")
                {
                    if (Description == null || Sanitizer.GetSafeHtmlFragment(Description) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Description), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(Description).Length > 100 || Sanitizer.GetSafeHtmlFragment(Description).Length < 2)
                        return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain only Alphabets with Minimum of 2 characters"), JsonRequestBehavior.AllowGet);
                }

                //RSA Encryption		
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(Code));
                _Val.Add(RSAPattern.Encrypt(Description));
                _Val.Add(RSAPattern.Encrypt(ButtonType));

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/SaveUpdateRole?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteRole(string Code)
        {
            try
            {
                //RSA Encryption
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(Code));

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/DeleteRole?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region C.R.U.D Menus
        public ActionResult CreateMenus()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetMenusGrid()
        {
            List<SE_Menus> _list = new List<SE_Menus>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Roles = ApiHelper.PostData_Json("api/CPanelDev/GetMenusGrid?Values=", _Array);
                Result<List<SE_Menus>> _ResultRoles = JsonConvert.DeserializeObject<Result<List<SE_Menus>>>(_Roles);

                _list = _ResultRoles.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.ParentId),      // 0   
                                 Convert.ToString(c.Header),        // 1   
                                 Convert.ToString(c.Controller),    // 2     
                                 Convert.ToString(c.Action),        // 3     
                                 Convert.ToString(c.HavingChild),   // 4     
                                 Convert.ToString(c.Order),         // 5     
                                 Convert.ToString(c.Icon),          // 6     
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult AddMenus()
        {
            var model = new SE_Menus();
            ViewBag.MenuTitle = "Add Menu";
            ViewBag.Menubtn = "Save";
            return View("../PartialViews/AddMenus");
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertUpdateMenus(SE_Menus _Menus)
        {
            try
            {
                //Server-Side Validations
                if (_Menus.Header == null || Sanitizer.GetSafeHtmlFragment(_Menus.Header) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Menus.Header), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_Menus.Header).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Menus.Header).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Header should not be Empty and must contain only Alphabets with Min of 3 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);
                if (_Menus.Controller != null || Sanitizer.GetSafeHtmlFragment(_Menus.Controller) != "")
                    if (Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Menus.Controller), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_Menus.Controller).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Menus.Controller).Length < 3)
                        return Json(new Result(false, 500, "Validation Error", "Controller must contain only Alphabets with Min of 3 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);
                if (_Menus.Action != null || Sanitizer.GetSafeHtmlFragment(_Menus.Action) != "")
                    if (Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Menus.Action), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_Menus.Action).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Menus.Action).Length < 3)
                        return Json(new Result(false, 500, "Validation Error", "Action must contain only Alphabets with Min of 3 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);
                if (Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Menus.HavingChild)) == "")
                    return Json(new Result(false, 500, "Validation Error", "Please Select HavingChild Yes / No"), JsonRequestBehavior.AllowGet);
                if (_Menus.Order == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Menus.Order)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Menus.Order)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Order should not be Empty and must contain only Numbers with Max of 3 Digits"), JsonRequestBehavior.AllowGet);
                if (_Menus.Icon == null || Sanitizer.GetSafeHtmlFragment(_Menus.Icon) == "" || Sanitizer.GetSafeHtmlFragment(_Menus.Icon).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Menus.Icon).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Icon should not be Empty and must contain Min of 3 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Menus);
                string response = ApiHelper.PostData_Json("api/CPanelDev/InsertUpdateMenus?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public ActionResult EditMenus(int id)
        {
            var model = new SE_Menus();
            try
            {
                List<int> _Val = new List<int>();
                _Val.Add(id);
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/EditMenus?Values=", _Array);
                Result<SE_Menus> _Result = JsonConvert.DeserializeObject<Result<SE_Menus>>(response);

                if (_Result.Status)
                {
                    model.ParentId = _Result.Data.ParentId;
                    model.Header = _Result.Data.Header;
                    model.Controller = _Result.Data.Controller;
                    model.Action = _Result.Data.Action;
                    model.HavingChild = _Result.Data.HavingChild;
                    model.Order = _Result.Data.Order;
                    model.Icon = _Result.Data.Icon;
                }

                ViewBag.MenuTitle = "Edit Menu";
                ViewBag.Menubtn = "Update";
                return View("../PartialViews/AddMenus", model);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteMenus(string IdVal)
        {
            try
            {
                //RSA Encryption
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(IdVal.ToString()));

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/DeleteMenus?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region C.R.U.D Sub Menus
        public ActionResult CreateSubMenus()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }


        public JsonResult GetSubMenusGrid()
        {
            List<SE_SubMenus> _list = new List<SE_SubMenus>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Roles = ApiHelper.PostData_Json("api/CPanelDev/GetSubMenusGrid?Values=", _Array);
                Result<List<SE_SubMenus>> _ResultRoles = JsonConvert.DeserializeObject<Result<List<SE_SubMenus>>>(_Roles);

                _list = _ResultRoles.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.ChildId),       // 0
                                 Convert.ToString(c.ParentId),      // 1   
                                 Convert.ToString(c.ParentHeader),  // 2
                                 Convert.ToString(c.Header),        // 3   
                                 Convert.ToString(c.Controller),    // 4     
                                 Convert.ToString(c.Action),        // 5     
                                 Convert.ToString(c.Order),         // 6     
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult AddSubMenus()
        {
            try
            {
                var model = new SE_SubMenus();
                ArrayList _Array = new ArrayList();
                string _ParentMenus = ApiHelper.PostData_Json("api/Shared/ParentMenus?Values=", _Array);
                Result<List<SE_RefValues>> _ResultParentMenus = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_ParentMenus);
                List<SelectListItem> ParentMenuList = new List<SelectListItem>();
                ParentMenuList.Add(new SelectListItem { Text = "Select Parent Menu", Value = "0" });
                for (int i = 0; i < _ResultParentMenus.Data.Count; i++)
                {
                    ParentMenuList.Add(new SelectListItem
                    {
                        Text = _ResultParentMenus.Data[i].Description.ToString(),
                        Value = _ResultParentMenus.Data[i].Id.ToString()
                    });
                }
                model.ParentMenus = ParentMenuList;

                ViewBag.SubMenuTitle = "Add Sub-Menu";
                ViewBag.SubMenubtn = "Save";
                return View("../PartialViews/AddSubMenus", model);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertUpdateSubMenus(SE_SubMenus _SubMenus)
        {
            try
            {
                //Server-Side Validations
                if (_SubMenus.ParentId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_SubMenus.ParentId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_SubMenus.ParentId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_SubMenus.Header == null || Sanitizer.GetSafeHtmlFragment(_SubMenus.Header) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_SubMenus.Header), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_SubMenus.Header).Length > 50 || Sanitizer.GetSafeHtmlFragment(_SubMenus.Header).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Header should not be Empty and must contain only Alphabets with Min of 3 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);
                if (_SubMenus.Controller == null || Sanitizer.GetSafeHtmlFragment(_SubMenus.Controller) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_SubMenus.Controller), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_SubMenus.Controller).Length > 50 || Sanitizer.GetSafeHtmlFragment(_SubMenus.Controller).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Controller should not be Empty and must contain only Alphabets with Min of 3 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);
                if (_SubMenus.Action == null || Sanitizer.GetSafeHtmlFragment(_SubMenus.Action) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_SubMenus.Action), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_SubMenus.Action).Length > 50 || Sanitizer.GetSafeHtmlFragment(_SubMenus.Action).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Action should not be Empty and must contain only Alphabets with Min of 3 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);
                if (_SubMenus.Order == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_SubMenus.Order)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_SubMenus.Order)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Order should not be Empty and must contain only Numbers with Max of 3 Digits"), JsonRequestBehavior.AllowGet);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_SubMenus);
                string response = ApiHelper.PostData_Json("api/CPanelDev/InsertUpdateSubMenus?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public ActionResult EditSubMenus(int id)
        {
            var model = new SE_SubMenus();
            try
            {
                List<int> _Val = new List<int>();
                _Val.Add(id);
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/EditSubMenus?Values=", _Array);
                Result<SE_SubMenus> _Result = JsonConvert.DeserializeObject<Result<SE_SubMenus>>(response);

                if (_Result.Status)
                {
                    string _ParentMenus = ApiHelper.PostData_Json("api/Shared/ParentMenus?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultParentMenus = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_ParentMenus);
                    List<SelectListItem> ParentMenuList = new List<SelectListItem>();
                    ParentMenuList.Add(new SelectListItem { Text = "Select Parent Menu", Value = "0" });
                    for (int i = 0; i < _ResultParentMenus.Data.Count; i++)
                    {
                        ParentMenuList.Add(new SelectListItem
                        {
                            Text = _ResultParentMenus.Data[i].Description.ToString(),
                            Value = _ResultParentMenus.Data[i].Id.ToString()
                        });
                    }
                    model.ParentMenus = ParentMenuList;

                    model.ChildId = _Result.Data.ChildId;
                    model.ParentId = _Result.Data.ParentId;
                    model.Header = _Result.Data.Header;
                    model.Controller = _Result.Data.Controller;
                    model.Action = _Result.Data.Action;
                    model.Order = _Result.Data.Order;
                }

                ViewBag.SubMenuTitle = "Edit Sub-Menu";
                ViewBag.SubMenubtn = "Update";
                return View("../PartialViews/AddSubMenus", model);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteSubMenus(string IdVal)
        {
            try
            {
                //RSA Encryption
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(IdVal.ToString()));

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/DeleteSubMenus?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region C.R.U.D Assigned Menus
        public ActionResult CreateAssignedMenus()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetAssignedMenusGrid()
        {
            List<SE_AssignedMenus> _list = new List<SE_AssignedMenus>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _AMenus = ApiHelper.PostData_Json("api/CPanelDev/GetAssignedMenusGrid?Values=", _Array);
                Result<List<SE_AssignedMenus>> _ResultAMenus = JsonConvert.DeserializeObject<Result<List<SE_AssignedMenus>>>(_AMenus);

                _list = _ResultAMenus.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.AssignedMenuId),    // 0
                                 Convert.ToString(c.ParentId),          // 1   
                                 Convert.ToString(c.ParentHeader),      // 2
                                 Convert.ToString(c.RoleId),            // 3   
                                 Convert.ToString(c.RoleDesc)           // 4     
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult AddAssignedMenus()
        {
            try
            {
                var model = new SE_AssignedMenus();

                ArrayList _Array = new ArrayList();
                string _ParentMenus = ApiHelper.PostData_Json("api/Shared/ParentMenus?Values=", _Array);
                Result<List<SE_RefValues>> _ResultParentMenus = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_ParentMenus);
                List<SelectListItem> ParentMenuList = new List<SelectListItem>();
                ParentMenuList.Add(new SelectListItem { Text = "Select Parent Menu", Value = "0" });
                for (int i = 0; i < _ResultParentMenus.Data.Count; i++)
                {
                    ParentMenuList.Add(new SelectListItem
                    {
                        Text = _ResultParentMenus.Data[i].Description.ToString(),
                        Value = _ResultParentMenus.Data[i].Id.ToString()
                    });
                }
                model.ParentMenus = ParentMenuList;

                string _RolesDesc = ApiHelper.PostData_Json("api/Shared/RoleList?Values=", _Array);
                Result<List<SE_RefValues>> _ResultRolesDesc = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_RolesDesc);
                List<SelectListItem> RolesDescList = new List<SelectListItem>();
                RolesDescList.Add(new SelectListItem { Text = "Select Role", Value = "0" });
                for (int i = 0; i < _ResultRolesDesc.Data.Count; i++)
                {
                    RolesDescList.Add(new SelectListItem
                    {
                        Text = _ResultRolesDesc.Data[i].Description.ToString(),
                        Value = _ResultRolesDesc.Data[i].Id.ToString()
                    });
                }
                model.RoleList = RolesDescList;

                ViewBag.AssignedMenuTitle = "Add Assigned-Menu";
                ViewBag.AssignedMenubtn = "Save";
                return View("../PartialViews/AddAssignedMenus", model);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertUpdateAssignedMenus(SE_AssignedMenus _AMenus)
        {
            try
            {
                //Server-Side Validations
                if (_AMenus.ParentId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_AMenus.ParentId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_AMenus.ParentId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_AMenus.RoleId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_AMenus.RoleId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_AMenus.RoleId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Role"), JsonRequestBehavior.AllowGet);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_AMenus);
                string response = ApiHelper.PostData_Json("api/CPanelDev/InsertUpdateAssignedMenus?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public ActionResult EditAssignedMenus(int id)
        {
            var model = new SE_AssignedMenus();
            try
            {
                List<int> _Val = new List<int>();
                _Val.Add(id);
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/EditAssignedMenus?Values=", _Array);
                Result<SE_AssignedMenus> _Result = JsonConvert.DeserializeObject<Result<SE_AssignedMenus>>(response);

                if (_Result.Status)
                {
                    string _ParentMenus = ApiHelper.PostData_Json("api/Shared/ParentMenus?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultParentMenus = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_ParentMenus);
                    List<SelectListItem> ParentMenuList = new List<SelectListItem>();
                    ParentMenuList.Add(new SelectListItem { Text = "Select Parent Menu", Value = "0" });
                    for (int i = 0; i < _ResultParentMenus.Data.Count; i++)
                    {
                        ParentMenuList.Add(new SelectListItem
                        {
                            Text = _ResultParentMenus.Data[i].Description.ToString(),
                            Value = _ResultParentMenus.Data[i].Id.ToString()
                        });
                    }
                    model.ParentMenus = ParentMenuList;

                    string _RolesDesc = ApiHelper.PostData_Json("api/Shared/RoleList?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultRolesDesc = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_RolesDesc);
                    List<SelectListItem> RolesDescList = new List<SelectListItem>();
                    RolesDescList.Add(new SelectListItem { Text = "Select Role", Value = "0" });
                    for (int i = 0; i < _ResultRolesDesc.Data.Count; i++)
                    {
                        RolesDescList.Add(new SelectListItem
                        {
                            Text = _ResultRolesDesc.Data[i].Description.ToString(),
                            Value = _ResultRolesDesc.Data[i].Id.ToString()
                        });
                    }
                    model.RoleList = RolesDescList;

                    model.AssignedMenuId = _Result.Data.AssignedMenuId;
                    model.ParentId = _Result.Data.ParentId;
                    model.RoleId = _Result.Data.RoleId;
                }

                ViewBag.AssignedMenuTitle = "Edit Sub-Menu";
                ViewBag.AssignedMenubtn = "Update";
                return View("../PartialViews/AddAssignedMenus", model);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteAssignedMenus(string IdVal)
        {
            try
            {
                //RSA Encryption
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(IdVal.ToString()));

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/DeleteAssignedMenus?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region C.R.U.D Countries
        public ActionResult CreateCountries()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetCountriesGrid()
        {
            List<SE_RefValues> _list = new List<SE_RefValues>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _Countries = ApiHelper.PostData_Json("api/CPanelDev/GetCountriesGrid?Values=", _Array);
                Result<List<SE_RefValues>> _ResultCountries = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Countries);

                _list = _ResultCountries.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.Id),            // 0   
                                 Convert.ToString(c.Code),          // 1   
                                 Convert.ToString(c.Description),   // 2     
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult AddCountries()
        {
            var model = new SE_Menus();
            ViewBag.CountriesTitle = "Add Countries";
            ViewBag.Countriesbtn = "Save";
            return View("../PartialViews/AddCountries");
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertUpdateCountries(SE_RefValues _Countries)
        {
            try
            {
                //Server-Side Validations
                if (_Countries.Code == null || Sanitizer.GetSafeHtmlFragment(_Countries.Code) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Countries.Code), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_Countries.Code).Length > 5 || Sanitizer.GetSafeHtmlFragment(_Countries.Code).Length < 2)
                    return Json(new Result(false, 500, "Validation Error", "Code should not be Empty and must contain only Alphabets with Minimum of 2 characters"), JsonRequestBehavior.AllowGet);
                if (_Countries.Description == null || Sanitizer.GetSafeHtmlFragment(_Countries.Description) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Countries.Description), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_Countries.Description).Length > 100 || Sanitizer.GetSafeHtmlFragment(_Countries.Description).Length < 2)
                    return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain only Alphabets with Minimum of 2 characters"), JsonRequestBehavior.AllowGet);

                //RSA Encryption		
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(_Countries.Id.ToString()));
                _Val.Add(RSAPattern.Encrypt(_Countries.Code));
                _Val.Add(RSAPattern.Encrypt(_Countries.Description));

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/InsertUpdateCountries?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public ActionResult EditCountries(int id)
        {
            var model = new SE_RefValues();
            try
            {
                List<int> _Val = new List<int>();
                _Val.Add(id);
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/EditCountries?Values=", _Array);
                Result<SE_RefValues> _Result = JsonConvert.DeserializeObject<Result<SE_RefValues>>(response);

                if (_Result.Status)
                {
                    model.Id = _Result.Data.Id;
                    model.Code = _Result.Data.Code;
                    model.Description = _Result.Data.Description;
                }

                ViewBag.CountriesTitle = "Edit Countries";
                ViewBag.Countriesbtn = "Update";
                return View("../PartialViews/AddCountries", model);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteCountries(string IdVal)
        {
            try
            {
                //RSA Encryption
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(IdVal.ToString()));

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/DeleteCountries?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region C.R.U.D States
        public ActionResult CreateStates()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetStatesGrid()
        {
            List<SE_States> _list = new List<SE_States>();
            try
            {
                ArrayList _Array = new ArrayList();
                string _States = ApiHelper.PostData_Json("api/CPanelDev/GetStatesGrid?Values=", _Array);
                Result<List<SE_States>> _ResultStates = JsonConvert.DeserializeObject<Result<List<SE_States>>>(_States);

                _list = _ResultStates.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString(c.Id),            // 0   
                                 Convert.ToString(c.CountryId),     // 1   
                                 Convert.ToString(c.CountryName),   // 2
                                 Convert.ToString(c.Code),          // 3   
                                 Convert.ToString(c.Description),   // 4     
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult AddStates()
        {
            try
            {
                var model = new SE_States();

                ArrayList _Array = new ArrayList();
                string _Countries = ApiHelper.PostData_Json("api/Shared/GetCountries?Values=", _Array);
                Result<List<SE_RefValues>> _ResultCountries = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Countries);
                model.CountryList = Reusable.CountriesList(_ResultCountries);

                ViewBag.StatesTitle = "Add States";
                ViewBag.Statesbtn = "Save";
                return View("../PartialViews/AddStates", model);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertUpdateStates(SE_States _States)
        {
            try
            {
                //Server-Side Validations
                if (_States.CountryId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_States.CountryId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_States.CountryId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Country"), JsonRequestBehavior.AllowGet);
                if (_States.Code == null || Sanitizer.GetSafeHtmlFragment(_States.Code) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_States.Code), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_States.Code).Length > 5 || Sanitizer.GetSafeHtmlFragment(_States.Code).Length < 2)
                    return Json(new Result(false, 500, "Validation Error", "Code should not be Empty and must contain only Alphabets with Minimum of 2 characters"), JsonRequestBehavior.AllowGet);
                if (_States.Description == null || Sanitizer.GetSafeHtmlFragment(_States.Description) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_States.Description), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_States.Description).Length > 100 || Sanitizer.GetSafeHtmlFragment(_States.Description).Length < 2)
                    return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must contain only Alphabets with Minimum of 2 characters"), JsonRequestBehavior.AllowGet);

                //RSA Encryption		
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(_States.Id.ToString()));
                _Val.Add(RSAPattern.Encrypt(_States.CountryId.ToString()));
                _Val.Add(RSAPattern.Encrypt(_States.Code));
                _Val.Add(RSAPattern.Encrypt(_States.Description));

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/InsertUpdateStates?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public ActionResult EditStates(int id)
        {
            var model = new SE_States();
            try
            {
                List<int> _Val = new List<int>();
                _Val.Add(id);
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/EditStates?Values=", _Array);
                Result<SE_States> _Result = JsonConvert.DeserializeObject<Result<SE_States>>(response);

                if (_Result.Status)
                {
                    string _Countries = ApiHelper.PostData_Json("api/Shared/GetCountries?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultCountries = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Countries);
                    model.CountryList = Reusable.CountriesList(_ResultCountries);

                    model.Id = _Result.Data.Id;
                    model.CountryId = _Result.Data.CountryId;
                    model.Code = _Result.Data.Code;
                    model.Description = _Result.Data.Description;
                }

                ViewBag.StatesTitle = "Edit States";
                ViewBag.Statesbtn = "Update";
                return View("../PartialViews/AddStates", model);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteStates(string IdVal)
        {
            try
            {
                //RSA Encryption
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(IdVal.ToString()));

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanelDev/DeleteStates?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region C.R.U.D Error Log
        public ActionResult ViewErrorLog()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public JsonResult GetErrorLogGrid()
        {
            List<SE_States> _list = new List<SE_States>();
            try
            {
                //WorkDocumets
                IList<SE_RefValues> _List = new List<SE_RefValues>();

                DirectoryInfo d = new DirectoryInfo(Server.MapPath("~/ErrorLog"));
                FileInfo[] Files = d.GetFiles("*.txt"); //Getting Text files

                int k = 1;
                foreach (FileInfo file in Files)
                {
                    _List.Add(new SE_RefValues { Id = Convert.ToInt32(k), Description = file.Name });
                    k++;
                }

                var result = from c in _List
                             select new[]
                             {
                                 Convert.ToString(c.Id),            // 0   
                                 Convert.ToString(c.Description),   // 1        
                             };

                return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public ActionResult ViewErrorLog_TextFile(string IdVal)
        {
            try
            {
                if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                    Reusable.BindMenus();
                ViewBag.Menus = SessionHandler.Menus;
                ViewBag.ErrorlogName = IdVal;

                string DocName = IdVal;

                DirectoryInfo d = new DirectoryInfo(Server.MapPath("~/ErrorLog")); //Assuming Test is your Folder
                FileInfo[] Files = d.GetFiles("*.txt"); //Getting Text files

                foreach (FileInfo file in Files)
                {
                    if (DocName == file.Name)
                    {
                        Application application = new Application();
                        Document document = application.Documents.Open(Server.MapPath("~/ErrorLog/" + DocName));

                        string allWords = document.Content.Text; //Get all words
                        document.Close();
                        application.Quit();

                        ViewBag.Message = allWords;
                    }
                }
                return View();
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteErrorLog(string IdVal)
        {
            try
            {
                string DocName = IdVal;

                DirectoryInfo d = new DirectoryInfo(Server.MapPath("~/ErrorLog")); //Assuming Test is your Folder
                FileInfo[] Files = d.GetFiles("*.txt"); //Getting Text files

                foreach (FileInfo file in Files)
                {
                    if (DocName == file.Name)
                        System.IO.File.Delete(Server.MapPath(("~/ErrorLog/") + DocName));
                }
                return Json(new Result(true, 200, "Success", "File Deleted Successfully"), JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion
    }
}