﻿jQuery.validator.addMethod("passwordCheck", function (value) {
    return /[@$!%*?&\s]+/.test(value) // consists of special sharacter including space
      && /[a-z]/.test(value) // has a lowercase letter
      && /[A-Z]/.test(value) // has a uppercase letter
      && /\d/.test(value) // has a digit
});

$(document).ready(function () {
    $("#UpdatePwdId").modal('show');

    $("#FirstTimeLogin").validate({
        rules: {
            UPoldpwd: {
                required: true,
                minlength: 8
            },
            UPpwd: {
                required: true,
                minlength: 8,
                maxlength: 50,
                passwordCheck: true
            },
            UPCpwd: {
                required: true,
                minlength: 8,
                equalTo: '[name="UPpwd"]'
            }
        },
        messages: {
            UPoldpwd: {
                required: 'Enter Old Password.',
                minlength: 'Min 8 Character'
            },
            UPpwd: {
                required: 'Enter New Password.',
                minlength: 'Min 8 Characters',
                maxlength: 'Max 50 Characters',
                passwordCheck: 'Check Mandatory (*)'
            },
            UPCpwd: {
                required: 'Enter Confirm Password.',
                minlength: 'Min 8 Character',
                equalTo: 'Password Mismatch'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            setTimeout(function () {

                var _postData = {
                    OldPassword: $('#UPoldpwd').val(),
                    Password: $('#UPpwd').val(),
                    CPassword: $('#UPCpwd').val()
                };

                $.ajax({
                    type: "POST",
                    url: "/CPanel/OneTimePassword",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                        if (!response.Status)
                            toastr.error(response.Message, response.Caption, opts);
                        else
                            $("#UpdatePwdId").modal('hide');

                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
                //$(".loadingImg").hide();
            }, 0);
        }
    });
});