﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

$(document).ready(function () {

    var UploadedFileType;
    var FileExtention;
    var FileSize;
    var ImgData;

    $("#UploadUserImage").change(function (e) {
        if (!e) e = window.event;
        var file = e.target.files[0] || e.srcElement.files[0];
        //var filename = e.target.files[0].name;
        UploadedFileType = file.type;
        FileSize = file.size;

        if (file.type == "image/jpeg") {
            var fileReader = new FileReader();
            fileReader.onload = function (fileLoadedEvent) {
                FileExtention = ".jpg";
                ImgData = fileLoadedEvent.target.result;
            };
            fileReader.readAsDataURL(file);
        }
        else if (file.type == "image/png") {
            var fileReader = new FileReader();
            fileReader.onload = function (fileLoadedEvent) {
                FileExtention = ".png";
                ImgData = fileLoadedEvent.target.result;
            };
            fileReader.readAsDataURL(file);
        }
        else {
            var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
            toastr.error('Upload Images of Extentions .JPG, .JPEG, .PNG', 'Validation Error', opts);
            $("#UploadUserImage").val(null);
        }
    })

    if ($('#isCurrentPermanent').is(':checked')) {
        $('#MPFCAddr').val($('#MPFPAddr').val());
        $('#MPFCCity').val($('#MPFPCity').val());
        $("#CStateId").val($('#PStateId option:selected').val());
        $("#CCountryId").val($('#PCountryId option:selected').val());
        $('#MPFCZip').val($('#MPFPZip').val());

        $('#MPFCAddr').attr('disabled', true);
        $('#MPFCCity').attr('disabled', true);
        $("#CStateId").attr('disabled', true);
        $("#CCountryId").attr('disabled', true);
        $('#MPFCZip').attr('disabled', true);
    }

    $('.EnteringBackPAddr').keypress(function () {
        if ($('#isCurrentPermanent').is(':checked')) {
            $('#isCurrentPermanent').prop('checked', false)

            $('#MPFCAddr').val('');
            $('#MPFCCity').val('');
            $("#CStateId").val($('#CStateId option:first').val());
            $("#CCountryId").val($('#CCountryId option:first').val());
            $('#MPFCZip').val('');

            $('#MPFCAddr').attr('disabled', false);
            $('#MPFCCity').attr('disabled', false);
            $("#CStateId").attr('disabled', false);
            $("#CCountryId").attr('disabled', false);
            $('#MPFCZip').attr('disabled', false);
        }
    });

    $('#isCurrentPermanent').change(function () {
        if (this.checked) {
            $('#MPFCAddr').val($('#MPFPAddr').val());
            $('#MPFCCity').val($('#MPFPCity').val());
            $("#CStateId").val($('#PStateId option:selected').val());
            $("#CCountryId").val($('#PCountryId option:selected').val());
            $('#MPFCZip').val($('#MPFPZip').val());

            $('#MPFCAddr').attr('disabled', true);
            $('#MPFCCity').attr('disabled', true);
            $("#MP_CState").attr('disabled', true);
            $("#MP_CCountry").attr('disabled', true);
            $('#MPFCZip').attr('disabled', true);
        }
        else {
            $('#MPFCAddr').val('');
            $('#MPFCCity').val('');
            $("#CStateId").val($('#CStateId option:first').val());
            $("#CCountryId").val($('#CCountryId option:first').val());
            $('#MPFCZip').val('');

            $('#MPFCAddr').attr('disabled', false);
            $('#MPFCCity').attr('disabled', false);
            $("#CStateId").attr('disabled', false);
            $("#CCountryId").attr('disabled', false);
            $('#MPFCZip').attr('disabled', false);
        }
    });

    $("#MyProfileForm").validate({
        rules: {
            MPFName: {
                required: true,
                maxlength: 35,
                lettersonly: true
            },
            MPLName: {
                required: true,
                maxlength: 35,
                lettersonly: true
            },
            MPFPZip: {
                maxlength: 10,
                number: true
            },
            MPFCZip: {
                maxlength: 10,
                number: true
            }
        },
        messages: {
            MPFName: {
                required: 'Enter First Name.',
                maxlength: 'Max 35 Characters'
            },
            MPLName: {
                required: 'Enter Last Name.',
                maxlength: 'Max 35 Characters',
            },
            MPFPZip: {
                minlength: 'Max 10 Digits',
                number: 'Enter Only Numbers'
            },
            MPFCZip: {
                maxlength: 'Max 10 Digits',
                number: 'Enter Only Numbers'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();

            var _postData = {
                FirstName: $('#MPFName').val(),
                LastName: $('#MPLName').val(),
                Gender: $('#Gender option:selected').val(),
                PAddress: $('#MPFPAddr').val(),
                PCity: $('#MPFPCity').val(),
                PStateId: $('#PStateId option:selected').val(),
                PCountryId: $('#PCountryId option:selected').val(),
                PZipCode: $('#MPFPZip').val(),
                isCurrentPermanent: $('#isCurrentPermanent').prop('checked'),
                CAddress: $('#MPFCAddr').val(),
                CCity: $('#MPFCCity').val(),
                CStateId: $('#CStateId option:selected').val(),
                CCountryId: $('#CCountryId option:selected').val(),
                CZipCode: $('#MPFCZip').val(),
                ProfilePic: ImgData,
                ImgType: FileExtention,
                FileSize: FileSize
            }

            $.ajax({
                type: "POST",
                url: "/CPanel/MyProfile",
                data: _postData,
                dataType: "json",
                cache: false,
                headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                success: function (response) {
                    setTimeout(function () {

                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                        if (!response.Status) {
                            toastr.error(response.Message, response.Caption, opts);
                        }
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    window.location.href = "/CPanel/Dashboard";
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    }, 0);
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    alert(xhr.responseText);
                }
            });
        }
    });
});

function EnteringBackPAddrChanged() {
    if ($('#isCurrentPermanent').is(':checked')) {
        $('#isCurrentPermanent').prop('checked', false)

        $('#MPFCAddr').val('');
        $('#MPFCCity').val('');
        $("#CStateId").val($('#CStateId option:first').val());
        $("#CCountryId").val($('#CCountryId option:first').val());
        $('#MPFCZip').val('');

        $('#MPFCAddr').attr('disabled', false);
        $('#MPFCCity').attr('disabled', false);
        $("#CStateId").attr('disabled', false);
        $("#CCountryId").attr('disabled', false);
        $('#MPFCZip').attr('disabled', false);
    }
}