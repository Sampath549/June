﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Models.SharedEntities
{
    public class SE_SingleVal
    {
        public string TextValue { get; set; }
    }
}