﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using WebApp.Models.SharedEntities;

namespace WebApp.Helper
{
    public static class OAuthHelper
    {
        public static string AccessToken()
        {
            return GetOAuthToken();
        }

        private static string GetOAuthToken()
        {
            string _ClientKey = GlobalVariables.Shared.ClientId;
            string _ClientSecret = GlobalVariables.Shared.Secret;
            string _AuthName = SessionHandler.AuthName;
            string _Password = SessionHandler.AuthPwd;
            string _Url = GlobalVariables.Shared.ApiUrl;

            SE_AccessToken token = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(_Url);
                client.DefaultRequestHeaders.Clear();
                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("username", _AuthName),
                    new KeyValuePair<string, string>("password", _Password),
                    new KeyValuePair<string, string>("client_id", _ClientKey),
                    new KeyValuePair<string, string>("client_secret", _ClientSecret),
                    new KeyValuePair<string, string>("grant_type", "password"),
                });
                var result = client.PostAsync("token", content).Result.Content.ReadAsStringAsync().Result;
                if (!string.IsNullOrEmpty(result))
                {
                    token = JsonConvert.DeserializeObject<SE_AccessToken>(result);
                }
                return token.AccessToken;
            }
        }
    }
}