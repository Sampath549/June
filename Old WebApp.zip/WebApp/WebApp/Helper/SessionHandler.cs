﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApp.Models.SharedEntities;

namespace WebApp.Helper
{
    public static class SessionHandler
    {
        public static string AuthName
        {
            get
            {
                return HttpContext.Current.Session["AuthName"] != null ? HttpContext.Current.Session["AuthName"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["AuthName"] = value;
            }
        }

        public static string AuthPwd
        {
            get
            {
                return HttpContext.Current.Session["AuthPwd"] != null ? HttpContext.Current.Session["AuthPwd"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["AuthPwd"] = value;
            }
        }
        public static string WelcomeName
        {
            get
            {
                return HttpContext.Current.Session["WelcomeName"] != null ? HttpContext.Current.Session["WelcomeName"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["WelcomeName"] = value;
            }
        }
        public static string WelcomeNameTitle
        {
            get
            {
                return HttpContext.Current.Session["WelcomeNameTitle"] != null ? HttpContext.Current.Session["WelcomeNameTitle"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["WelcomeNameTitle"] = value;
            }
        }
        public static string ProfilePic
        {
            get
            {
                return HttpContext.Current.Session["ProfilePic"] != null ? HttpContext.Current.Session["ProfilePic"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["ProfilePic"] = value;
            }
        }
        public static SE_Users UserDetails
        {
            get
            {
                return HttpContext.Current.Session["_UserDetails"] != null ? HttpContext.Current.Session["_UserDetails"] as SE_Users : null;
            }
            set
            {
                HttpContext.Current.Session["_UserDetails"] = value;
            }
        }
        public static string Menus
        {
            get
            {
                return HttpContext.Current.Session["_Menus"] != null ? HttpContext.Current.Session["_Menus"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["_Menus"] = value;
            }
        }
    }
}