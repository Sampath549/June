﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApp.Models.SharedEntities;

namespace WebApp.Helper
{
    public static class Reusable
    {
        public static List<SelectListItem> RolesList(Result<List<SE_RefValues>> _ResultRoles)
        {
            try
            {
                List<SelectListItem> RolesList = new List<SelectListItem>();
                RolesList.Add(new SelectListItem { Text = "Select Role", Value = "0" });
                for (int i = 0; i < _ResultRoles.Data.Count; i++)
                {
                    RolesList.Add(new SelectListItem
                    {
                        Text = _ResultRoles.Data[i].Description.ToString(),
                        Value = _ResultRoles.Data[i].Id.ToString()
                    });
                }
                return RolesList;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> GenderList()
        {
            try
            {
                List<SelectListItem> GenderList = new List<SelectListItem>();
                GenderList.Add(new SelectListItem { Text = "Select Gender", Value = "0" });
                GenderList.Add(new SelectListItem { Text = "Male", Value = "1" });
                GenderList.Add(new SelectListItem { Text = "Female", Value = "2" });
                GenderList.Add(new SelectListItem { Text = "Other", Value = "3" });
                return GenderList;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }

        public static List<SelectListItem> RoomTypes()
        {
            try
            {
                List<SelectListItem> _Type = new List<SelectListItem>();
                _Type.Add(new SelectListItem { Text = "Select Room Type", Value = "0" });
                _Type.Add(new SelectListItem { Text = "Sharing Basis", Value = "Sharing Basis" });
                _Type.Add(new SelectListItem { Text = "Complete Flat / House", Value = "Complete Flat / House" });
                return _Type;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public static List<string> ProfilePicExtentions()
        {
            try
            {
                List<string> _ext = new List<string>();
                _ext.Add(".JPG");
                _ext.Add(".JPEG");
                _ext.Add(".PNG");
                _ext.Add(".jpg");
                _ext.Add(".jpge");
                _ext.Add(".png");
                return _ext;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> CountriesList(Result<List<SE_RefValues>> _ResultCountries)
        {
            try
            {
                List<SelectListItem> CountriesList = new List<SelectListItem>();
                CountriesList.Add(new SelectListItem { Text = "Select Country", Value = "0" });
                for (int k = 0; k < _ResultCountries.Data.Count; k++)
                {
                    CountriesList.Add(new SelectListItem
                    {
                        Text = _ResultCountries.Data[k].Description.ToString(),
                        Value = _ResultCountries.Data[k].Id.ToString()
                    });
                }
                return CountriesList;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> StatesList(Result<List<SE_RefValues>> _ResultStates)
        {
            try
            {
                List<SelectListItem> StatesList = new List<SelectListItem>();
                StatesList.Add(new SelectListItem { Text = "Select State", Value = "0" });
                for (int i = 0; i < _ResultStates.Data.Count; i++)
                {
                    StatesList.Add(new SelectListItem
                    {
                        Text = _ResultStates.Data[i].Description.ToString(),
                        Value = _ResultStates.Data[i].Id.ToString()
                    });
                }
                return StatesList;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public static string BindMenus()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                {
                    //RSA Encryption
                    List<string> _Val = new List<string>();
                    _Val.Add(RSAPattern.Encrypt(_SessionUserDetails.RoleCode));

                    //API Call		
                    ArrayList _Array = new ArrayList();
                    _Array.Add(_Val);
                    string _Menu = ApiHelper.PostData_Json("api/CPanel/BindMenus?Values=", _Array);
                    Result<string> _Result = JsonConvert.DeserializeObject<Result<string>>(_Menu);

                    SessionHandler.Menus = _Result.Data;
                }
                return SessionHandler.Menus;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public static bool CheckIsFirstTimeLogin()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            if (_SessionUserDetails.IsFirstTimeLogin)
                return true;
            else
                return false;
        }
    }
}