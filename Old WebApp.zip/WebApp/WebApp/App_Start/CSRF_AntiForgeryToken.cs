﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Routing;
using WebApp.Helper;

namespace WebApp.App_Start
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class CSRF_AntiForgeryToken : FilterAttribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationContext filterContext)
        {
            try
            {
                if (filterContext.HttpContext.Request.IsAjaxRequest()) //If the Request is from Ajax Call
                {
                    if (filterContext.HttpContext.Request.RequestType.ToLower() == "post")
                        ValidateRequestHeader(filterContext.HttpContext.Request, filterContext);
                }
                else if (filterContext.HttpContext.Request.RequestType.ToLower() == "post") //If the Request is with in the MVC
                {
                    AntiForgery.Validate();
                }
            }
            catch
            {
                HandleUnauthenticatedPages(filterContext);
            }
        }
        private void ValidateRequestHeader(HttpRequestBase request, AuthorizationContext filterContext)
        {
            string cookieToken = string.Empty;
            string formToken = string.Empty;
            var antiForgeryCookie = request.Cookies[AntiForgeryConfig.CookieName];
            var cookieValue = antiForgeryCookie != null ? antiForgeryCookie.Value : null;

            if (!string.IsNullOrEmpty(request.Headers["__RequestVerificationToken"]))
            {
                string[] tokens = request.Headers["__RequestVerificationToken"].Split(':');
                if (tokens.Length == 2)
                {
                    cookieToken = tokens[0].Trim();
                    formToken = tokens[1].Trim();
                    AntiForgery.Validate(cookieToken, formToken);
                }
                else
                {
                    AntiForgery.Validate(cookieValue, request.Headers["__RequestVerificationToken"]);
                }
            }
            else
            {
                HandleUnauthenticatedPages(filterContext);
            }
        }
        private void HandleUnauthenticatedPages(AuthorizationContext filterContext)
        {
            var values = new RouteValueDictionary(new { action = GlobalVariables.Shared.SessionExpired, controller = "Error" });
            filterContext.Result = new RedirectToRouteResult(values);
        }
    }
}