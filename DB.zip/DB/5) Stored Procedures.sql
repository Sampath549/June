USE [StepTek]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_AuthenticatedUser]
( 
 @EmailId	VARCHAR(800),  
 @Password	VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 

	DECLARE @Status					VARCHAR(5),  
			@UserId					INT = NULL,  
			@FirstName				VARCHAR(800) = NULL,
			@LastName				VARCHAR(800) = NULL,
			@FullName				VARCHAR(800) = NULL,
			@Email					VARCHAR(800) = NULL,
			@Mobile					VARCHAR(800) = NULL,
			@RoleId					INT = NULL,  
			@RoleCode				VARCHAR(50) = NULL,  
			@IsFirstTimeLogin		BIT = NULL,
			@ProfilePic				VARCHAR(MAX) = NULL

	IF (SELECT Count(*) FROM [StepTekDB].[tbl_Users] WHERE Email = @EmailId AND [Password] = @Password) = 0  
		BEGIN  
			SET @Status = 0   
		END  
	ELSE  
		BEGIN  
			SELECT  @Status = 1,  
					@UserId = U.UserId,  
					@FirstName = U.FirstName,  
					@LastName = U.LastName, 
					@FullName = (U.FirstName + ' ' + U.LastName),  
					@Email = U.Email,  
					@Mobile = U.Mobile,  
					@RoleId = U.RoleId,  
					@RoleCode = R.Code,  
					@ProfilePic = U.Photo,
					@IsFirstTimeLogin = U.IsFirstTimeLogin
			FROM   
				[StepTekDB].[tbl_Users] U
			INNER JOIN [StepTekDB].[Ref_Roles] R ON U.RoleId = R.RoleId
			WHERE U.Email = @EmailId  AND U.[Password] = @Password

			IF (SELECT Count(*) FROM [StepTekDB].[tbl_UserMapping] WHERE UserId = @UserId) = 0  
				BEGIN
					INSERT INTO [StepTekDB].[tbl_UserMapping] (UserId) VALUES (@UserId)
				END
	  END  

	SELECT  @Status AS [Status],
			@UserId AS UserId,
			@FirstName AS FirstName,
			@LastName AS LastName,
			@FullName AS FullName,
			@Email AS Email,
			@Mobile AS Mobile,
			@RoleId AS RoleId, 
			@RoleCode AS RoleCode,
			@ProfilePic AS Photo,
			@IsFirstTimeLogin AS IsFirstTimeLogin
END 
--EXEC USP_Get_AuthenticatedUser 'GLlFWpU4PZsR+jb7S1PkGyvwFX9EHwCBLkie7NeA9o8=','Nky5VhXfD6T9ZLaUWTO5BNeu+rMdVMz4X96RSeKh7mg='
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_MenuListByRole]
(
	@RoleCode	VARCHAR(10)
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RoleId INT
	SET @RoleId= (SELECT RoleId FROM [StepTekDB].[Ref_Roles] WHERE Code = @RoleCode)

	SELECT
		AM.ParentId,
		M.Header,
		M.Controller,
		M.[Action],
		M.HavingChild,
		M.[Order],
		M.Icon
	FROM [StepTekDB].[tbl_AssignMenus] AS AM
	INNER JOIN [StepTekDB].[tbl_Menus] M ON M.ParentId= AM.ParentId
	WHERE AM.RoleId = @RoleId
	
	SELECT
		AM.ParentId,
		SM.Header,
		SM.Controller,
		SM.[Action],
		SM.[Order]
	FROM [StepTekDB].[tbl_AssignMenus] AS AM
	INNER JOIN [StepTekDB].[tbl_SubMenus] SM ON SM.ParentId= AM.ParentId
	WHERE AM.RoleId = @RoleId	

END
-- EXEC USP_Get_MenuListByRole 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_UserDetails]
( 
 @Email	VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 

	DECLARE @UserId INT
	
	IF (SELECT Count(*) FROM [StepTekDB].[tbl_Users] WHERE Email = @Email) > 0  
		BEGIN  
			SET @UserId= (SELECT UserId FROM [StepTekDB].[tbl_Users] WHERE Email = @Email)

			SELECT	U.UserId,
					U.Gender,
					UM.PermanentStreetAddress [Address],
					UM.PermanentCity [City],
					UM.PermanentState [StateId],
					UM.PermanentCountry [CountryId],
					UM.PermanentZipCode [ZipCode]
			FROM   
				[StepTekDB].[tbl_Users] U
			INNER JOIN [StepTekDB].[tbl_UserMapping] UM ON U.UserId = UM.UserId
			WHERE U.UserId = @UserId
		END  
END 
-- EXEC [USP_Get_UserDetails] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Update_UserProfile]
(
	@Email				VARCHAR(800),
	@FirstName			VARCHAR(800),
	@LastName			VARCHAR(800),
	@Gender				VARCHAR(500) = NULL,
	@Address			VARCHAR(800) = NULL,
	@City				VARCHAR(800) = NULL,
	@StateId			INT = NULL,
	@CountryId			INT = NULL,
	@ZipCode			BIGINT = NULL,
	@OutputResult		INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;
	
	BEGIN TRANSACTION;
	SAVE TRANSACTION MySavePoint;
		
	BEGIN TRY
		
		DECLARE @UserId INT
		SET @UserId= (SELECT UserId FROM [StepTekDB].[tbl_Users] WHERE Email = @Email)
		
		BEGIN
			UPDATE [StepTekDB].[tbl_Users] SET [FirstName] = @FirstName, [LastName] = @LastName, [Gender] = @Gender  WHERE UserId = @UserId
			UPDATE [StepTekDB].[tbl_UserMapping] 
						SET [IsPermanentAddress] = 1,	
							[PermanentStreetAddress] = @Address,
							[PermanentCity] = @City,
							[PermanentState] = @StateId,
							[PermanentCountry] = @CountryId,
							[PermanentZipCode] = @ZipCode,
							[CurrentStreetAddress] = NULL,
							[CurrentCity] = NULL,
							[CurrentState] = NULL,
							[CurrentCountry] = NULL,
							[CurrentZipCode] = NULL
						WHERE UserId = @UserId
			SET @OutputResult = 1	
		END	
				
	END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
			BEGIN
				SET @OutputResult = 0
				ROLLBACK TRANSACTION MySavePoint; 
			END
		END CATCH
		COMMIT TRANSACTION 
	END	
--EXEC [USP_Update_UserProfile]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Update_ChangePassword]
(
	@UserId INT ,
	@OldPwd VARCHAR(800),
	@OldKey VARCHAR(800),
	@NewPwd VARCHAR(800),
	@NewKey VARCHAR(800),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_Users] WHERE UserId = @UserId) > 0)
		BEGIN
			IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_Users] WHERE [Password] = @OldPwd AND SaltKey = @OldKey) > 0)
				BEGIN
					UPDATE [StepTekDB].[tbl_Users] SET [Password] = @NewPwd , SaltKey = @NewKey, IsFirstTimeLogin = 0 WHERE UserId = @UserId
					SET @OutPut = 1 
				END
			ELSE
				SET @OutPut = 99 -- Old Password Incorrect
		END
	ELSE
		SET @OutPut = 100 -- No User
END
-- EXEC [USP_Update_ChangePassword] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Insert_Users]
( 
  @PersonalKey      VARCHAR(800),
  @FirstName		VARCHAR(800),
  @LastName         VARCHAR(800),
  @Email            VARCHAR(800),
  @Mobile           VARCHAR(800),
  @RoleId	        VARCHAR(10),
  @Password         VARCHAR(800),
  @SaltKey          VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 
	INSERT INTO [StepTekDB].[tbl_Users] (PersonalKey, FirstName, LastName, Email, Mobile, RoleId, [Password], SaltKey, [CreatedDate])
	VALUES (@PersonalKey, @FirstName, @LastName, @Email, @Mobile, @RoleId, @Password, @SaltKey, GETDATE())
END		
-- EXEC [USP_Insert_Users]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Update_StudentDetails]
(
	@UserId		INT ,
	@FirstName	VARCHAR(800),
	@LastName	VARCHAR(800),
	@IsActive	BIT,
	@OutPut		INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_Users] WHERE UserId = @UserId) > 0)
		BEGIN
			DECLARE @Role INT = (SELECT RoleId FROM [StepTekDB].[tbl_Users] WHERE UserId = 4)
			IF(@Role = 3)
				BEGIN
					UPDATE [StepTekDB].[tbl_Users] SET [FirstName] = @FirstName, [LastName] = @LastName, IsActive= @IsActive WHERE UserId = @UserId
					SET @OutPut = 1 
				END
			ELSE
			SET @OutPut = 101 -- Not Authorized
		END
	ELSE
		SET @OutPut = 100 -- No User
END
-- EXEC [USP_Update_StudentDetails] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_InsertUpdate_CourseCategory]
(
	@Code VARCHAR(5),
	@Desc VARCHAR(100),
	@btnType VARCHAR(15),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF(@btnType = 'Save')
		BEGIN
			IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_CourseCategory] WHERE Code= @Code) = 0)
				BEGIN				
					INSERT INTO [StepTekDB].[tbl_CourseCategory] (Code, [Description], CreatedDate) VALUES (@Code, @Desc, GETDATE())
					SET @OutPut = 1
				END
			ELSE
				SET @OutPut = 99 -- Duplicate Code
		END
	ELSE IF(@btnType = 'Update')
		BEGIN
			UPDATE [StepTekDB].[tbl_CourseCategory] SET [Description] = @Desc WHERE Code = @Code
			SET @OutPut = 1 
		END
	ELSE 
		SET @OutPut = 100 -- Button Text
END
-- EXEC [USP_InsertUpdate_CourseCategory] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Delete_CourseCategory]
(
	@Code VARCHAR(5),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;
	
	IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_CourseCategory] WHERE Code= @Code) > 0)
		BEGIN				
			DECLARE @ID INT = (SELECT CategoryId FROM [StepTekDB].[tbl_CourseCategory] WHERE Code= @Code)
			IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_Course] WHERE CategoryId = @ID) = 0)
				BEGIN
					DELETE FROM [StepTekDB].[tbl_CourseCategory] WHERE Code = @Code
					SET @OutPut = 1
				END
			ELSE
				SET @OutPut = 100 -- Foregin Key
		END
	ELSE
		SET @OutPut = 99 -- Dont Exists
END
-- EXEC [StepTekDB].[USP_Delete_CourseCategory] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_InsertUpdate_CreateCourse]
(
	@CategoryId INT,
	@Title VARCHAR(50),
	@Desc VARCHAR(MAX),
	@btnType VARCHAR(15),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF(@btnType = 'Save')
		BEGIN
			IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_Course] WHERE Title= @Title) = 0)
				BEGIN				
					INSERT INTO [StepTekDB].[tbl_Course] (CategoryId, Title, [Description], CreatedDate) VALUES (@CategoryId, @Title, @Desc, GETDATE())
					SET @OutPut = 1
				END
			ELSE
				SET @OutPut = 99 -- Duplicate Title
		END
	ELSE IF(@btnType = 'Update')
		BEGIN
			UPDATE [StepTekDB].[tbl_Course] SET [Description] = @Desc WHERE Title = @Title
			SET @OutPut = 1 
		END
	ELSE 
		SET @OutPut = 100 -- Button Text
END
-- EXEC [USP_InsertUpdate_CreateCourse] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Delete_Course]
(
	@Title VARCHAR(50),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_Course] WHERE Title = @Title) > 0)
		BEGIN				
			DELETE FROM [StepTekDB].[tbl_Course] WHERE Title = @Title
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Duplicate Title
END
-- EXEC [StepTekDB].[USP_Delete_Course] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_CourseDetails]
AS 
BEGIN 
	SET NOCOUNT ON; 

	SELECT
		CD.CDetailsId,
		C.CourseId,
		C.Title [CourseTitle],
		CC.CategoryId,
		CC.[Description] [CategoryDesc],
		CD.Currency,
		CD.Price,
		CD.Ratting,
		CD.Duration,
		CD.NumOfClasses,
		CD.[Image]
	FROM [StepTekDB].[tbl_CourseDetails] CD
	INNER JOIN [StepTekDB].[tbl_Course] C ON C.CourseId = CD.CourseId
	INNER JOIN [StepTekDB].[tbl_CourseCategory] CC ON CC.CategoryId = C.CategoryId
END 
-- EXEC [StepTekDB].[USP_Get_CourseDetails] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_InsertUpdate_CourseDetails]
(
	@CourseId INT,
	@Currency VARCHAR(300),
	@Price DECIMAL(18,0),
	@Rating INT,
	@Duration INT,
	@NumOfClasses INT,
	@Image VARCHAR(MAX) = NULL,
	@CDetailsId INT = NULL,
	@btnType VARCHAR(300),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF(@btnType = 'Save')
		BEGIN
			IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_CourseDetails] WHERE CourseId= @CourseId) = 0)
				BEGIN				
					INSERT INTO [StepTekDB].[tbl_CourseDetails] (CourseId, [Currency], [Price], [Ratting], [Duration], [NumOfClasses], [Image], [CreatedDate]) 
					VALUES (@CourseId, @Currency, @Price, @Rating, @Duration, @NumOfClasses, @Image, GETDATE())
					SET @OutPut = 1
				END
			ELSE
				SET @OutPut = 99 -- Duplicate Course
		END
	ELSE IF(@btnType = 'Update')
		BEGIN
			IF(@Image IS NULL)
				BEGIN
					UPDATE [StepTekDB].[tbl_CourseDetails] SET [Currency] = @Currency, [Price] = @Price, [Ratting] = @Rating, [Duration] = @Duration, [NumOfClasses] = @NumOfClasses WHERE CDetailsId = @CDetailsId
					SET @OutPut = 1 
				END
			ELSE
				BEGIN
					UPDATE [StepTekDB].[tbl_CourseDetails] SET [Currency] = @Currency, [Price] = @Price, [Ratting] = @Rating, [Duration] = @Duration, [NumOfClasses] = @NumOfClasses, [Image] = @Image WHERE CDetailsId = @CDetailsId
					SET @OutPut = 1 
				END
		END
	ELSE 
		SET @OutPut = 100 -- Button Text
END
-- EXEC [StepTekDB].[USP_InsertUpdate_CourseDetails] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_CourseDetailsById]
(
	@CDetailsId INT
)
AS 
BEGIN 
	SET NOCOUNT ON; 

	SELECT
		CD.CDetailsId,
		C.CourseId,
		C.Title [CourseTitle],
		CC.CategoryId,
		CC.[Description] [CategoryDesc],
		CD.Currency,
		CD.Price,
		CD.Ratting,
		CD.Duration,
		CD.NumOfClasses,
		CD.[Image]
	FROM [StepTekDB].[tbl_CourseDetails] CD
	INNER JOIN [StepTekDB].[tbl_Course] C ON C.CourseId = CD.CourseId
	INNER JOIN [StepTekDB].[tbl_CourseCategory] CC ON CC.CategoryId = C.CategoryId
	WHERE CD.CDetailsId = @CDetailsId
END 
-- EXEC [StepTekDB].[USP_Get_CourseDetailsById]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Delete_CourseDetails]
(
	@ID INT,
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_CourseDetails] WHERE CDetailsId= @ID) > 0)
		BEGIN				
			DELETE FROM [StepTekDB].[tbl_CourseDetails] WHERE CDetailsId = @ID
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Duplicate Title
END
-- EXEC [StepTekDB].[USP_Delete_CourseDetails] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_InsertUpdate_CourseContent]
(
	@ContentId INT = null,
	@CourseId INT,
	@Content VARCHAR(MAX),
	@btnType VARCHAR(15),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	IF(@btnType = 'Save')
		BEGIN
			IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_CourseContent] WHERE CourseId= @CourseId) = 0)
				BEGIN				
					INSERT INTO [StepTekDB].[tbl_CourseContent] ([CourseId], [Concepts], CreatedDate) VALUES (@CourseId, @Content, GETDATE())
					SET @OutPut = 1
				END
			ELSE
				SET @OutPut = 99 -- Duplicate Record
		END
	ELSE IF(@btnType = 'Update')
		BEGIN
			UPDATE [StepTekDB].[tbl_CourseContent] SET [Concepts] = @Content WHERE ContentId = @ContentId
			SET @OutPut = 1 
		END
	ELSE 
		SET @OutPut = 100 -- Button Text
END
-- EXEC [StepTekDB].[USP_InsertUpdate_CourseContent] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Delete_CourseContent]
(
	@ID INT,
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;
	
	IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_CourseContent] WHERE [ContentId] = @ID) > 0)
		BEGIN				
			DELETE FROM [StepTekDB].[tbl_CourseContent] WHERE [ContentId] = @ID
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Dont Exists
END
-- EXEC [StepTekDB].[USP_Delete_CourseContent] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Insert_CreateBatch]
(
	@CourseId INT,
	@StaffName VARCHAR(50),
	@BatchStartDate DATETIME,
	@BatchTime VARCHAR(30),
	@SingleValStudents NVARCHAR(MAX) = NULL,
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRANSACTION;
	SAVE TRANSACTION MySavePoint;
		
	BEGIN TRY
		BEGIN
			DECLARE @ScopeIdentity INT

			DECLARE @BatchDefaultCode VARCHAR(5) = (SELECT 'B#')
			DECLARE @BatchDigits VARCHAR(5) = '00000'
			DECLARE @MaxNumber INT = (SELECT CONVERT(INT, (SELECT RIGHT((SELECT MAX(BatchCode) FROM [StepTekDB].[tbl_Batches]), LEN((SELECT MAX(BatchCode) FROM [StepTekDB].[tbl_Batches])) - 2) + 1)))
			DECLARE @NumberLength INT = LEN(@MaxNumber)
			

			DECLARE @BatchCode VARCHAR(30)
			SET @BatchCode = (
						CASE
							WHEN (SELECT MAX(BatchCode) FROM [StepTekDB].[tbl_Batches]) IS NULL THEN 'B#00001'
							ELSE (SELECT @BatchDefaultCode + LEFT(@BatchDigits, LEN(@BatchDigits) - @NumberLength) + (CONVERT(VARCHAR(5), @MaxNumber))) 
						END
					)
	
			IF((SELECT COUNT(*) FROM [tbl_Batches] WHERE [BatchCode]= @BatchCode) = 0)
				BEGIN				
					INSERT INTO [StepTekDB].[tbl_Batches] ([BatchCode], [CourseId], [StaffName], [StartDate], [BatchTime], [CreatedDate]) VALUES (@BatchCode, @CourseId, @StaffName, @BatchStartDate, @BatchTime, GETDATE())
					SET @ScopeIdentity = SCOPE_IDENTITY();
					INSERT�INTO�[StepTekDB].[tbl_BatchStudents] SELECT @ScopeIdentity, UserId, GETDATE() FROM [StepTekDB].[tbl_Users] WHERE Email IN (SELECT Item FROM [StepTekDB].SplitString(@SingleValStudents,�','))
					SET @OutPut = 1
				END
			ELSE
				SET @OutPut = 99 -- Duplicate BatchCode
		END	
	END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
			BEGIN
				SET @OutPut = 0
				ROLLBACK TRANSACTION MySavePoint; 
			END
		END CATCH
	COMMIT TRANSACTION 
END
-- EXEC [StepTekDB].[USP_Insert_CreateBatch] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_BatchDetails]
AS 
BEGIN 
	SET NOCOUNT ON; 

	SELECT
		B.[BatchId],
		B.[BatchCode],
		B.[CourseId],
		C.Title [CourseDesc],
		(SELECT FORMAT(B.[StartDate], 'dd-MM-yyyy')) +' '+(SELECT FORMAT(B.[BatchTime], 'HH:mm')) [FullDateTime],
		(SELECT COUNT(*) FROM [StepTekDB].[tbl_BatchStudents] WHERE [BatchId] = B.[BatchId]) [NumOfStudents]
	FROM [StepTekDB].[tbl_Batches] B
	INNER JOIN [StepTekDB].[tbl_Course] C ON C.CourseId = B.CourseId
END 
-- EXEC [StepTekDB].[USP_Get_BatchDetails]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_BatchDetailsById]
(
	@BatchId INT
)
AS 
BEGIN 
	SET NOCOUNT ON; 

	SELECT
		B.[BatchId],
		B.[BatchCode],
		B.[CourseId],
		C.Title [CourseDesc],
		B.StaffName,
		(SELECT Convert(date,B.[StartDate])) [BatchStartDate],
		(SELECT FORMAT(B.[BatchTime], 'HH:mm')) [BatchTime]
	FROM [StepTekDB].[tbl_Batches] B
	INNER JOIN [StepTekDB].[tbl_Course] C ON C.CourseId = B.CourseId
	WHERE B.[BatchId] = @BatchId

	SELECT 
	 U.FirstName,
	 U.LastName,
	 U.Email	
	FROM [StepTekDB].[tbl_BatchStudents] BS
	INNER JOIN [StepTekDB].[tbl_Batches] B ON B.BatchId = BS.BatchId
	INNER JOIN [StepTekDB].[tbl_Users] U ON U.UserId = BS.StudentId
	WHERE BS.[BatchId] = @BatchId
END 
-- EXEC [StepTekDB].[USP_Get_BatchDetailsById] 1
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Insert_BatchDetails]
(
	@BatchId INT,
	@SingleValStudents	VARCHAR(300),
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRANSACTION;
	SAVE TRANSACTION MySavePoint;
		
	BEGIN TRY
		BEGIN
			INSERT�INTO�[StepTekDB].[tbl_BatchStudents] SELECT @BatchId, Item, GETDATE() FROM [StepTekDB].SplitString(@SingleValStudents,�',')
			SET @OutPut = 1
		END	
	END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
			BEGIN
				SET @OutPut = 0
				ROLLBACK TRANSACTION MySavePoint; 
			END
		END CATCH
	COMMIT TRANSACTION 
END
-- EXEC [StepTekDB].[USP_Insert_BatchDetails] '15','4,5'
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_AutoCompleteStudents]
(
	@Prefix NVARCHAR(MAX)
)
AS 
BEGIN 
	SET NOCOUNT ON; 

	SELECT Email FROM [StepTekDB].[tbl_Users] WHERE Email LIKE '%' + @Prefix + '%' AND RoleId = 3 AND IsActive = 1
END 
-- EXEC [StepTekDB].[USP_Get_AutoCompleteStudents] 'asdf'
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Update_BatchDetails]
(
	@BatchId INT,
	@StaffName VARCHAR(50),
	@BatchStartDate DATETIME,
	@BatchTime VARCHAR(30),
	@SingleValStudents NVARCHAR(MAX) = NULL,
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRANSACTION;
	SAVE TRANSACTION MySavePoint;
		
	BEGIN TRY
		BEGIN
			DECLARE @ScopeIdentity INT
			
			UPDATE [StepTekDB].[tbl_Batches] SET [StaffName] = @StaffName, [StartDate] = @BatchStartDate, [BatchTime] = @BatchTime WHERE BatchId = @BatchId
			DELETE FROM [StepTekDB].[tbl_BatchStudents] WHERE BatchId = @BatchId
			INSERT�INTO�[StepTekDB].[tbl_BatchStudents] SELECT @BatchId, UserId, GETDATE() FROM tbl_Users WHERE Email IN (SELECT Item FROM [StepTekDB].SplitString(@SingleValStudents,�','))
			SET @OutPut = 1
		END	
	END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
			BEGIN
				SET @OutPut = 0
				ROLLBACK TRANSACTION MySavePoint; 
			END
		END CATCH
	COMMIT TRANSACTION 
END
-- EXEC [StepTekDB].[USP_Update_BatchDetails] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Delete_Batch]
(
	@ID INT,
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRANSACTION;
	SAVE TRANSACTION MySavePoint;
		
	BEGIN TRY
		BEGIN
			IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_Batches] WHERE BatchId = @ID) > 0)
				BEGIN				
					DELETE FROM [StepTekDB].[tbl_BatchStudents] WHERE BatchId = @ID
					DELETE FROM [StepTekDB].[tbl_Batches] WHERE BatchId = @ID
					SET @OutPut = 1
				END
			ELSE
				SET @OutPut = 99 -- Dont Exists
		END	
	END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
			BEGIN
				SET @OutPut = 0
				ROLLBACK TRANSACTION MySavePoint; 
			END
		END CATCH
	COMMIT TRANSACTION 
END
-- EXEC [StepTekDB].[USP_Delete_Batch] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Insert_Forms]
( 
  @FormType			VARCHAR(800),
  @Name				VARCHAR(800),
  @Email            VARCHAR(800),
  @Mobile           VARCHAR(800),
  @Course	        VARCHAR(800),
  @Message	        VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 
	INSERT INTO [StepTekDB].[tbl_Forms] (FormType, Name, Email, Mobile, Course, [Message], [CreatedDate])
	VALUES (@FormType, @Name, @Email, @Mobile, @Course, @Message, GETDATE())
END		
-- EXEC [StepTekDB].[USP_Insert_Forms]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_AdminWidgets]
AS 
BEGIN 
	SET NOCOUNT ON; 

	SELECT 
		(SELECT COUNT(*) FROM [StepTekDB].[tbl_Forms] WHERE FormType = 'mMMOGGqXVAilTOCp4Gw85g==') AS [RequestForms],
		(SELECT COUNT(*) FROM [StepTekDB].[tbl_Forms] WHERE FormType = 'ZEUT1NLj3HqUxXCrfj6v4Q==') AS [ManualForms],	
		(SELECT COUNT(*) FROM [StepTekDB].[tbl_Forms] WHERE FormType = 'bpm5wl2oCtf4GLl9uTG1zA==') AS [ContactForms],
		(SELECT COUNT(*) FROM [StepTekDB].[tbl_Users] WHERE RoleId = 3) AS [RegisteredStudents]
		
END		
-- EXEC [StepTekDB].[USP_Get_AdminWidgets]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Insert_UploadDocument]
( 
  @CourseId		INT,
  @FileName		VARCHAR(800),
  @FileExt		VARCHAR(800),
  @OutPut		INT = 0 OUT
) 
AS 
BEGIN 
	SET NOCOUNT ON; 

	IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_CourseMaterial] WHERE [CourseId] = @CourseId AND [FileName] = @FileName) = 0)
		BEGIN	
			INSERT INTO [StepTekDB].[tbl_CourseMaterial] ([CourseId], [FileName], [FileExt], [CreatedDate])
			VALUES (@CourseId, @FileName, @FileExt, GETDATE())
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Duplicate
END		
-- EXEC [StepTekDB].[USP_Insert_UploadDocument]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Delete_File]
(
	@ID INT,
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;
	
	IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_CourseMaterial] WHERE [MaterialId] = @ID) > 0)
		BEGIN				
			DELETE FROM [StepTekDB].[tbl_CourseMaterial] WHERE [MaterialId] = @ID
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Dont Exists
END
-- EXEC [StepTekDB].[USP_Delete_File] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Insert_UploadVideo]
( 
  @BatchId		INT,
  @Url			VARCHAR(800),
  @OutPut		INT = 0 OUT
) 
AS 
BEGIN 
	SET NOCOUNT ON; 

	IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_VideoRecording] WHERE [BatchId] = @BatchId AND [VideoPath] = @Url) = 0)
		BEGIN	
			INSERT INTO [StepTekDB].[tbl_VideoRecording] ([BatchId], [VideoPath], [CreatedDate])
			VALUES (@BatchId, @Url, GETDATE())
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Duplicate
END		
-- EXEC [StepTekDB].[USP_Insert_UploadVideo]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Delete_Video]
(
	@ID INT,
	@OutPut INT = 0 OUT
)
AS
BEGIN
	SET NOCOUNT ON;
	
	IF((SELECT COUNT(*) FROM [StepTekDB].[tbl_VideoRecording] WHERE [VideoRecId] = @ID) > 0)
		BEGIN				
			DELETE FROM [StepTekDB].[tbl_VideoRecording] WHERE [VideoRecId] = @ID
			SET @OutPut = 1
		END
	ELSE
		SET @OutPut = 99 -- Dont Exists
END
-- EXEC [StepTekDB].[USP_Delete_Video] 132,4
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Update_SendMails]
( 
  @UserId		INT,
  @Password     VARCHAR(800),
  @SaltKey      VARCHAR(800)
) 
AS 
BEGIN 
	SET NOCOUNT ON; 
	UPDATE [StepTekDB].[tbl_Users] SET [Password] = @Password, SaltKey = @SaltKey WHERE UserId = @UserId
END		
-- EXEC [USP_Update_SendMails]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_StudentWidgets]
(
	@UserId INT
)
AS 
BEGIN 
	SET NOCOUNT ON; 

	SELECT 
		(SELECT COUNT(*) FROM tbl_BatchStudents BS WHERE BS.StudentId = @UserId) AS [SelectedCourses],
		(SELECT COUNT(*) FROM tbl_BatchStudents BS INNER JOIN tbl_Batches B ON BS.BatchId = B.BatchId INNER JOIN tbl_CourseMaterial CM ON CM.CourseId = B.CourseId WHERE BS.StudentId = @UserId ) AS [Materials],	
		(SELECT COUNT(*) FROM tbl_BatchStudents BS INNER JOIN tbl_VideoRecording VR ON VR.BatchId = BS.BatchId WHERE BS.StudentId = @UserId ) AS [VideoRecordings],
		(SELECT COUNT(*) FROM tbl_Course C) AS [TotalAvlCourses]

	SELECT 
		BS.BatchId,
		B.BatchCode,
		CC.[Description] [CourseCategory],
		C.CourseId,
		C.Title [CourseDesc],
		CD.[Image],
		(SELECT FORMAT(B.[StartDate], 'dd-MM-yyyy')) +' '+(SELECT FORMAT(B.[BatchTime], 'HH:mm')) [FullDateTime]
	FROM tbl_BatchStudents BS 
	INNER JOIN tbl_Batches B ON B.BatchId = BS.BatchId
	INNER JOIN tbl_Course C ON C.CourseId = B.CourseId 
	LEFT JOIN tbl_CourseDetails CD ON CD.CourseId = B.CourseId 
	INNER JOIN tbl_CourseCategory CC ON CC.CategoryId= C.CategoryId
	WHERE BS.StudentId = @UserId
END		
-- EXEC [StepTekDB].[USP_Get_StudentWidgets] 3
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_PopularCourses]
AS 
BEGIN 
	SET NOCOUNT ON; 

	SELECT 
		TOP 3
		CC.CategoryId, 
		CC.[Description] [CategoryDesc],
		C.CourseId,
		C.Title [CourseTitle],
		C.[Description] [CourseDesc],
		CD.Currency,
		CD.Price,
		CD.Ratting,
		CD.Duration,
		CD.NumOfClasses,
		CD.[Image],
		CCo.Concepts
	FROM [StepTekDB].[tbl_Course] C
	INNER JOIN [StepTekDB].[tbl_CourseDetails] CD ON CD.CourseId = C.CourseId
	INNER JOIN [StepTekDB].[tbl_CourseCategory] CC ON CC.CategoryId = C.CategoryId
	INNER JOIN [StepTekDB].[tbl_CourseContent] CCo ON CCo.CourseId = C.CourseId
	ORDER BY NEWID()
END		
-- EXEC [StepTekDB].[USP_Get_PopularCourses]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_UserAllCourses]
AS 
BEGIN 
	SET NOCOUNT ON; 

	SELECT 
		CC.CategoryId, 
		CC.[Description] [CategoryDesc],
		C.CourseId,
		C.Title [CourseTitle],
		C.[Description] [CourseDesc],
		CD.Currency,
		CD.Price,
		CD.Ratting,
		CD.Duration,
		CD.NumOfClasses,
		CD.[Image],
		CCo.Concepts
	FROM [StepTekDB].[tbl_Course] C
	INNER JOIN [StepTekDB].[tbl_CourseDetails] CD ON CD.CourseId = C.CourseId
	INNER JOIN [StepTekDB].[tbl_CourseCategory] CC ON CC.CategoryId = C.CategoryId
	INNER JOIN [StepTekDB].[tbl_CourseContent] CCo ON CCo.CourseId = C.CourseId
END		
-- EXEC [StepTekDB].[USP_Get_UserAllCourses]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [StepTekDB].[USP_Get_CourseById]
(
	@CourseId INT
)
AS 
BEGIN 
	SET NOCOUNT ON; 

	SELECT 
		CC.CategoryId, 
		CC.[Description] [CategoryDesc],
		C.CourseId,
		C.Title [CourseTitle],
		C.[Description] [CourseDesc],
		CD.Currency,
		CD.Price,
		CD.Ratting,
		CD.Duration,
		CD.NumOfClasses,
		CD.[Image],
		CCo.Concepts
	FROM [StepTekDB].[tbl_Course] C
	INNER JOIN [StepTekDB].[tbl_CourseDetails] CD ON CD.CourseId = C.CourseId
	INNER JOIN [StepTekDB].[tbl_CourseCategory] CC ON CC.CategoryId = C.CategoryId
	INNER JOIN [StepTekDB].[tbl_CourseContent] CCo ON CCo.CourseId = C.CourseId
	WHERE C.CourseId = @CourseId
END		
-- EXEC [StepTekDB].[USP_Get_CourseById] 1






